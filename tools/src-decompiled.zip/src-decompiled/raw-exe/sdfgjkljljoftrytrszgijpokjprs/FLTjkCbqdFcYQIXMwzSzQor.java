/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

public class FLTjkCbqdFcYQIXMwzSzQor {
    private final int rHAjVyBgPhqkQKsOvJMPMYn;
    private final double[] QPeIwmpzLZIktKLXAJOQHcO;
    private final double[] JSuXbPLjXcQLpTiButqPpoI;
    private final double[] iwitQCGCnkthNoQBBlYaPUM;
    private final double dnqxuOOQwmxxivZzrQBWydh;
    private final double[] VZagBOcdslnIaKEkojULJvx;

    public FLTjkCbqdFcYQIXMwzSzQor(int n, double[] dArray, double[] dArray2, double[] dArray3, double d, double[] dArray4) {
        this.rHAjVyBgPhqkQKsOvJMPMYn = n;
        this.QPeIwmpzLZIktKLXAJOQHcO = dArray;
        this.JSuXbPLjXcQLpTiButqPpoI = dArray2;
        this.iwitQCGCnkthNoQBBlYaPUM = dArray3;
        this.dnqxuOOQwmxxivZzrQBWydh = d;
        this.VZagBOcdslnIaKEkojULJvx = dArray4;
    }

    public FLTjkCbqdFcYQIXMwzSzQor(FLTjkCbqdFcYQIXMwzSzQor fLTjkCbqdFcYQIXMwzSzQor) {
        this(fLTjkCbqdFcYQIXMwzSzQor.rHAjVyBgPhqkQKsOvJMPMYn(), fLTjkCbqdFcYQIXMwzSzQor.QPeIwmpzLZIktKLXAJOQHcO(), fLTjkCbqdFcYQIXMwzSzQor.JSuXbPLjXcQLpTiButqPpoI(), fLTjkCbqdFcYQIXMwzSzQor.iwitQCGCnkthNoQBBlYaPUM(), fLTjkCbqdFcYQIXMwzSzQor.dnqxuOOQwmxxivZzrQBWydh(), fLTjkCbqdFcYQIXMwzSzQor.VZagBOcdslnIaKEkojULJvx());
    }

    public int rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }

    public double[] QPeIwmpzLZIktKLXAJOQHcO() {
        return this.QPeIwmpzLZIktKLXAJOQHcO;
    }

    public double[] JSuXbPLjXcQLpTiButqPpoI() {
        return this.JSuXbPLjXcQLpTiButqPpoI;
    }

    public double[] iwitQCGCnkthNoQBBlYaPUM() {
        return this.iwitQCGCnkthNoQBBlYaPUM;
    }

    public double dnqxuOOQwmxxivZzrQBWydh() {
        return this.dnqxuOOQwmxxivZzrQBWydh;
    }

    public double[] VZagBOcdslnIaKEkojULJvx() {
        return this.VZagBOcdslnIaKEkojULJvx;
    }
}

