/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import sdfgjkljljoftrytrszgijpokjprs.DagtpHXBKJqWifDEjrWyNPG;
import sdfgjkljljoftrytrszgijpokjprs.mjycquzYfQnWsdeiKxtdpyM;
import sdfgjkljljoftrytrszgijpokjprs.oJKdRGEwipDKnLCbDZfxxHL;
import sdfgjkljljoftrytrszgijpokjprs.qJjaUDPMXHYSaEdpDZAtvaH;
import sdfgjkljljoftrytrszgijpokjprs.zQAHKnBQNWhKYbQLXMAgfmk;

public class FiypGaFYdzscEBybnfTNrMU {
    private static final FiypGaFYdzscEBybnfTNrMU rHAjVyBgPhqkQKsOvJMPMYn = new FiypGaFYdzscEBybnfTNrMU();
    private final HashMap<String, mjycquzYfQnWsdeiKxtdpyM> QPeIwmpzLZIktKLXAJOQHcO;
    private final ArrayList<oJKdRGEwipDKnLCbDZfxxHL<?>> JSuXbPLjXcQLpTiButqPpoI = new ArrayList(0);

    private FiypGaFYdzscEBybnfTNrMU() {
        this.QPeIwmpzLZIktKLXAJOQHcO = new HashMap(0);
    }

    public static FiypGaFYdzscEBybnfTNrMU rHAjVyBgPhqkQKsOvJMPMYn() {
        return rHAjVyBgPhqkQKsOvJMPMYn;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(String string, mjycquzYfQnWsdeiKxtdpyM mjycquzYfQnWsdeiKxtdpyM2) {
        if (this.QPeIwmpzLZIktKLXAJOQHcO != null && !this.QPeIwmpzLZIktKLXAJOQHcO.containsKey(string)) {
            this.QPeIwmpzLZIktKLXAJOQHcO.put(string, mjycquzYfQnWsdeiKxtdpyM2);
        }
    }

    public BufferedImage rHAjVyBgPhqkQKsOvJMPMYn(String string) {
        mjycquzYfQnWsdeiKxtdpyM mjycquzYfQnWsdeiKxtdpyM2 = this.QPeIwmpzLZIktKLXAJOQHcO.get(string);
        if (mjycquzYfQnWsdeiKxtdpyM2 != null) {
            return mjycquzYfQnWsdeiKxtdpyM2.TNdBwPzcCrGifNBGlgVkPGL();
        }
        return null;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(zQAHKnBQNWhKYbQLXMAgfmk zQAHKnBQNWhKYbQLXMAgfmk2, String string) {
        BufferedImage bufferedImage = zQAHKnBQNWhKYbQLXMAgfmk2.rHAjVyBgPhqkQKsOvJMPMYn(rHAjVyBgPhqkQKsOvJMPMYn);
        try {
            ImageIO.write((RenderedImage)bufferedImage, "PNG", new File(string));
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(oJKdRGEwipDKnLCbDZfxxHL<?> oJKdRGEwipDKnLCbDZfxxHL2, int n) {
        int n2 = n;
        if (oJKdRGEwipDKnLCbDZfxxHL2 != null && !this.JSuXbPLjXcQLpTiButqPpoI.contains(oJKdRGEwipDKnLCbDZfxxHL2)) {
            n2 = n2 < 0 ? 0 : n2;
            n2 = n2 > this.JSuXbPLjXcQLpTiButqPpoI.size() ? this.JSuXbPLjXcQLpTiButqPpoI.size() : n2;
            this.JSuXbPLjXcQLpTiButqPpoI.add(n2, oJKdRGEwipDKnLCbDZfxxHL2);
        }
    }

    public ArrayList<oJKdRGEwipDKnLCbDZfxxHL<?>> QPeIwmpzLZIktKLXAJOQHcO() {
        return this.JSuXbPLjXcQLpTiButqPpoI;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(DagtpHXBKJqWifDEjrWyNPG dagtpHXBKJqWifDEjrWyNPG, String string) {
        File file = new File(string);
        StringBuilder stringBuilder = dagtpHXBKJqWifDEjrWyNPG.QPeIwmpzLZIktKLXAJOQHcO(rHAjVyBgPhqkQKsOvJMPMYn);
        try {
            if (file.exists()) {
                file.delete();
            }
            file.createNewFile();
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file));
            bufferedWriter.append(stringBuilder.toString());
            bufferedWriter.flush();
            bufferedWriter.close();
        }
        catch (IOException iOException) {
            Logger.getLogger(FiypGaFYdzscEBybnfTNrMU.class.getName()).log(Level.SEVERE, null, iOException);
        }
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(qJjaUDPMXHYSaEdpDZAtvaH qJjaUDPMXHYSaEdpDZAtvaH2) {
        qJjaUDPMXHYSaEdpDZAtvaH2.rHAjVyBgPhqkQKsOvJMPMYn(rHAjVyBgPhqkQKsOvJMPMYn);
    }
}

