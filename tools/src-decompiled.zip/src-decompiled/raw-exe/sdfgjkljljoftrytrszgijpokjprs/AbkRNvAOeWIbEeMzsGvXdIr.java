/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

class AbkRNvAOeWIbEeMzsGvXdIr {
    private final byte[] rHAjVyBgPhqkQKsOvJMPMYn;
    private final int QPeIwmpzLZIktKLXAJOQHcO;
    private int JSuXbPLjXcQLpTiButqPpoI;
    private int iwitQCGCnkthNoQBBlYaPUM;

    AbkRNvAOeWIbEeMzsGvXdIr(int n) {
        this.QPeIwmpzLZIktKLXAJOQHcO = n;
        this.rHAjVyBgPhqkQKsOvJMPMYn = new byte[n];
    }

    int rHAjVyBgPhqkQKsOvJMPMYn(byte[] byArray, int n, int n2) {
        System.arraycopy(byArray, n, this.rHAjVyBgPhqkQKsOvJMPMYn, this.JSuXbPLjXcQLpTiButqPpoI, n2);
        this.JSuXbPLjXcQLpTiButqPpoI += n2;
        return this.JSuXbPLjXcQLpTiButqPpoI;
    }

    int QPeIwmpzLZIktKLXAJOQHcO(byte[] byArray, int n, int n2) {
        int n3 = Math.min(n2, this.QPeIwmpzLZIktKLXAJOQHcO - this.iwitQCGCnkthNoQBBlYaPUM);
        System.arraycopy(this.rHAjVyBgPhqkQKsOvJMPMYn, this.iwitQCGCnkthNoQBBlYaPUM, byArray, n, n3);
        this.iwitQCGCnkthNoQBBlYaPUM += n3;
        return n3;
    }

    boolean rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.QPeIwmpzLZIktKLXAJOQHcO > this.iwitQCGCnkthNoQBBlYaPUM;
    }
}

