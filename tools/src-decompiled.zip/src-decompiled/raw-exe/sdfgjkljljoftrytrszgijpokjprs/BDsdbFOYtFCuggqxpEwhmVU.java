/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.awt.event.ActionEvent;

public interface BDsdbFOYtFCuggqxpEwhmVU {
    public void rHAjVyBgPhqkQKsOvJMPMYn(ActionEvent var1, int var2);
}

