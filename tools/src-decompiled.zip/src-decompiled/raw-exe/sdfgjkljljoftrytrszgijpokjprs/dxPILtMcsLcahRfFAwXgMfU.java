/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.io.IOException;
import sdfgjkljljoftrytrszgijpokjprs.eJnHMGFAPyJBjoMvbKedmZt;
import sdfgjkljljoftrytrszgijpokjprs.hrgPgVhiQYIZXeWOluMaPwR;
import sdfgjkljljoftrytrszgijpokjprs.nLKFrMDqbxmPfTbsNqtPeSU;

public class dxPILtMcsLcahRfFAwXgMfU
extends eJnHMGFAPyJBjoMvbKedmZt {
    protected nLKFrMDqbxmPfTbsNqtPeSU[] rHAjVyBgPhqkQKsOvJMPMYn;

    public dxPILtMcsLcahRfFAwXgMfU(hrgPgVhiQYIZXeWOluMaPwR hrgPgVhiQYIZXeWOluMaPwR2, int n, boolean bl) throws IOException {
        super(bl, n);
        int n2 = n / 18;
        this.rHAjVyBgPhqkQKsOvJMPMYn = new nLKFrMDqbxmPfTbsNqtPeSU[n2];
        for (int i = 0; i < this.rHAjVyBgPhqkQKsOvJMPMYn.length; ++i) {
            this.rHAjVyBgPhqkQKsOvJMPMYn[i] = new nLKFrMDqbxmPfTbsNqtPeSU(hrgPgVhiQYIZXeWOluMaPwR2);
        }
        if ((n -= n * 18) > 0) {
            hrgPgVhiQYIZXeWOluMaPwR2.rHAjVyBgPhqkQKsOvJMPMYn(null, n);
        }
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("SeekTable: points=" + this.rHAjVyBgPhqkQKsOvJMPMYn.length + "\n");
        for (int i = 0; i < this.rHAjVyBgPhqkQKsOvJMPMYn.length; ++i) {
            stringBuffer.append("\tPoint " + this.rHAjVyBgPhqkQKsOvJMPMYn[i].toString() + "\n");
        }
        return stringBuffer.toString();
    }
}

