/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import com.xivero.hraa.Main;
import java.io.File;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import sdfgjkljljoftrytrszgijpokjprs.FiypGaFYdzscEBybnfTNrMU;
import sdfgjkljljoftrytrszgijpokjprs.MhVrMnbsUmIgwNYekMCIkde;
import sdfgjkljljoftrytrszgijpokjprs.ROJuPbsRZYkDSnyfZISOUMD;
import sdfgjkljljoftrytrszgijpokjprs.YGjBevanihqaxYKnUNtrNeA;
import sdfgjkljljoftrytrszgijpokjprs.fegnCROFfntWhihpSdONLyP;
import sdfgjkljljoftrytrszgijpokjprs.gDUqxotmDwrsAvlIwIEIdto;
import sdfgjkljljoftrytrszgijpokjprs.hLDzMMEJpHepjqnDHxBExAn;
import sdfgjkljljoftrytrszgijpokjprs.kfrVEsKUvFeBfAoSkvCCRmV;
import sdfgjkljljoftrytrszgijpokjprs.lwCwsaOnEEwXwbudVVNfhyz;
import sdfgjkljljoftrytrszgijpokjprs.oJKdRGEwipDKnLCbDZfxxHL;
import sdfgjkljljoftrytrszgijpokjprs.qJjaUDPMXHYSaEdpDZAtvaH;
import sdfgjkljljoftrytrszgijpokjprs.rLTzSWcNicpRLKKlkUbbehc;

public class AkjxEminiBQvbUdaGZgkyhV
implements MhVrMnbsUmIgwNYekMCIkde,
qJjaUDPMXHYSaEdpDZAtvaH,
rLTzSWcNicpRLKKlkUbbehc {
    private static final AkjxEminiBQvbUdaGZgkyhV rHAjVyBgPhqkQKsOvJMPMYn = new AkjxEminiBQvbUdaGZgkyhV();
    private static final int[] QPeIwmpzLZIktKLXAJOQHcO = new int[]{-32, 6, 3, 11, 13, 9, 9, 9, 9, 9, 9, 9, 9, 10, 10, 10, 9};
    private static final boolean[] JSuXbPLjXcQLpTiButqPpoI = new boolean[]{true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true};
    private final Locale iwitQCGCnkthNoQBBlYaPUM = new Locale("en", "us");
    private YGjBevanihqaxYKnUNtrNeA dnqxuOOQwmxxivZzrQBWydh;
    private final kfrVEsKUvFeBfAoSkvCCRmV VZagBOcdslnIaKEkojULJvx = kfrVEsKUvFeBfAoSkvCCRmV.rHAjVyBgPhqkQKsOvJMPMYn();
    private File VmkNmvoUyyfcyaaKFyveguY;

    protected AkjxEminiBQvbUdaGZgkyhV() {
    }

    public static AkjxEminiBQvbUdaGZgkyhV rHAjVyBgPhqkQKsOvJMPMYn() {
        return rHAjVyBgPhqkQKsOvJMPMYn;
    }

    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(FiypGaFYdzscEBybnfTNrMU fiypGaFYdzscEBybnfTNrMU) {
        hLDzMMEJpHepjqnDHxBExAn hLDzMMEJpHepjqnDHxBExAn2 = new hLDzMMEJpHepjqnDHxBExAn();
        ArrayList<AbstractMap.SimpleEntry<String, Object>> arrayList = this.JSuXbPLjXcQLpTiButqPpoI(fiypGaFYdzscEBybnfTNrMU);
        hLDzMMEJpHepjqnDHxBExAn2.rHAjVyBgPhqkQKsOvJMPMYn(this.VmkNmvoUyyfcyaaKFyveguY.getAbsoluteFile().toPath());
        hLDzMMEJpHepjqnDHxBExAn2.rHAjVyBgPhqkQKsOvJMPMYn(this.rHAjVyBgPhqkQKsOvJMPMYn(32, this.VmkNmvoUyyfcyaaKFyveguY.getName()));
        hLDzMMEJpHepjqnDHxBExAn2.JSuXbPLjXcQLpTiButqPpoI(this.dnqxuOOQwmxxivZzrQBWydh.NuCoRkdmXmpraThwzNAiTcw().rHAjVyBgPhqkQKsOvJMPMYn());
        hLDzMMEJpHepjqnDHxBExAn2.QPeIwmpzLZIktKLXAJOQHcO(this.dnqxuOOQwmxxivZzrQBWydh.NuCoRkdmXmpraThwzNAiTcw().QPeIwmpzLZIktKLXAJOQHcO().name());
        hLDzMMEJpHepjqnDHxBExAn2.QPeIwmpzLZIktKLXAJOQHcO(this.dnqxuOOQwmxxivZzrQBWydh.QPeIwmpzLZIktKLXAJOQHcO().rHAjVyBgPhqkQKsOvJMPMYn());
        hLDzMMEJpHepjqnDHxBExAn2.rHAjVyBgPhqkQKsOvJMPMYn(this.dnqxuOOQwmxxivZzrQBWydh.rHAjVyBgPhqkQKsOvJMPMYn());
        for (AbstractMap.SimpleEntry<String, Object> simpleEntry : arrayList) {
            ROJuPbsRZYkDSnyfZISOUMD rOJuPbsRZYkDSnyfZISOUMD = (ROJuPbsRZYkDSnyfZISOUMD)simpleEntry.getValue();
            switch (simpleEntry.getKey()) {
                case "TPL Left:": {
                    hLDzMMEJpHepjqnDHxBExAn2.rHAjVyBgPhqkQKsOvJMPMYn(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "TPL Right:": {
                    hLDzMMEJpHepjqnDHxBExAn2.QPeIwmpzLZIktKLXAJOQHcO(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "TPL Mid:": {
                    hLDzMMEJpHepjqnDHxBExAn2.wunjGuaHWPKejzkQKUJfPKe(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "TPL Side:": {
                    hLDzMMEJpHepjqnDHxBExAn2.NuCoRkdmXmpraThwzNAiTcw(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "RMS Left:": {
                    hLDzMMEJpHepjqnDHxBExAn2.JSuXbPLjXcQLpTiButqPpoI(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "RMS Right:": {
                    hLDzMMEJpHepjqnDHxBExAn2.iwitQCGCnkthNoQBBlYaPUM(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "RMS Mid:": {
                    hLDzMMEJpHepjqnDHxBExAn2.OrmpCzNZzYDlbDZDBXyofLf(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "RMS Side:": {
                    hLDzMMEJpHepjqnDHxBExAn2.ibbBhgWhrhhiOLwDlcriPhb(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "CREST Avg.:": {
                    hLDzMMEJpHepjqnDHxBExAn2.dnqxuOOQwmxxivZzrQBWydh(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "PLR Avg.:": {
                    hLDzMMEJpHepjqnDHxBExAn2.VZagBOcdslnIaKEkojULJvx(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "Loudness Range:": {
                    hLDzMMEJpHepjqnDHxBExAn2.VmkNmvoUyyfcyaaKFyveguY(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "Integrated Loudness:": {
                    hLDzMMEJpHepjqnDHxBExAn2.YGjBevanihqaxYKnUNtrNeA(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "Cut-Off Frequency:": {
                    hLDzMMEJpHepjqnDHxBExAn2.FoVkhFqKjpvomrYQnnVFKwY(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "Max. M-Loudness:": {
                    hLDzMMEJpHepjqnDHxBExAn2.kMqExmRlFLPTFqBDauCBKYL(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "Max. S-Loudness:": {
                    hLDzMMEJpHepjqnDHxBExAn2.uAGKHXCiDSbltWOPIpXUgwC(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "IS L/M:": {
                    hLDzMMEJpHepjqnDHxBExAn2.kVXnygMrAwyMajIgLatcyWS(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "IS R/S:": {
                    hLDzMMEJpHepjqnDHxBExAn2.vJgxuXjYdOvTUFZsFThavLL(rOJuPbsRZYkDSnyfZISOUMD);
                    break;
                }
                case "HASH:": {
                    hLDzMMEJpHepjqnDHxBExAn2.iwitQCGCnkthNoQBBlYaPUM((String)rOJuPbsRZYkDSnyfZISOUMD.rHAjVyBgPhqkQKsOvJMPMYn());
                }
            }
        }
        this.VZagBOcdslnIaKEkojULJvx.VmkNmvoUyyfcyaaKFyveguY().rHAjVyBgPhqkQKsOvJMPMYn(hLDzMMEJpHepjqnDHxBExAn2);
    }

    @Override
    public StringBuilder QPeIwmpzLZIktKLXAJOQHcO(FiypGaFYdzscEBybnfTNrMU fiypGaFYdzscEBybnfTNrMU) {
        StringBuilder stringBuilder = new StringBuilder(0);
        boolean[] blArray = JSuXbPLjXcQLpTiButqPpoI;
        stringBuilder.append(String.format(this.iwitQCGCnkthNoQBBlYaPUM, "Report generated by the MusicScope %s - www.xivero.com", Main.rHAjVyBgPhqkQKsOvJMPMYn.QPeIwmpzLZIktKLXAJOQHcO(2))).append(System.lineSeparator());
        stringBuilder.append(System.lineSeparator());
        stringBuilder.append(this.rHAjVyBgPhqkQKsOvJMPMYn(blArray, " | ", "Track", "Format", "Bit", "Sample rate", "Cut-Off Freq.", "TPL Left", "TPL Right", "TPL Mid", "TPL Side", "RMS Left", "RMS Right", "RMS Mid", "RMS Side", "CREST Avg.", "PLR Avg.", "I-Loudness", "LRA"));
        stringBuilder.append(System.lineSeparator());
        for (gDUqxotmDwrsAvlIwIEIdto gDUqxotmDwrsAvlIwIEIdto2 : this.VZagBOcdslnIaKEkojULJvx.VZagBOcdslnIaKEkojULJvx()) {
            String string;
            hLDzMMEJpHepjqnDHxBExAn hLDzMMEJpHepjqnDHxBExAn2 = gDUqxotmDwrsAvlIwIEIdto2.YGjBevanihqaxYKnUNtrNeA();
            if ((Integer)hLDzMMEJpHepjqnDHxBExAn2.CWUsTkhDhNSqiWmIUfrczRE().rHAjVyBgPhqkQKsOvJMPMYn() != -1) {
                double d = (Integer)hLDzMMEJpHepjqnDHxBExAn2.CWUsTkhDhNSqiWmIUfrczRE().rHAjVyBgPhqkQKsOvJMPMYn() / 1000;
                string = String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%s %s", d, "kHz");
            } else {
                string = "--- kHz";
            }
            stringBuilder.append(this.rHAjVyBgPhqkQKsOvJMPMYn(blArray, "   ", hLDzMMEJpHepjqnDHxBExAn2.rHAjVyBgPhqkQKsOvJMPMYn(), hLDzMMEJpHepjqnDHxBExAn2.QPeIwmpzLZIktKLXAJOQHcO(), String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%s", hLDzMMEJpHepjqnDHxBExAn2.iwitQCGCnkthNoQBBlYaPUM().rHAjVyBgPhqkQKsOvJMPMYn()), String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%s %s", hLDzMMEJpHepjqnDHxBExAn2.JSuXbPLjXcQLpTiButqPpoI().rHAjVyBgPhqkQKsOvJMPMYn(), hLDzMMEJpHepjqnDHxBExAn2.JSuXbPLjXcQLpTiButqPpoI().QPeIwmpzLZIktKLXAJOQHcO()), String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%s", string), String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%5.1f %s", hLDzMMEJpHepjqnDHxBExAn2.dnqxuOOQwmxxivZzrQBWydh().rHAjVyBgPhqkQKsOvJMPMYn(), hLDzMMEJpHepjqnDHxBExAn2.dnqxuOOQwmxxivZzrQBWydh().QPeIwmpzLZIktKLXAJOQHcO()), String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%5.1f %s", hLDzMMEJpHepjqnDHxBExAn2.VZagBOcdslnIaKEkojULJvx().rHAjVyBgPhqkQKsOvJMPMYn(), hLDzMMEJpHepjqnDHxBExAn2.VZagBOcdslnIaKEkojULJvx().QPeIwmpzLZIktKLXAJOQHcO()), String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%5.1f %s", hLDzMMEJpHepjqnDHxBExAn2.kVXnygMrAwyMajIgLatcyWS().rHAjVyBgPhqkQKsOvJMPMYn(), hLDzMMEJpHepjqnDHxBExAn2.kVXnygMrAwyMajIgLatcyWS().QPeIwmpzLZIktKLXAJOQHcO()), String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%5.1f %s", hLDzMMEJpHepjqnDHxBExAn2.vJgxuXjYdOvTUFZsFThavLL().rHAjVyBgPhqkQKsOvJMPMYn(), hLDzMMEJpHepjqnDHxBExAn2.vJgxuXjYdOvTUFZsFThavLL().QPeIwmpzLZIktKLXAJOQHcO()), String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%5.1f %s", hLDzMMEJpHepjqnDHxBExAn2.VmkNmvoUyyfcyaaKFyveguY().rHAjVyBgPhqkQKsOvJMPMYn(), hLDzMMEJpHepjqnDHxBExAn2.VmkNmvoUyyfcyaaKFyveguY().QPeIwmpzLZIktKLXAJOQHcO()), String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%5.1f %s", hLDzMMEJpHepjqnDHxBExAn2.YGjBevanihqaxYKnUNtrNeA().rHAjVyBgPhqkQKsOvJMPMYn(), hLDzMMEJpHepjqnDHxBExAn2.YGjBevanihqaxYKnUNtrNeA().QPeIwmpzLZIktKLXAJOQHcO()), String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%5.1f %s", hLDzMMEJpHepjqnDHxBExAn2.FoVkhFqKjpvomrYQnnVFKwY().rHAjVyBgPhqkQKsOvJMPMYn(), hLDzMMEJpHepjqnDHxBExAn2.FoVkhFqKjpvomrYQnnVFKwY().QPeIwmpzLZIktKLXAJOQHcO()), String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%5.1f %s", hLDzMMEJpHepjqnDHxBExAn2.kMqExmRlFLPTFqBDauCBKYL().rHAjVyBgPhqkQKsOvJMPMYn(), hLDzMMEJpHepjqnDHxBExAn2.kMqExmRlFLPTFqBDauCBKYL().QPeIwmpzLZIktKLXAJOQHcO()), String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%5.1f %s", hLDzMMEJpHepjqnDHxBExAn2.wunjGuaHWPKejzkQKUJfPKe().rHAjVyBgPhqkQKsOvJMPMYn(), hLDzMMEJpHepjqnDHxBExAn2.wunjGuaHWPKejzkQKUJfPKe().QPeIwmpzLZIktKLXAJOQHcO()), String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%5.1f %s", hLDzMMEJpHepjqnDHxBExAn2.NuCoRkdmXmpraThwzNAiTcw().rHAjVyBgPhqkQKsOvJMPMYn(), hLDzMMEJpHepjqnDHxBExAn2.NuCoRkdmXmpraThwzNAiTcw().QPeIwmpzLZIktKLXAJOQHcO()), String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%5.1f %s", hLDzMMEJpHepjqnDHxBExAn2.ibbBhgWhrhhiOLwDlcriPhb().rHAjVyBgPhqkQKsOvJMPMYn(), hLDzMMEJpHepjqnDHxBExAn2.ibbBhgWhrhhiOLwDlcriPhb().QPeIwmpzLZIktKLXAJOQHcO()), String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%5.1f %s", hLDzMMEJpHepjqnDHxBExAn2.OrmpCzNZzYDlbDZDBXyofLf().rHAjVyBgPhqkQKsOvJMPMYn(), hLDzMMEJpHepjqnDHxBExAn2.OrmpCzNZzYDlbDZDBXyofLf().QPeIwmpzLZIktKLXAJOQHcO())));
            stringBuilder.append(System.lineSeparator());
        }
        stringBuilder.append(System.lineSeparator());
        stringBuilder.append(String.format(this.iwitQCGCnkthNoQBBlYaPUM, "%s: %5.1f %s", "Playlist Loudness Range", this.QPeIwmpzLZIktKLXAJOQHcO(), "dB"));
        stringBuilder.append(System.lineSeparator());
        return stringBuilder;
    }

    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(YGjBevanihqaxYKnUNtrNeA yGjBevanihqaxYKnUNtrNeA, YGjBevanihqaxYKnUNtrNeA yGjBevanihqaxYKnUNtrNeA2) {
        this.dnqxuOOQwmxxivZzrQBWydh = yGjBevanihqaxYKnUNtrNeA2;
    }

    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(String string) {
        this.VmkNmvoUyyfcyaaKFyveguY = new File(string);
    }

    private ArrayList<AbstractMap.SimpleEntry<String, Object>> JSuXbPLjXcQLpTiButqPpoI(FiypGaFYdzscEBybnfTNrMU fiypGaFYdzscEBybnfTNrMU) {
        ArrayList<AbstractMap.SimpleEntry<String, Object>> arrayList = new ArrayList<AbstractMap.SimpleEntry<String, Object>>(0);
        for (oJKdRGEwipDKnLCbDZfxxHL<?> oJKdRGEwipDKnLCbDZfxxHL2 : fiypGaFYdzscEBybnfTNrMU.QPeIwmpzLZIktKLXAJOQHcO()) {
            Object object;
            String string;
            String string2;
            fegnCROFfntWhihpSdONLyP fegnCROFfntWhihpSdONLyP2;
            Object obj = oJKdRGEwipDKnLCbDZfxxHL2.dnqxuOOQwmxxivZzrQBWydh();
            if (obj == null) continue;
            Class<?> clazz = obj.getClass();
            Field[] fieldArray = clazz.getDeclaredFields();
            Method[] methodArray = clazz.getDeclaredMethods();
            for (Field field : fieldArray) {
                fegnCROFfntWhihpSdONLyP2 = field.getAnnotation(fegnCROFfntWhihpSdONLyP.class);
                if (fegnCROFfntWhihpSdONLyP2 == null) continue;
                string2 = fegnCROFfntWhihpSdONLyP2.rHAjVyBgPhqkQKsOvJMPMYn();
                string = fegnCROFfntWhihpSdONLyP2.QPeIwmpzLZIktKLXAJOQHcO();
                object = fegnCROFfntWhihpSdONLyP2.JSuXbPLjXcQLpTiButqPpoI();
                field.setAccessible(true);
                if (Arrays.asList(object).contains(this.dnqxuOOQwmxxivZzrQBWydh.NuCoRkdmXmpraThwzNAiTcw().QPeIwmpzLZIktKLXAJOQHcO().toString())) continue;
                try {
                    Object object2 = field.get(obj);
                    arrayList.add(new AbstractMap.SimpleEntry<String, ROJuPbsRZYkDSnyfZISOUMD>(string2, new ROJuPbsRZYkDSnyfZISOUMD(object2, string)));
                }
                catch (IllegalAccessException | IllegalArgumentException exception) {
                    // empty catch block
                }
            }
            for (AccessibleObject accessibleObject : methodArray) {
                fegnCROFfntWhihpSdONLyP2 = ((Method)accessibleObject).getAnnotation(fegnCROFfntWhihpSdONLyP.class);
                if (fegnCROFfntWhihpSdONLyP2 == null) continue;
                string2 = fegnCROFfntWhihpSdONLyP2.rHAjVyBgPhqkQKsOvJMPMYn();
                string = fegnCROFfntWhihpSdONLyP2.QPeIwmpzLZIktKLXAJOQHcO();
                accessibleObject.setAccessible(true);
                try {
                    object = ((Method)accessibleObject).invoke(obj, new Object[0]);
                    arrayList.add(new AbstractMap.SimpleEntry<String, ROJuPbsRZYkDSnyfZISOUMD>(string2, new ROJuPbsRZYkDSnyfZISOUMD(object, string)));
                }
                catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException exception) {
                    Logger.getLogger(lwCwsaOnEEwXwbudVVNfhyz.class.getName()).log(Level.SEVERE, null, exception);
                }
            }
            arrayList.add(new AbstractMap.SimpleEntry<String, ROJuPbsRZYkDSnyfZISOUMD>("", new ROJuPbsRZYkDSnyfZISOUMD("", "")));
        }
        return arrayList;
    }

    private String rHAjVyBgPhqkQKsOvJMPMYn(boolean[] blArray, String string, Object ... objectArray) {
        String string2 = "";
        for (int i = 0; i < blArray.length; ++i) {
            if (!blArray[i]) continue;
            string2 = string2 + String.format("%" + QPeIwmpzLZIktKLXAJOQHcO[i] + "s", objectArray[i]);
            string2 = string2 + (i == blArray.length - 1 ? "" : string);
        }
        return string2;
    }

    private double QPeIwmpzLZIktKLXAJOQHcO() {
        double d = 0.0;
        for (gDUqxotmDwrsAvlIwIEIdto gDUqxotmDwrsAvlIwIEIdto2 : this.VZagBOcdslnIaKEkojULJvx.VZagBOcdslnIaKEkojULJvx()) {
            double d2 = (Double)gDUqxotmDwrsAvlIwIEIdto2.YGjBevanihqaxYKnUNtrNeA().OrmpCzNZzYDlbDZDBXyofLf().rHAjVyBgPhqkQKsOvJMPMYn();
            d += Math.pow(10.0, d2 / 20.0);
        }
        return 20.0 * Math.log10(d / (double)this.VZagBOcdslnIaKEkojULJvx.VZagBOcdslnIaKEkojULJvx().size());
    }

    private String rHAjVyBgPhqkQKsOvJMPMYn(int n, String string) {
        if (string.length() > n) {
            String string2 = string.substring(0, n / 2 - 3);
            String string3 = string.substring(string.length() - n / 2, string.length());
            return string2 + "..." + string3;
        }
        return string;
    }
}

