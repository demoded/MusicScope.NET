/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.TDhalVHIgJpVEqwCgwFnQOQ;
import sdfgjkljljoftrytrszgijpokjprs.YGjBevanihqaxYKnUNtrNeA;
import sdfgjkljljoftrytrszgijpokjprs.hLDzMMEJpHepjqnDHxBExAn;
import sdfgjkljljoftrytrszgijpokjprs.nszTqDkxYiaGpuKyqsPMpEP;

public class gDUqxotmDwrsAvlIwIEIdto
implements nszTqDkxYiaGpuKyqsPMpEP {
    private final String rHAjVyBgPhqkQKsOvJMPMYn;
    private final String QPeIwmpzLZIktKLXAJOQHcO;
    private String JSuXbPLjXcQLpTiButqPpoI;
    private boolean iwitQCGCnkthNoQBBlYaPUM;
    private boolean dnqxuOOQwmxxivZzrQBWydh;
    private boolean VZagBOcdslnIaKEkojULJvx;
    private boolean VmkNmvoUyyfcyaaKFyveguY;
    private boolean YGjBevanihqaxYKnUNtrNeA;
    private hLDzMMEJpHepjqnDHxBExAn wunjGuaHWPKejzkQKUJfPKe;
    private YGjBevanihqaxYKnUNtrNeA NuCoRkdmXmpraThwzNAiTcw;
    private TDhalVHIgJpVEqwCgwFnQOQ OrmpCzNZzYDlbDZDBXyofLf;

    public gDUqxotmDwrsAvlIwIEIdto(String string, String string2, String string3, boolean bl, boolean bl2, boolean bl3, boolean bl4) {
        this.rHAjVyBgPhqkQKsOvJMPMYn = string;
        this.QPeIwmpzLZIktKLXAJOQHcO = string2;
        this.JSuXbPLjXcQLpTiButqPpoI = string3;
        this.iwitQCGCnkthNoQBBlYaPUM = bl;
        this.dnqxuOOQwmxxivZzrQBWydh = bl2;
        this.VmkNmvoUyyfcyaaKFyveguY = bl4;
        this.VZagBOcdslnIaKEkojULJvx = bl3;
        this.wunjGuaHWPKejzkQKUJfPKe = null;
    }

    public String rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }

    public String QPeIwmpzLZIktKLXAJOQHcO() {
        return this.QPeIwmpzLZIktKLXAJOQHcO;
    }

    public String JSuXbPLjXcQLpTiButqPpoI() {
        return this.JSuXbPLjXcQLpTiButqPpoI;
    }

    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(String string) {
        this.JSuXbPLjXcQLpTiButqPpoI = string;
        if (this.OrmpCzNZzYDlbDZDBXyofLf != null) {
            this.OrmpCzNZzYDlbDZDBXyofLf.kVXnygMrAwyMajIgLatcyWS();
        }
    }

    public boolean iwitQCGCnkthNoQBBlYaPUM() {
        return this.iwitQCGCnkthNoQBBlYaPUM;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(boolean bl) {
        this.iwitQCGCnkthNoQBBlYaPUM = bl;
        if (bl) {
            this.wunjGuaHWPKejzkQKUJfPKe = null;
        }
    }

    public boolean dnqxuOOQwmxxivZzrQBWydh() {
        return this.dnqxuOOQwmxxivZzrQBWydh;
    }

    public void QPeIwmpzLZIktKLXAJOQHcO(boolean bl) {
        this.dnqxuOOQwmxxivZzrQBWydh = bl;
        if (bl) {
            this.wunjGuaHWPKejzkQKUJfPKe = null;
        }
    }

    public YGjBevanihqaxYKnUNtrNeA VZagBOcdslnIaKEkojULJvx() {
        return this.NuCoRkdmXmpraThwzNAiTcw;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(YGjBevanihqaxYKnUNtrNeA yGjBevanihqaxYKnUNtrNeA) {
        this.NuCoRkdmXmpraThwzNAiTcw = yGjBevanihqaxYKnUNtrNeA;
    }

    public Object rHAjVyBgPhqkQKsOvJMPMYn(int n) {
        switch (n) {
            case 0: {
                return this.QPeIwmpzLZIktKLXAJOQHcO();
            }
            case 1: {
                return this.iwitQCGCnkthNoQBBlYaPUM();
            }
            case 2: {
                return this.dnqxuOOQwmxxivZzrQBWydh();
            }
            case 3: {
                return this.JSuXbPLjXcQLpTiButqPpoI();
            }
        }
        return null;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(Object object, int n) {
        switch (n) {
            case 1: {
                this.rHAjVyBgPhqkQKsOvJMPMYn((Boolean)object);
                break;
            }
            case 2: {
                this.QPeIwmpzLZIktKLXAJOQHcO((Boolean)object);
                break;
            }
            case 3: {
                this.rHAjVyBgPhqkQKsOvJMPMYn((String)object);
            }
        }
    }

    public boolean VmkNmvoUyyfcyaaKFyveguY() {
        return this.YGjBevanihqaxYKnUNtrNeA;
    }

    public void JSuXbPLjXcQLpTiButqPpoI(boolean bl) {
        this.YGjBevanihqaxYKnUNtrNeA = bl;
    }

    public hLDzMMEJpHepjqnDHxBExAn YGjBevanihqaxYKnUNtrNeA() {
        return this.wunjGuaHWPKejzkQKUJfPKe;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(hLDzMMEJpHepjqnDHxBExAn hLDzMMEJpHepjqnDHxBExAn2) {
        this.wunjGuaHWPKejzkQKUJfPKe = hLDzMMEJpHepjqnDHxBExAn2;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(TDhalVHIgJpVEqwCgwFnQOQ tDhalVHIgJpVEqwCgwFnQOQ) {
        this.OrmpCzNZzYDlbDZDBXyofLf = tDhalVHIgJpVEqwCgwFnQOQ;
    }
}

