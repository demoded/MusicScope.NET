/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

public abstract class eJnHMGFAPyJBjoMvbKedmZt {
    protected boolean VZagBOcdslnIaKEkojULJvx;
    protected int VmkNmvoUyyfcyaaKFyveguY;

    public eJnHMGFAPyJBjoMvbKedmZt(boolean bl, int n) {
        this.VZagBOcdslnIaKEkojULJvx = bl;
        this.VmkNmvoUyyfcyaaKFyveguY = n;
    }

    public boolean rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.VZagBOcdslnIaKEkojULJvx;
    }

    public int QPeIwmpzLZIktKLXAJOQHcO() {
        return this.VmkNmvoUyyfcyaaKFyveguY + 4;
    }
}

