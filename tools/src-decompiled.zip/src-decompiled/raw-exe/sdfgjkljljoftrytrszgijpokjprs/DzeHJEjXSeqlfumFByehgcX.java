/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.JkbcbdCPHrPQuHSTsgwADIb;

public abstract class DzeHJEjXSeqlfumFByehgcX
implements JkbcbdCPHrPQuHSTsgwADIb {
    private long rHAjVyBgPhqkQKsOvJMPMYn;

    public long rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(long l) {
        this.rHAjVyBgPhqkQKsOvJMPMYn = l;
    }
}

