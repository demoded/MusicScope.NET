/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.FiypGaFYdzscEBybnfTNrMU;

public interface DagtpHXBKJqWifDEjrWyNPG {
    public StringBuilder QPeIwmpzLZIktKLXAJOQHcO(FiypGaFYdzscEBybnfTNrMU var1);
}

