/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.util.concurrent.Callable;

public interface EYLjCFiTTOgnPWQPYoTfNzn<V>
extends Callable<V> {
    public V QPeIwmpzLZIktKLXAJOQHcO() throws Exception;

    public void rHAjVyBgPhqkQKsOvJMPMYn(int var1);
}

