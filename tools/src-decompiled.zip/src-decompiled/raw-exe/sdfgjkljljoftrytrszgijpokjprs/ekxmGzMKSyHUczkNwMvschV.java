/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.cJizbPrgAISXyzXrgujHPeB;

public interface ekxmGzMKSyHUczkNwMvschV<V> {
    public void rHAjVyBgPhqkQKsOvJMPMYn(V var1, cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn var2);
}

