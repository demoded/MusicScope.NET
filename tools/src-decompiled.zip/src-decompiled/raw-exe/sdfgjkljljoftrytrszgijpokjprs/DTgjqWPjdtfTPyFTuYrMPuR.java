/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import javax.sound.sampled.AudioFormat;
import sdfgjkljljoftrytrszgijpokjprs.AGpEswewZOXTtopHPFqtErb;
import sdfgjkljljoftrytrszgijpokjprs.KFVWmcqOBgYFxPgeswapvPe;
import sdfgjkljljoftrytrszgijpokjprs.QPeIwmpzLZIktKLXAJOQHcO;
import sdfgjkljljoftrytrszgijpokjprs.TWPHktttPCBsYgoUXmAgKnC;
import sdfgjkljljoftrytrszgijpokjprs.YGjBevanihqaxYKnUNtrNeA;

class DTgjqWPjdtfTPyFTuYrMPuR
implements YGjBevanihqaxYKnUNtrNeA {
    private final AudioFormat rHAjVyBgPhqkQKsOvJMPMYn;
    private final int QPeIwmpzLZIktKLXAJOQHcO;
    private QPeIwmpzLZIktKLXAJOQHcO JSuXbPLjXcQLpTiButqPpoI;

    public DTgjqWPjdtfTPyFTuYrMPuR(AudioFormat audioFormat, int n) {
        this.rHAjVyBgPhqkQKsOvJMPMYn = audioFormat;
        this.QPeIwmpzLZIktKLXAJOQHcO = n;
    }

    @Override
    public int rHAjVyBgPhqkQKsOvJMPMYn() {
        return (int)this.rHAjVyBgPhqkQKsOvJMPMYn.getSampleRate();
    }

    @Override
    public KFVWmcqOBgYFxPgeswapvPe QPeIwmpzLZIktKLXAJOQHcO() {
        return KFVWmcqOBgYFxPgeswapvPe.QPeIwmpzLZIktKLXAJOQHcO(this.rHAjVyBgPhqkQKsOvJMPMYn.getSampleSizeInBits());
    }

    @Override
    public int JSuXbPLjXcQLpTiButqPpoI() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn() * this.iwitQCGCnkthNoQBBlYaPUM() * this.QPeIwmpzLZIktKLXAJOQHcO().QPeIwmpzLZIktKLXAJOQHcO();
    }

    @Override
    public int iwitQCGCnkthNoQBBlYaPUM() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn.getChannels();
    }

    @Override
    public TWPHktttPCBsYgoUXmAgKnC dnqxuOOQwmxxivZzrQBWydh() {
        return TWPHktttPCBsYgoUXmAgKnC.JSuXbPLjXcQLpTiButqPpoI;
    }

    @Override
    public long VZagBOcdslnIaKEkojULJvx() {
        return this.QPeIwmpzLZIktKLXAJOQHcO / this.JSuXbPLjXcQLpTiButqPpoI();
    }

    @Override
    public long VmkNmvoUyyfcyaaKFyveguY() {
        return this.QPeIwmpzLZIktKLXAJOQHcO;
    }

    @Override
    public String YGjBevanihqaxYKnUNtrNeA() {
        return "No name";
    }

    @Override
    public int wunjGuaHWPKejzkQKUJfPKe() {
        return 0;
    }

    @Override
    public AGpEswewZOXTtopHPFqtErb NuCoRkdmXmpraThwzNAiTcw() {
        return AGpEswewZOXTtopHPFqtErb.YGjBevanihqaxYKnUNtrNeA;
    }

    @Override
    public long OrmpCzNZzYDlbDZDBXyofLf() {
        return Long.MIN_VALUE;
    }

    @Override
    public long ibbBhgWhrhhiOLwDlcriPhb() {
        return this.OrmpCzNZzYDlbDZDBXyofLf();
    }

    @Override
    public QPeIwmpzLZIktKLXAJOQHcO kVXnygMrAwyMajIgLatcyWS() {
        return this.JSuXbPLjXcQLpTiButqPpoI;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(QPeIwmpzLZIktKLXAJOQHcO qPeIwmpzLZIktKLXAJOQHcO) {
        this.JSuXbPLjXcQLpTiButqPpoI = qPeIwmpzLZIktKLXAJOQHcO;
    }
}

