/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package sdfgjkljljoftrytrszgijpokjprs;

import com.google.gson.annotations.SerializedName;
import sdfgjkljljoftrytrszgijpokjprs.OYxnuGnRxgrJcQlkwcqoEzu;

public class cxgXPZvqmsDtmYhggfCRwiz {
    @SerializedName(value="lra")
    private double rHAjVyBgPhqkQKsOvJMPMYn = -1.0;
    @SerializedName(value="noIsp")
    private boolean QPeIwmpzLZIktKLXAJOQHcO;

    public void rHAjVyBgPhqkQKsOvJMPMYn(double d) {
        this.rHAjVyBgPhqkQKsOvJMPMYn = OYxnuGnRxgrJcQlkwcqoEzu.rHAjVyBgPhqkQKsOvJMPMYn(d, 1);
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(boolean bl) {
        this.QPeIwmpzLZIktKLXAJOQHcO = bl;
    }
}

