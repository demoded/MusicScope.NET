/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Line;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import sdfgjkljljoftrytrszgijpokjprs.VNCvmztVWQPbbbOMHkAjmTw;
import sdfgjkljljoftrytrszgijpokjprs.hetTKOScphLxLEtDQDmaEvK;

public class froHLNEMoKyANSaNQrCIWqe
extends JDialog
implements ActionListener {
    static final Mixer.Info[] rHAjVyBgPhqkQKsOvJMPMYn = AudioSystem.getMixerInfo();
    static final int[] QPeIwmpzLZIktKLXAJOQHcO = new int[rHAjVyBgPhqkQKsOvJMPMYn.length + 1];
    static final int[] JSuXbPLjXcQLpTiButqPpoI = new int[rHAjVyBgPhqkQKsOvJMPMYn.length + 1];
    static final JComboBox iwitQCGCnkthNoQBBlYaPUM = new JComboBox();
    static final JComboBox dnqxuOOQwmxxivZzrQBWydh = new JComboBox();
    private static final JButton NuCoRkdmXmpraThwzNAiTcw = new JButton("Start");
    private static final JLabel OrmpCzNZzYDlbDZDBXyofLf = new JLabel("        THD:");
    private static final JLabel ibbBhgWhrhhiOLwDlcriPhb = new JLabel("%");
    private static final JLabel kVXnygMrAwyMajIgLatcyWS = new JLabel("      THD Attenuation:");
    private static final JLabel vJgxuXjYdOvTUFZsFThavLL = new JLabel("dB");
    static JTextField VZagBOcdslnIaKEkojULJvx = new JTextField("----", 7);
    static JTextField VmkNmvoUyyfcyaaKFyveguY = new JTextField("----", 4);
    public static final hetTKOScphLxLEtDQDmaEvK YGjBevanihqaxYKnUNtrNeA = new hetTKOScphLxLEtDQDmaEvK();
    public static VNCvmztVWQPbbbOMHkAjmTw wunjGuaHWPKejzkQKUJfPKe = new VNCvmztVWQPbbbOMHkAjmTw();

    public froHLNEMoKyANSaNQrCIWqe(Frame frame, boolean bl) {
        super(frame, bl);
        froHLNEMoKyANSaNQrCIWqe.iwitQCGCnkthNoQBBlYaPUM();
        this.JSuXbPLjXcQLpTiButqPpoI();
    }

    private Component QPeIwmpzLZIktKLXAJOQHcO() {
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BoxLayout(jPanel, 3));
        jPanel.setBackground(Color.black);
        JPanel jPanel2 = new JPanel();
        JPanel jPanel3 = new JPanel();
        jPanel3.setBackground(Color.white);
        jPanel.add(jPanel2);
        jPanel.add(jPanel3);
        JLabel jLabel = new JLabel("Input:");
        iwitQCGCnkthNoQBBlYaPUM.setPreferredSize(new Dimension(250, 25));
        dnqxuOOQwmxxivZzrQBWydh.setPreferredSize(new Dimension(200, 25));
        jPanel2.add(jLabel);
        jPanel2.add(iwitQCGCnkthNoQBBlYaPUM);
        YGjBevanihqaxYKnUNtrNeA.setPreferredSize(new Dimension(1100, 775));
        YGjBevanihqaxYKnUNtrNeA.setBackground(Color.white);
        jPanel3.add(YGjBevanihqaxYKnUNtrNeA);
        jPanel2.add(NuCoRkdmXmpraThwzNAiTcw);
        NuCoRkdmXmpraThwzNAiTcw.addActionListener(this);
        jPanel2.add(OrmpCzNZzYDlbDZDBXyofLf);
        VZagBOcdslnIaKEkojULJvx.setEditable(false);
        VZagBOcdslnIaKEkojULJvx.setHorizontalAlignment(4);
        jPanel2.add(VZagBOcdslnIaKEkojULJvx);
        jPanel2.add(ibbBhgWhrhhiOLwDlcriPhb);
        jPanel2.add(kVXnygMrAwyMajIgLatcyWS);
        VmkNmvoUyyfcyaaKFyveguY.setEditable(false);
        VmkNmvoUyyfcyaaKFyveguY.setHorizontalAlignment(4);
        jPanel2.add(VmkNmvoUyyfcyaaKFyveguY);
        jPanel2.add(vJgxuXjYdOvTUFZsFThavLL);
        return jPanel;
    }

    private void JSuXbPLjXcQLpTiButqPpoI() {
        Dimension dimension = new Dimension(1150, 860);
        this.setTitle("MusicScope - THD Analyzer");
        this.setLocation(10, 10);
        this.setPreferredSize(dimension);
        this.setMinimumSize(dimension);
        this.setMaximumSize(dimension);
        this.setSize(dimension);
        this.setDefaultCloseOperation(1);
        this.setResizable(false);
        this.addWindowListener(new WindowAdapter(){

            @Override
            public void windowClosing(WindowEvent windowEvent) {
                froHLNEMoKyANSaNQrCIWqe.this.VZagBOcdslnIaKEkojULJvx();
            }
        });
        Component component = this.QPeIwmpzLZIktKLXAJOQHcO();
        this.getContentPane().add(component, "Center");
    }

    private static void iwitQCGCnkthNoQBBlYaPUM() {
        int n = 0;
        boolean bl = false;
        Line.Info info = new Line.Info(TargetDataLine.class);
        for (int i = 0; i < rHAjVyBgPhqkQKsOvJMPMYn.length; ++i) {
            Mixer mixer = AudioSystem.getMixer(rHAjVyBgPhqkQKsOvJMPMYn[i]);
            if (!mixer.isLineSupported(info)) continue;
            iwitQCGCnkthNoQBBlYaPUM.addItem(rHAjVyBgPhqkQKsOvJMPMYn[i].getName());
            froHLNEMoKyANSaNQrCIWqe.QPeIwmpzLZIktKLXAJOQHcO[n] = i;
            ++n;
        }
    }

    private void dnqxuOOQwmxxivZzrQBWydh() {
        if (!wunjGuaHWPKejzkQKUJfPKe.rHAjVyBgPhqkQKsOvJMPMYn()) {
            wunjGuaHWPKejzkQKUJfPKe.rHAjVyBgPhqkQKsOvJMPMYn(true);
        }
        try {
            Thread.sleep(500L);
        }
        catch (InterruptedException interruptedException) {
            // empty catch block
        }
        YGjBevanihqaxYKnUNtrNeA.rHAjVyBgPhqkQKsOvJMPMYn();
        wunjGuaHWPKejzkQKUJfPKe.rHAjVyBgPhqkQKsOvJMPMYn(false);
        new Thread(wunjGuaHWPKejzkQKUJfPKe).start();
        NuCoRkdmXmpraThwzNAiTcw.setText("Stop");
    }

    private void VZagBOcdslnIaKEkojULJvx() {
        wunjGuaHWPKejzkQKUJfPKe.rHAjVyBgPhqkQKsOvJMPMYn(true);
        NuCoRkdmXmpraThwzNAiTcw.setText("Start");
    }

    public static void rHAjVyBgPhqkQKsOvJMPMYn() {
        NuCoRkdmXmpraThwzNAiTcw.setText("Start");
    }

    public static void rHAjVyBgPhqkQKsOvJMPMYn(double[] dArray, double d) {
        if (YGjBevanihqaxYKnUNtrNeA != null) {
            YGjBevanihqaxYKnUNtrNeA.rHAjVyBgPhqkQKsOvJMPMYn(dArray, d);
        }
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        if (actionEvent.getSource() == NuCoRkdmXmpraThwzNAiTcw) {
            if ("Start".equals(NuCoRkdmXmpraThwzNAiTcw.getText())) {
                this.dnqxuOOQwmxxivZzrQBWydh();
            } else {
                this.VZagBOcdslnIaKEkojULJvx();
            }
        }
    }

    @Override
    public void setVisible(boolean bl) {
        if (bl) {
            this.setLocationRelativeTo(null);
        }
        super.setVisible(bl);
    }
}

