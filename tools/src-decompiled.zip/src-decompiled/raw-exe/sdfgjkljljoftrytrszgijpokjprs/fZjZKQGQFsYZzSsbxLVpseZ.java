/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import sdfgjkljljoftrytrszgijpokjprs.YzXXpcCCVJkKMcoHoACbjGG;

public class fZjZKQGQFsYZzSsbxLVpseZ {
    private static final String rHAjVyBgPhqkQKsOvJMPMYn = YzXXpcCCVJkKMcoHoACbjGG.rHAjVyBgPhqkQKsOvJMPMYn("MusicScope", "SystemSettings.properties");
    private static final Object QPeIwmpzLZIktKLXAJOQHcO = new Object();
    private static fZjZKQGQFsYZzSsbxLVpseZ JSuXbPLjXcQLpTiButqPpoI;
    private final Properties iwitQCGCnkthNoQBBlYaPUM = new Properties();

    private fZjZKQGQFsYZzSsbxLVpseZ() {
        this.QPeIwmpzLZIktKLXAJOQHcO(rHAjVyBgPhqkQKsOvJMPMYn);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static fZjZKQGQFsYZzSsbxLVpseZ rHAjVyBgPhqkQKsOvJMPMYn() {
        if (JSuXbPLjXcQLpTiButqPpoI == null) {
            Object object = QPeIwmpzLZIktKLXAJOQHcO;
            synchronized (object) {
                if (JSuXbPLjXcQLpTiButqPpoI == null) {
                    JSuXbPLjXcQLpTiButqPpoI = new fZjZKQGQFsYZzSsbxLVpseZ();
                }
            }
        }
        return JSuXbPLjXcQLpTiButqPpoI;
    }

    public String rHAjVyBgPhqkQKsOvJMPMYn(String string) {
        return this.iwitQCGCnkthNoQBBlYaPUM.getProperty(string);
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(String string, String string2) {
        this.iwitQCGCnkthNoQBBlYaPUM.setProperty(string, string2);
        this.JSuXbPLjXcQLpTiButqPpoI(rHAjVyBgPhqkQKsOvJMPMYn);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void QPeIwmpzLZIktKLXAJOQHcO(String string) {
        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(string);
            this.iwitQCGCnkthNoQBBlYaPUM.load(fileInputStream);
        }
        catch (IOException iOException) {
        }
        finally {
            try {
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
            }
            catch (IOException iOException) {}
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void JSuXbPLjXcQLpTiButqPpoI(String string) {
        File file = new File(string);
        FileOutputStream fileOutputStream = null;
        if (!file.exists()) {
            file.getParentFile().mkdirs();
        }
        try {
            fileOutputStream = new FileOutputStream(file);
            this.iwitQCGCnkthNoQBBlYaPUM.store(fileOutputStream, null);
        }
        catch (IOException iOException) {
        }
        finally {
            if (fileOutputStream != null) {
                try {
                    fileOutputStream.close();
                }
                catch (IOException iOException) {}
            }
        }
    }
}

