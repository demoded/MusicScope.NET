/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

public interface gTFnKQGZNjRkBqwPpskYCUd {
    public void rHAjVyBgPhqkQKsOvJMPMYn(String var1);
}

