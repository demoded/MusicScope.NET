/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.nio.ByteBuffer;
import sdfgjkljljoftrytrszgijpokjprs.NQNHsyTtMLkOfnutDZwcTrt;
import sdfgjkljljoftrytrszgijpokjprs.XUZmRmMUmxUHZmymTILWbDT;
import sdfgjkljljoftrytrszgijpokjprs.ZDSaXekyHHNqfExESErZUQI;
import sdfgjkljljoftrytrszgijpokjprs.psJsIRSyxnSjAJUtCLtVicz;

public class cdSECoXyrascmeWiUkiBTmK
extends XUZmRmMUmxUHZmymTILWbDT {
    @ZDSaXekyHHNqfExESErZUQI(rHAjVyBgPhqkQKsOvJMPMYn=4)
    private final char[] rHAjVyBgPhqkQKsOvJMPMYn = new char[4];
    private final NQNHsyTtMLkOfnutDZwcTrt QPeIwmpzLZIktKLXAJOQHcO = new NQNHsyTtMLkOfnutDZwcTrt();
    private final psJsIRSyxnSjAJUtCLtVicz JSuXbPLjXcQLpTiButqPpoI = new psJsIRSyxnSjAJUtCLtVicz();

    public char[] iwitQCGCnkthNoQBBlYaPUM() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }

    public NQNHsyTtMLkOfnutDZwcTrt dnqxuOOQwmxxivZzrQBWydh() {
        return this.QPeIwmpzLZIktKLXAJOQHcO;
    }

    public psJsIRSyxnSjAJUtCLtVicz VZagBOcdslnIaKEkojULJvx() {
        return this.JSuXbPLjXcQLpTiButqPpoI;
    }

    @Override
    public void QPeIwmpzLZIktKLXAJOQHcO(ByteBuffer byteBuffer) {
        for (int i = 0; i < 4; ++i) {
            this.rHAjVyBgPhqkQKsOvJMPMYn[i] = (char)byteBuffer.get();
        }
    }
}

