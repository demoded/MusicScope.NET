/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  javax.ws.rs.ProcessingException
 *  javax.ws.rs.client.Client
 *  javax.ws.rs.client.ClientBuilder
 *  javax.ws.rs.client.Entity
 *  javax.ws.rs.client.Invocation$Builder
 *  javax.ws.rs.client.WebTarget
 *  javax.ws.rs.core.MediaType
 */
package sdfgjkljljoftrytrszgijpokjprs;

import com.google.gson.Gson;
import java.security.SecureRandom;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.ws.rs.ProcessingException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import sdfgjkljljoftrytrszgijpokjprs.LzCAJZEadLaXnGAVreeEXhK;
import sdfgjkljljoftrytrszgijpokjprs.NsnRIHEihaQxXVQOAJMMZZW;
import sdfgjkljljoftrytrszgijpokjprs.dXwHeIuXrPXwwYsOazDjvwg;
import sdfgjkljljoftrytrszgijpokjprs.fikLFfybOLBBPFzDSaJuDxU;
import sdfgjkljljoftrytrszgijpokjprs.fkymSnbJojnjWTHxKogeOzr;
import sdfgjkljljoftrytrszgijpokjprs.nszTqDkxYiaGpuKyqsPMpEP;

class dXJPyPaUBgexSaefEizNJCt
extends NsnRIHEihaQxXVQOAJMMZZW<dXwHeIuXrPXwwYsOazDjvwg> {
    private final int QPeIwmpzLZIktKLXAJOQHcO = 3;
    private final int JSuXbPLjXcQLpTiButqPpoI = 10000;
    private final int iwitQCGCnkthNoQBBlYaPUM = 60000;
    private final LzCAJZEadLaXnGAVreeEXhK dnqxuOOQwmxxivZzrQBWydh;
    private final String VZagBOcdslnIaKEkojULJvx;
    private final String VmkNmvoUyyfcyaaKFyveguY;

    dXJPyPaUBgexSaefEizNJCt(LzCAJZEadLaXnGAVreeEXhK lzCAJZEadLaXnGAVreeEXhK, String string, String string2) {
        this.dnqxuOOQwmxxivZzrQBWydh = lzCAJZEadLaXnGAVreeEXhK;
        this.VZagBOcdslnIaKEkojULJvx = string;
        this.VmkNmvoUyyfcyaaKFyveguY = string2;
    }

    public dXwHeIuXrPXwwYsOazDjvwg rHAjVyBgPhqkQKsOvJMPMYn() throws Exception {
        String string = "Uploading...";
        this.dnqxuOOQwmxxivZzrQBWydh.QPeIwmpzLZIktKLXAJOQHcO(true);
        this.QPeIwmpzLZIktKLXAJOQHcO(string);
        String string2 = this.rHAjVyBgPhqkQKsOvJMPMYn(this.dnqxuOOQwmxxivZzrQBWydh.rHAjVyBgPhqkQKsOvJMPMYn());
        SSLContext sSLContext = SSLContext.getInstance("TLS");
        sSLContext.init(null, new TrustManager[]{new NsnRIHEihaQxXVQOAJMMZZW.QPeIwmpzLZIktKLXAJOQHcO()}, new SecureRandom());
        Client client = ClientBuilder.newBuilder().sslContext(sSLContext).hostnameVerifier((HostnameVerifier)new NsnRIHEihaQxXVQOAJMMZZW.rHAjVyBgPhqkQKsOvJMPMYn()).build();
        dXwHeIuXrPXwwYsOazDjvwg dXwHeIuXrPXwwYsOazDjvwg2 = null;
        for (int i = 0; i < 3; ++i) {
            try {
                String string3;
                WebTarget processingException = client.target("https://api.xivero.com:8097/").path("lra/v1.0/albumsView/" + this.VZagBOcdslnIaKEkojULJvx + "/");
                Invocation.Builder builder = processingException.request(new MediaType[]{MediaType.APPLICATION_JSON_TYPE});
                builder.property("jersey.config.client.connectTimeout", (Object)10000);
                builder.property("jersey.config.client.readTimeout", (Object)60000);
                builder.header("apiKey", (Object)"dU83jmI032MW#Jd93dfsuj");
                builder.header("data", (Object)this.rHAjVyBgPhqkQKsOvJMPMYn(string2));
                if (this.VmkNmvoUyyfcyaaKFyveguY != null && !this.VmkNmvoUyyfcyaaKFyveguY.isEmpty()) {
                    builder.header("recoveryKey", (Object)this.VmkNmvoUyyfcyaaKFyveguY);
                }
                if ((dXwHeIuXrPXwwYsOazDjvwg2 = (dXwHeIuXrPXwwYsOazDjvwg)new Gson().fromJson(string3 = (String)builder.post(Entity.entity((Object)"", (MediaType)MediaType.TEXT_PLAIN_TYPE), String.class), dXwHeIuXrPXwwYsOazDjvwg.class)) == null) continue;
                this.dnqxuOOQwmxxivZzrQBWydh.rHAjVyBgPhqkQKsOvJMPMYn(dXwHeIuXrPXwwYsOazDjvwg2);
                this.dnqxuOOQwmxxivZzrQBWydh.rHAjVyBgPhqkQKsOvJMPMYn(!dXwHeIuXrPXwwYsOazDjvwg2.rHAjVyBgPhqkQKsOvJMPMYn());
                string = "Upload finished";
                break;
            }
            catch (ProcessingException processingException) {
                string = "Upload timeout";
            }
        }
        if (this.dnqxuOOQwmxxivZzrQBWydh.JSuXbPLjXcQLpTiButqPpoI().rHAjVyBgPhqkQKsOvJMPMYn()) {
            string = "Metadata not valid";
        }
        for (nszTqDkxYiaGpuKyqsPMpEP nszTqDkxYiaGpuKyqsPMpEP2 : this.dnqxuOOQwmxxivZzrQBWydh.VZagBOcdslnIaKEkojULJvx()) {
            nszTqDkxYiaGpuKyqsPMpEP2.rHAjVyBgPhqkQKsOvJMPMYn(string);
        }
        client.close();
        this.dnqxuOOQwmxxivZzrQBWydh.QPeIwmpzLZIktKLXAJOQHcO(false);
        return dXwHeIuXrPXwwYsOazDjvwg2;
    }

    private String rHAjVyBgPhqkQKsOvJMPMYn(fikLFfybOLBBPFzDSaJuDxU fikLFfybOLBBPFzDSaJuDxU2) {
        return new Gson().toJson((Object)new fkymSnbJojnjWTHxKogeOzr(fikLFfybOLBBPFzDSaJuDxU2));
    }

    private void QPeIwmpzLZIktKLXAJOQHcO(String string) {
        for (nszTqDkxYiaGpuKyqsPMpEP nszTqDkxYiaGpuKyqsPMpEP2 : this.dnqxuOOQwmxxivZzrQBWydh.VZagBOcdslnIaKEkojULJvx()) {
            nszTqDkxYiaGpuKyqsPMpEP2.rHAjVyBgPhqkQKsOvJMPMYn(string);
        }
    }

    @Override
    public /* synthetic */ Object call() throws Exception {
        return this.rHAjVyBgPhqkQKsOvJMPMYn();
    }
}

