/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.JBphLoDiqESKYDzcdAUENWI;
import sdfgjkljljoftrytrszgijpokjprs.KTkvbLlxuYGcvSGyJtmnFsX;

public interface ExyuhjCFdYRxawtXrlsOAtI {
    public void rHAjVyBgPhqkQKsOvJMPMYn(KTkvbLlxuYGcvSGyJtmnFsX var1);

    public void rHAjVyBgPhqkQKsOvJMPMYn(JBphLoDiqESKYDzcdAUENWI var1);
}

