/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JComponent;
import javax.swing.SwingUtilities;

public class gXcEagWZXJBjeouQCslyrnT
extends JComponent
implements Runnable {
    private final int rHAjVyBgPhqkQKsOvJMPMYn = 120;
    private double QPeIwmpzLZIktKLXAJOQHcO = 33.3333333333;
    private double[] JSuXbPLjXcQLpTiButqPpoI = new double[121];
    private final int iwitQCGCnkthNoQBBlYaPUM = 50;
    private final int dnqxuOOQwmxxivZzrQBWydh = 440;

    public void rHAjVyBgPhqkQKsOvJMPMYn(double[] dArray) {
        this.JSuXbPLjXcQLpTiButqPpoI = dArray;
        this.rHAjVyBgPhqkQKsOvJMPMYn();
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(double d) {
        this.QPeIwmpzLZIktKLXAJOQHcO = d;
        this.rHAjVyBgPhqkQKsOvJMPMYn();
    }

    @Override
    public void paintComponent(Graphics graphics) {
        int n;
        int n2;
        Graphics2D graphics2D = (Graphics2D)graphics;
        FontMetrics fontMetrics = graphics2D.getFontMetrics();
        int n3 = 0;
        for (n2 = 1; n2 <= 120; ++n2) {
            n = (int)Math.round(240.0 - this.JSuXbPLjXcQLpTiButqPpoI[n2] * 200.0);
            if (this.JSuXbPLjXcQLpTiButqPpoI[n2] > 0.0) {
                graphics2D.setColor(Color.decode("#FFA100"));
            } else {
                graphics2D.setColor(Color.decode("#00F1FF"));
            }
            if (Math.abs(this.JSuXbPLjXcQLpTiButqPpoI[n2]) == 1.01) {
                graphics2D.setColor(Color.decode("#FF0000"));
            }
            for (int i = 0; i < 4; ++i) {
                graphics2D.drawLine(50 + i + n3 + n2, 240, 50 + i + n3 + n2, n);
            }
            n3 += 4;
        }
        graphics2D.setColor(Color.decode("#000000"));
        String string = "%";
        graphics2D.drawString(string, 50 - fontMetrics.stringWidth(string) / 2, 15);
        graphics2D.drawLine(50, 450, 50, 20);
        graphics2D.drawLine(45, 30, 50, 20);
        graphics2D.drawLine(55, 30, 50, 20);
        for (n2 = -100; n2 <= 100; n2 += 25) {
            n = 240 - 2 * n2;
            graphics2D.drawLine(45, n, 50, n);
            string = String.valueOf((double)n2 / 100.0);
            graphics2D.drawString(string, 40 - fontMetrics.stringWidth(string), n + 5);
        }
        for (n2 = -100; n2 <= 100; n2 += 25) {
            n = 240 - 2 * n2;
            if (Math.abs(n2) == 25) {
                graphics2D.setColor(Color.decode("#FF0000"));
            } else {
                graphics2D.setColor(Color.decode("#DDDDDD"));
            }
            if (n2 == 0) continue;
            graphics2D.drawLine(51, n, 650, n);
        }
        graphics2D.setColor(Color.decode("#000000"));
        graphics2D.drawLine(50, 240, 651, 240);
        for (n2 = 1; n2 <= 11; ++n2) {
            int n4 = 50 + n2 * 5 * 10;
            graphics2D.drawLine(n4, 240, n4, 245);
            string = String.valueOf(n2 * 10) + "s";
            graphics2D.drawString(string, n4 - fontMetrics.stringWidth(string) / 2, 260);
        }
        graphics2D.setColor(Color.decode("#000000"));
        string = "RPM";
        graphics2D.drawString(string, 651 - fontMetrics.stringWidth(string) / 2, 15);
        graphics2D.drawLine(651, 450, 651, 20);
        graphics2D.drawLine(646, 30, 651, 20);
        graphics2D.drawLine(656, 30, 651, 20);
        for (n2 = -100; n2 <= 100; n2 += 25) {
            n = 240 - 2 * n2;
            graphics2D.drawLine(651, n, 656, n);
            string = String.valueOf((double)Math.round(((double)n2 / 10000.0 * this.QPeIwmpzLZIktKLXAJOQHcO + this.QPeIwmpzLZIktKLXAJOQHcO) * 1000.0) / 1000.0);
            graphics2D.drawString(string, 661, n + 5);
        }
    }

    private void rHAjVyBgPhqkQKsOvJMPMYn() {
        SwingUtilities.invokeLater(new Runnable(){

            @Override
            public void run() {
                gXcEagWZXJBjeouQCslyrnT.this.repaint();
            }
        });
    }

    @Override
    public void run() {
    }
}

