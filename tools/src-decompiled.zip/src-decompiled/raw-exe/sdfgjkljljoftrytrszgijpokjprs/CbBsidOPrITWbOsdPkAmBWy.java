/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.io.File;
import java.nio.file.Path;

public interface CbBsidOPrITWbOsdPkAmBWy<T> {
    public T QPeIwmpzLZIktKLXAJOQHcO(File var1, Path var2) throws Exception;
}

