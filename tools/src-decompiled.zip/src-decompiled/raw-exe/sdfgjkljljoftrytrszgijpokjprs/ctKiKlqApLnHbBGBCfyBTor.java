/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.AbkRNvAOeWIbEeMzsGvXdIr;

class ctKiKlqApLnHbBGBCfyBTor
extends AbkRNvAOeWIbEeMzsGvXdIr {
    ctKiKlqApLnHbBGBCfyBTor() {
        super(0);
    }
}

