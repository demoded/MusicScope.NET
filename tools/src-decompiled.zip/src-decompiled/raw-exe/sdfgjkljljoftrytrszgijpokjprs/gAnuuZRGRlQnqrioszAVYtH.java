/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

public interface gAnuuZRGRlQnqrioszAVYtH {
    public void rHAjVyBgPhqkQKsOvJMPMYn(int var1, int var2);
}

