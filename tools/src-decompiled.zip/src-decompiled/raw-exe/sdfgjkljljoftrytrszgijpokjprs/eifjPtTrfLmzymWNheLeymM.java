/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import sdfgjkljljoftrytrszgijpokjprs.KFVWmcqOBgYFxPgeswapvPe;
import sdfgjkljljoftrytrszgijpokjprs.LSAvoQmvVEpPeurnfJpgDzj;
import sdfgjkljljoftrytrszgijpokjprs.tSwCDjQKHwQVvbvetpZIATg;

public class eifjPtTrfLmzymWNheLeymM
implements Runnable {
    private static final int rHAjVyBgPhqkQKsOvJMPMYn = 1000 * KFVWmcqOBgYFxPgeswapvPe.VZagBOcdslnIaKEkojULJvx.QPeIwmpzLZIktKLXAJOQHcO();
    private final Socket QPeIwmpzLZIktKLXAJOQHcO;
    private final BufferedInputStream JSuXbPLjXcQLpTiButqPpoI;
    private final LSAvoQmvVEpPeurnfJpgDzj iwitQCGCnkthNoQBBlYaPUM;
    private final tSwCDjQKHwQVvbvetpZIATg dnqxuOOQwmxxivZzrQBWydh;
    private char VZagBOcdslnIaKEkojULJvx;
    private int VmkNmvoUyyfcyaaKFyveguY;
    private final byte[] YGjBevanihqaxYKnUNtrNeA = new byte[rHAjVyBgPhqkQKsOvJMPMYn];
    private final byte[] wunjGuaHWPKejzkQKUJfPKe = new byte[5];
    private ByteBuffer NuCoRkdmXmpraThwzNAiTcw;

    public eifjPtTrfLmzymWNheLeymM(Socket socket, LSAvoQmvVEpPeurnfJpgDzj lSAvoQmvVEpPeurnfJpgDzj, tSwCDjQKHwQVvbvetpZIATg tSwCDjQKHwQVvbvetpZIATg2) throws IOException {
        this.QPeIwmpzLZIktKLXAJOQHcO = socket;
        this.iwitQCGCnkthNoQBBlYaPUM = lSAvoQmvVEpPeurnfJpgDzj;
        this.dnqxuOOQwmxxivZzrQBWydh = tSwCDjQKHwQVvbvetpZIATg2;
        this.JSuXbPLjXcQLpTiButqPpoI = new BufferedInputStream(socket.getInputStream());
    }

    @Override
    public void run() {
        try {
            while (!this.QPeIwmpzLZIktKLXAJOQHcO.isClosed()) {
                Thread.currentThread().setPriority(10);
                this.JSuXbPLjXcQLpTiButqPpoI.read(this.wunjGuaHWPKejzkQKUJfPKe, 0, 1);
                this.JSuXbPLjXcQLpTiButqPpoI.read(this.wunjGuaHWPKejzkQKUJfPKe, 1, 4);
                this.NuCoRkdmXmpraThwzNAiTcw = ByteBuffer.wrap(this.wunjGuaHWPKejzkQKUJfPKe);
                this.VZagBOcdslnIaKEkojULJvx = (char)this.NuCoRkdmXmpraThwzNAiTcw.order(ByteOrder.LITTLE_ENDIAN).get();
                this.VmkNmvoUyyfcyaaKFyveguY = this.NuCoRkdmXmpraThwzNAiTcw.order(ByteOrder.LITTLE_ENDIAN).getInt();
                if (this.VZagBOcdslnIaKEkojULJvx == 'E') {
                    this.JSuXbPLjXcQLpTiButqPpoI.close();
                    this.QPeIwmpzLZIktKLXAJOQHcO.close();
                    if (this.dnqxuOOQwmxxivZzrQBWydh == null) continue;
                    this.dnqxuOOQwmxxivZzrQBWydh.rHAjVyBgPhqkQKsOvJMPMYn();
                    continue;
                }
                int n = this.VmkNmvoUyyfcyaaKFyveguY = this.VmkNmvoUyyfcyaaKFyveguY < 0 ? 1 : this.VmkNmvoUyyfcyaaKFyveguY;
                while (this.VmkNmvoUyyfcyaaKFyveguY > 0) {
                    int n2 = this.JSuXbPLjXcQLpTiButqPpoI.read(this.YGjBevanihqaxYKnUNtrNeA, 0, this.VmkNmvoUyyfcyaaKFyveguY > rHAjVyBgPhqkQKsOvJMPMYn ? rHAjVyBgPhqkQKsOvJMPMYn : this.VmkNmvoUyyfcyaaKFyveguY);
                    if (n2 <= 0) continue;
                    this.VmkNmvoUyyfcyaaKFyveguY -= n2;
                    if (this.iwitQCGCnkthNoQBBlYaPUM == null) continue;
                    switch (this.VZagBOcdslnIaKEkojULJvx) {
                        case 'I': {
                            this.NuCoRkdmXmpraThwzNAiTcw = ByteBuffer.wrap(this.YGjBevanihqaxYKnUNtrNeA, 0, n2);
                            this.iwitQCGCnkthNoQBBlYaPUM.rHAjVyBgPhqkQKsOvJMPMYn(this.NuCoRkdmXmpraThwzNAiTcw.order(ByteOrder.LITTLE_ENDIAN).getDouble());
                            this.NuCoRkdmXmpraThwzNAiTcw.clear();
                            this.NuCoRkdmXmpraThwzNAiTcw = null;
                            break;
                        }
                        case 'S': {
                            this.iwitQCGCnkthNoQBBlYaPUM.rHAjVyBgPhqkQKsOvJMPMYn(Arrays.copyOfRange(this.YGjBevanihqaxYKnUNtrNeA, 0, n2));
                        }
                    }
                }
            }
        }
        catch (IOException iOException) {
        }
        finally {
            try {
                this.JSuXbPLjXcQLpTiButqPpoI.close();
                this.QPeIwmpzLZIktKLXAJOQHcO.close();
                this.iwitQCGCnkthNoQBBlYaPUM.rHAjVyBgPhqkQKsOvJMPMYn();
            }
            catch (IOException iOException) {}
        }
    }
}

