/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

public class gTVlynIXxRUCYNEJFcwJfzY
extends Exception {
    public gTVlynIXxRUCYNEJFcwJfzY() {
    }

    public gTVlynIXxRUCYNEJFcwJfzY(String string) {
        super(string);
    }
}

