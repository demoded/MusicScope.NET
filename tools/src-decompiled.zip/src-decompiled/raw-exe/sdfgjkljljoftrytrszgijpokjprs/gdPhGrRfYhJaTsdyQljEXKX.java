/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.BrqrCQbbknwtebNWiMmRwch;
import sdfgjkljljoftrytrszgijpokjprs.FLTjkCbqdFcYQIXMwzSzQor;
import sdfgjkljljoftrytrszgijpokjprs.HAfXhvYubJkskjSMlFLLdgY;
import sdfgjkljljoftrytrszgijpokjprs.KXzLGKHeRupGOUCLSJARWrw;
import sdfgjkljljoftrytrszgijpokjprs.LwMnHLCbJlVyuQgcwIapPMa;
import sdfgjkljljoftrytrszgijpokjprs.PYJBgzPCdrZnekQfrnwIPxJ;
import sdfgjkljljoftrytrszgijpokjprs.ZjoyaRSokkGYDwXHPKTBIiX;
import sdfgjkljljoftrytrszgijpokjprs.ZvOTVUaKFTNpNSbbMYZfoXf;
import sdfgjkljljoftrytrszgijpokjprs.cJizbPrgAISXyzXrgujHPeB;
import sdfgjkljljoftrytrszgijpokjprs.lXCOGwZXVelwEKHMMPwpSAO;
import sdfgjkljljoftrytrszgijpokjprs.rLTzSWcNicpRLKKlkUbbehc;
import sdfgjkljljoftrytrszgijpokjprs.uzZiPWteQonnOTzvIEnZmpw;

@BrqrCQbbknwtebNWiMmRwch(rHAjVyBgPhqkQKsOvJMPMYn=cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn.StereoMeter)
public class gdPhGrRfYhJaTsdyQljEXKX
extends LwMnHLCbJlVyuQgcwIapPMa<FLTjkCbqdFcYQIXMwzSzQor>
implements HAfXhvYubJkskjSMlFLLdgY,
KXzLGKHeRupGOUCLSJARWrw,
rLTzSWcNicpRLKKlkUbbehc,
uzZiPWteQonnOTzvIEnZmpw {
    private static final double rHAjVyBgPhqkQKsOvJMPMYn = 1.0 / Math.sqrt(2.0);
    private static final double[] QPeIwmpzLZIktKLXAJOQHcO = new double[5000];
    private static final double[] JSuXbPLjXcQLpTiButqPpoI = new double[5000];
    private static final double[] iwitQCGCnkthNoQBBlYaPUM = new double[5000];
    private final double[] dnqxuOOQwmxxivZzrQBWydh = new double[5000];
    private final double[] VZagBOcdslnIaKEkojULJvx = new double[5000];
    private final double[] VmkNmvoUyyfcyaaKFyveguY = new double[100];
    private final double[] YGjBevanihqaxYKnUNtrNeA = new double[100];
    private static int wunjGuaHWPKejzkQKUJfPKe = 0;
    private static int NuCoRkdmXmpraThwzNAiTcw;
    private static int OrmpCzNZzYDlbDZDBXyofLf;
    private static double ibbBhgWhrhhiOLwDlcriPhb;

    public gdPhGrRfYhJaTsdyQljEXKX() {
        this.VZagBOcdslnIaKEkojULJvx();
    }

    private void VZagBOcdslnIaKEkojULJvx() {
        int n;
        ibbBhgWhrhhiOLwDlcriPhb = 0.0;
        wunjGuaHWPKejzkQKUJfPKe = 0;
        for (n = 0; n < 5000; ++n) {
            gdPhGrRfYhJaTsdyQljEXKX.JSuXbPLjXcQLpTiButqPpoI[n] = 0.0;
            gdPhGrRfYhJaTsdyQljEXKX.QPeIwmpzLZIktKLXAJOQHcO[n] = 0.0;
            this.VZagBOcdslnIaKEkojULJvx[n] = 0.0;
            this.dnqxuOOQwmxxivZzrQBWydh[n] = 0.0;
        }
        for (n = 0; n < 100; ++n) {
            this.YGjBevanihqaxYKnUNtrNeA[n] = 0.0;
            this.VmkNmvoUyyfcyaaKFyveguY[n] = 0.0;
        }
    }

    public void JSuXbPLjXcQLpTiButqPpoI() {
        this.VZagBOcdslnIaKEkojULJvx();
    }

    public FLTjkCbqdFcYQIXMwzSzQor dnqxuOOQwmxxivZzrQBWydh() throws Exception {
        int n;
        Thread.currentThread().setName(this.getClass().getSimpleName());
        double d = 0.0;
        double d2 = 0.0;
        double d3 = 0.0;
        PYJBgzPCdrZnekQfrnwIPxJ pYJBgzPCdrZnekQfrnwIPxJ = this.rHAjVyBgPhqkQKsOvJMPMYn();
        ZvOTVUaKFTNpNSbbMYZfoXf zvOTVUaKFTNpNSbbMYZfoXf = pYJBgzPCdrZnekQfrnwIPxJ.JSuXbPLjXcQLpTiButqPpoI();
        if (zvOTVUaKFTNpNSbbMYZfoXf.iwitQCGCnkthNoQBBlYaPUM() < 500) {
            return null;
        }
        int n2 = zvOTVUaKFTNpNSbbMYZfoXf.JSuXbPLjXcQLpTiButqPpoI().length;
        int n3 = n2 / 500;
        for (n = 0; n < n2; n += n3) {
            this.dnqxuOOQwmxxivZzrQBWydh[gdPhGrRfYhJaTsdyQljEXKX.wunjGuaHWPKejzkQKUJfPKe] = zvOTVUaKFTNpNSbbMYZfoXf.JSuXbPLjXcQLpTiButqPpoI()[n];
            this.VZagBOcdslnIaKEkojULJvx[gdPhGrRfYhJaTsdyQljEXKX.wunjGuaHWPKejzkQKUJfPKe] = zvOTVUaKFTNpNSbbMYZfoXf.QPeIwmpzLZIktKLXAJOQHcO()[n];
            if (++wunjGuaHWPKejzkQKUJfPKe < 5000) continue;
            wunjGuaHWPKejzkQKUJfPKe = 0;
        }
        NuCoRkdmXmpraThwzNAiTcw = wunjGuaHWPKejzkQKUJfPKe;
        double d4 = 2.0E-4;
        double d5 = 0.0;
        for (n = 0; n < 5000; ++n) {
            gdPhGrRfYhJaTsdyQljEXKX.QPeIwmpzLZIktKLXAJOQHcO[n] = -rHAjVyBgPhqkQKsOvJMPMYn * (this.dnqxuOOQwmxxivZzrQBWydh[NuCoRkdmXmpraThwzNAiTcw] - this.VZagBOcdslnIaKEkojULJvx[NuCoRkdmXmpraThwzNAiTcw]);
            gdPhGrRfYhJaTsdyQljEXKX.JSuXbPLjXcQLpTiButqPpoI[n] = -rHAjVyBgPhqkQKsOvJMPMYn * (this.dnqxuOOQwmxxivZzrQBWydh[NuCoRkdmXmpraThwzNAiTcw] + this.VZagBOcdslnIaKEkojULJvx[NuCoRkdmXmpraThwzNAiTcw]);
            if (++NuCoRkdmXmpraThwzNAiTcw >= 5000) {
                NuCoRkdmXmpraThwzNAiTcw = 0;
            }
            gdPhGrRfYhJaTsdyQljEXKX.iwitQCGCnkthNoQBBlYaPUM[n] = d5 += d4;
        }
        double d6 = 0.0;
        for (n = 0; n < n2; ++n) {
            d = zvOTVUaKFTNpNSbbMYZfoXf.JSuXbPLjXcQLpTiButqPpoI()[n];
            d2 = zvOTVUaKFTNpNSbbMYZfoXf.QPeIwmpzLZIktKLXAJOQHcO()[n];
            if (Math.abs(d2) > Math.abs(d)) {
                d6 += 1.0;
            } else if (Math.abs(d2) < Math.abs(d)) {
                d6 -= 1.0;
            }
            if (d > 0.0) {
                d = 1.0;
            } else if (d < 0.0) {
                d = -1.0;
            }
            if (d2 > 0.0) {
                d2 = 1.0;
            } else if (d2 < 0.0) {
                d2 = -1.0;
            }
            d3 += d * d2;
        }
        d3 /= (double)n2;
        this.VmkNmvoUyyfcyaaKFyveguY[gdPhGrRfYhJaTsdyQljEXKX.OrmpCzNZzYDlbDZDBXyofLf] = d6 /= (double)n2;
        if (++OrmpCzNZzYDlbDZDBXyofLf >= 100) {
            OrmpCzNZzYDlbDZDBXyofLf = 0;
        }
        int n4 = OrmpCzNZzYDlbDZDBXyofLf;
        for (n = 0; n < 100; ++n) {
            this.YGjBevanihqaxYKnUNtrNeA[n] = this.VmkNmvoUyyfcyaaKFyveguY[n4];
            if (++n4 < 100) continue;
            n4 = 0;
        }
        if (ibbBhgWhrhhiOLwDlcriPhb < d3) {
            ibbBhgWhrhhiOLwDlcriPhb += 0.004;
        }
        if (ibbBhgWhrhhiOLwDlcriPhb > d3) {
            ibbBhgWhrhhiOLwDlcriPhb -= 0.004;
        }
        if (ibbBhgWhrhhiOLwDlcriPhb < -1.0) {
            ibbBhgWhrhhiOLwDlcriPhb = -1.0;
        }
        if (ibbBhgWhrhhiOLwDlcriPhb > 1.0) {
            ibbBhgWhrhhiOLwDlcriPhb = 1.0;
        }
        FLTjkCbqdFcYQIXMwzSzQor fLTjkCbqdFcYQIXMwzSzQor = new FLTjkCbqdFcYQIXMwzSzQor(5000, iwitQCGCnkthNoQBBlYaPUM, QPeIwmpzLZIktKLXAJOQHcO, JSuXbPLjXcQLpTiButqPpoI, ibbBhgWhrhhiOLwDlcriPhb, this.YGjBevanihqaxYKnUNtrNeA);
        return fLTjkCbqdFcYQIXMwzSzQor;
    }

    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(String string) {
        this.VZagBOcdslnIaKEkojULJvx();
    }

    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(ZjoyaRSokkGYDwXHPKTBIiX zjoyaRSokkGYDwXHPKTBIiX) {
        if (zjoyaRSokkGYDwXHPKTBIiX == ZjoyaRSokkGYDwXHPKTBIiX.iwitQCGCnkthNoQBBlYaPUM) {
            this.JSuXbPLjXcQLpTiButqPpoI();
        }
    }

    @Override
    public boolean rHAjVyBgPhqkQKsOvJMPMYn(lXCOGwZXVelwEKHMMPwpSAO lXCOGwZXVelwEKHMMPwpSAO2, Object object) {
        switch (lXCOGwZXVelwEKHMMPwpSAO2) {
            case dnqxuOOQwmxxivZzrQBWydh: {
                this.VZagBOcdslnIaKEkojULJvx();
            }
        }
        return true;
    }

    @Override
    public void iwitQCGCnkthNoQBBlYaPUM() {
        this.VZagBOcdslnIaKEkojULJvx();
    }

    @Override
    public /* synthetic */ Object QPeIwmpzLZIktKLXAJOQHcO() throws Exception {
        return this.dnqxuOOQwmxxivZzrQBWydh();
    }

    static {
        OrmpCzNZzYDlbDZDBXyofLf = 0;
        ibbBhgWhrhhiOLwDlcriPhb = 0.0;
    }
}

