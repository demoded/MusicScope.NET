/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

class gLHqHFGBEIDXbcqrsZzduVF {
    private int rHAjVyBgPhqkQKsOvJMPMYn = 0;
    private int QPeIwmpzLZIktKLXAJOQHcO = 0;

    gLHqHFGBEIDXbcqrsZzduVF() {
    }

    public int rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(int n) {
        this.rHAjVyBgPhqkQKsOvJMPMYn = n;
    }

    public int QPeIwmpzLZIktKLXAJOQHcO() {
        return this.QPeIwmpzLZIktKLXAJOQHcO;
    }

    public void QPeIwmpzLZIktKLXAJOQHcO(int n) {
        this.QPeIwmpzLZIktKLXAJOQHcO = n;
    }
}

