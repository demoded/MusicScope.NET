/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.util.HashSet;
import sdfgjkljljoftrytrszgijpokjprs.ExyuhjCFdYRxawtXrlsOAtI;
import sdfgjkljljoftrytrszgijpokjprs.JBphLoDiqESKYDzcdAUENWI;
import sdfgjkljljoftrytrszgijpokjprs.KTkvbLlxuYGcvSGyJtmnFsX;

class fsCnlqKXkxhMuTxKNEytqlv
implements ExyuhjCFdYRxawtXrlsOAtI {
    private final HashSet rHAjVyBgPhqkQKsOvJMPMYn = new HashSet();

    fsCnlqKXkxhMuTxKNEytqlv() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void rHAjVyBgPhqkQKsOvJMPMYn(ExyuhjCFdYRxawtXrlsOAtI exyuhjCFdYRxawtXrlsOAtI) {
        HashSet hashSet = this.rHAjVyBgPhqkQKsOvJMPMYn;
        synchronized (hashSet) {
            this.rHAjVyBgPhqkQKsOvJMPMYn.add(exyuhjCFdYRxawtXrlsOAtI);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(KTkvbLlxuYGcvSGyJtmnFsX kTkvbLlxuYGcvSGyJtmnFsX) {
        HashSet hashSet = this.rHAjVyBgPhqkQKsOvJMPMYn;
        synchronized (hashSet) {
            for (ExyuhjCFdYRxawtXrlsOAtI exyuhjCFdYRxawtXrlsOAtI : this.rHAjVyBgPhqkQKsOvJMPMYn) {
                exyuhjCFdYRxawtXrlsOAtI.rHAjVyBgPhqkQKsOvJMPMYn(kTkvbLlxuYGcvSGyJtmnFsX);
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(JBphLoDiqESKYDzcdAUENWI jBphLoDiqESKYDzcdAUENWI) {
        HashSet hashSet = this.rHAjVyBgPhqkQKsOvJMPMYn;
        synchronized (hashSet) {
            for (ExyuhjCFdYRxawtXrlsOAtI exyuhjCFdYRxawtXrlsOAtI : this.rHAjVyBgPhqkQKsOvJMPMYn) {
                exyuhjCFdYRxawtXrlsOAtI.rHAjVyBgPhqkQKsOvJMPMYn(jBphLoDiqESKYDzcdAUENWI);
            }
        }
    }

    public boolean rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn.size() == 0;
    }
}

