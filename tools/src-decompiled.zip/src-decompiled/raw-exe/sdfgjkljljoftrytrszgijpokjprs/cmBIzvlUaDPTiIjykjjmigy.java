/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.gLHqHFGBEIDXbcqrsZzduVF;

class cmBIzvlUaDPTiIjykjjmigy {
    private byte[] rHAjVyBgPhqkQKsOvJMPMYn;
    private int QPeIwmpzLZIktKLXAJOQHcO = 0;
    private int JSuXbPLjXcQLpTiButqPpoI = 0;
    private int iwitQCGCnkthNoQBBlYaPUM = 0;
    private int dnqxuOOQwmxxivZzrQBWydh = 0;
    private int VZagBOcdslnIaKEkojULJvx = 0;
    private gLHqHFGBEIDXbcqrsZzduVF VmkNmvoUyyfcyaaKFyveguY = new gLHqHFGBEIDXbcqrsZzduVF();
    private int YGjBevanihqaxYKnUNtrNeA = 16384;
    private int[] wunjGuaHWPKejzkQKUJfPKe = new int[this.YGjBevanihqaxYKnUNtrNeA];
    private int[] NuCoRkdmXmpraThwzNAiTcw = new int[this.YGjBevanihqaxYKnUNtrNeA];
    private int[] OrmpCzNZzYDlbDZDBXyofLf = new int[this.YGjBevanihqaxYKnUNtrNeA];
    private int[] ibbBhgWhrhhiOLwDlcriPhb = new int[this.YGjBevanihqaxYKnUNtrNeA];
    private int[] kVXnygMrAwyMajIgLatcyWS = new int[this.YGjBevanihqaxYKnUNtrNeA];
    private int[] vJgxuXjYdOvTUFZsFThavLL = new int[this.YGjBevanihqaxYKnUNtrNeA];
    private int FoVkhFqKjpvomrYQnnVFKwY = 0;
    private int kMqExmRlFLPTFqBDauCBKYL = 0;
    private int uAGKHXCiDSbltWOPIpXUgwC = 0;
    private int TNdBwPzcCrGifNBGlgVkPGL = 0;
    private int CWUsTkhDhNSqiWmIUfrczRE = 0;
    private int XphHMDaiRLyTnLXiOVlLPqZ = 0;
    private int cmBIzvlUaDPTiIjykjjmigy = 0;
    private int NwteqrdXWwWpaoJmiBDNxxz = 0;
    private int SYnuCfTgzCxensnEBdDedFe = 0;
    private int ajlSZBxlJSwYUTeUsFfhumH = 0;
    private int TTvVyJBikEjkvfEQPPobmUz = 0;
    private int[] IiqlRFfWYxYaAobCQvdRFEl = new int[1024];
    private int[] gLHqHFGBEIDXbcqrsZzduVF = new int[1024];
    private int[] xurJiSGFDQVeEtISoLSazWS = new int[1024];

    cmBIzvlUaDPTiIjykjjmigy() {
    }

    public byte[] rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(byte[] byArray) {
        this.rHAjVyBgPhqkQKsOvJMPMYn = byArray;
    }

    public int QPeIwmpzLZIktKLXAJOQHcO() {
        return this.QPeIwmpzLZIktKLXAJOQHcO;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(int n) {
        this.QPeIwmpzLZIktKLXAJOQHcO = n;
    }

    public int JSuXbPLjXcQLpTiButqPpoI() {
        return this.JSuXbPLjXcQLpTiButqPpoI;
    }

    public void QPeIwmpzLZIktKLXAJOQHcO(int n) {
        this.JSuXbPLjXcQLpTiButqPpoI = n;
    }

    public void JSuXbPLjXcQLpTiButqPpoI(int n) {
        this.iwitQCGCnkthNoQBBlYaPUM = n;
    }

    public int iwitQCGCnkthNoQBBlYaPUM() {
        return this.dnqxuOOQwmxxivZzrQBWydh;
    }

    public void iwitQCGCnkthNoQBBlYaPUM(int n) {
        this.dnqxuOOQwmxxivZzrQBWydh = n;
    }

    public int dnqxuOOQwmxxivZzrQBWydh() {
        return this.VZagBOcdslnIaKEkojULJvx;
    }

    public void dnqxuOOQwmxxivZzrQBWydh(int n) {
        this.VZagBOcdslnIaKEkojULJvx = n;
    }

    public gLHqHFGBEIDXbcqrsZzduVF VZagBOcdslnIaKEkojULJvx() {
        return this.VmkNmvoUyyfcyaaKFyveguY;
    }

    public int[] VmkNmvoUyyfcyaaKFyveguY() {
        return this.wunjGuaHWPKejzkQKUJfPKe;
    }

    public int[] YGjBevanihqaxYKnUNtrNeA() {
        return this.NuCoRkdmXmpraThwzNAiTcw;
    }

    public int[] wunjGuaHWPKejzkQKUJfPKe() {
        return this.OrmpCzNZzYDlbDZDBXyofLf;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(int[] nArray) {
        this.OrmpCzNZzYDlbDZDBXyofLf = nArray;
    }

    public int[] NuCoRkdmXmpraThwzNAiTcw() {
        return this.ibbBhgWhrhhiOLwDlcriPhb;
    }

    public void QPeIwmpzLZIktKLXAJOQHcO(int[] nArray) {
        this.ibbBhgWhrhhiOLwDlcriPhb = nArray;
    }

    public int[] OrmpCzNZzYDlbDZDBXyofLf() {
        return this.kVXnygMrAwyMajIgLatcyWS;
    }

    public int[] ibbBhgWhrhhiOLwDlcriPhb() {
        return this.vJgxuXjYdOvTUFZsFThavLL;
    }

    public int kVXnygMrAwyMajIgLatcyWS() {
        return this.FoVkhFqKjpvomrYQnnVFKwY;
    }

    public void VZagBOcdslnIaKEkojULJvx(int n) {
        this.FoVkhFqKjpvomrYQnnVFKwY = n;
    }

    public void VmkNmvoUyyfcyaaKFyveguY(int n) {
        this.kMqExmRlFLPTFqBDauCBKYL = n;
    }

    public int vJgxuXjYdOvTUFZsFThavLL() {
        return this.uAGKHXCiDSbltWOPIpXUgwC;
    }

    public void YGjBevanihqaxYKnUNtrNeA(int n) {
        this.uAGKHXCiDSbltWOPIpXUgwC = n;
    }

    public int FoVkhFqKjpvomrYQnnVFKwY() {
        return this.TNdBwPzcCrGifNBGlgVkPGL;
    }

    public void wunjGuaHWPKejzkQKUJfPKe(int n) {
        this.TNdBwPzcCrGifNBGlgVkPGL = n;
    }

    public int kMqExmRlFLPTFqBDauCBKYL() {
        return this.CWUsTkhDhNSqiWmIUfrczRE;
    }

    public void NuCoRkdmXmpraThwzNAiTcw(int n) {
        this.CWUsTkhDhNSqiWmIUfrczRE = n;
    }

    public int uAGKHXCiDSbltWOPIpXUgwC() {
        return this.XphHMDaiRLyTnLXiOVlLPqZ;
    }

    public void OrmpCzNZzYDlbDZDBXyofLf(int n) {
        this.XphHMDaiRLyTnLXiOVlLPqZ = n;
    }

    public void ibbBhgWhrhhiOLwDlcriPhb(int n) {
        this.cmBIzvlUaDPTiIjykjjmigy = n;
    }

    public void kVXnygMrAwyMajIgLatcyWS(int n) {
        this.NwteqrdXWwWpaoJmiBDNxxz = n;
    }

    public void vJgxuXjYdOvTUFZsFThavLL(int n) {
        this.SYnuCfTgzCxensnEBdDedFe = n;
    }

    public void FoVkhFqKjpvomrYQnnVFKwY(int n) {
        this.ajlSZBxlJSwYUTeUsFfhumH = n;
    }

    public void kMqExmRlFLPTFqBDauCBKYL(int n) {
        this.TTvVyJBikEjkvfEQPPobmUz = n;
    }

    public int[] TNdBwPzcCrGifNBGlgVkPGL() {
        return this.IiqlRFfWYxYaAobCQvdRFEl;
    }

    public int[] CWUsTkhDhNSqiWmIUfrczRE() {
        return this.gLHqHFGBEIDXbcqrsZzduVF;
    }

    public int[] XphHMDaiRLyTnLXiOVlLPqZ() {
        return this.xurJiSGFDQVeEtISoLSazWS;
    }
}

