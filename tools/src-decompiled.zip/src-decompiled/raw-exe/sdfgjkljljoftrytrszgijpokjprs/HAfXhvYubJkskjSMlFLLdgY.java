/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.ZjoyaRSokkGYDwXHPKTBIiX;

public interface HAfXhvYubJkskjSMlFLLdgY {
    public void rHAjVyBgPhqkQKsOvJMPMYn(ZjoyaRSokkGYDwXHPKTBIiX var1);
}

