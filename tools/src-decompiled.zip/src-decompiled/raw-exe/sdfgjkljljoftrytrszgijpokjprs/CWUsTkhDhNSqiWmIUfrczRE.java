/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.NwteqrdXWwWpaoJmiBDNxxz;
import sdfgjkljljoftrytrszgijpokjprs.TTvVyJBikEjkvfEQPPobmUz;
import sdfgjkljljoftrytrszgijpokjprs.cmBIzvlUaDPTiIjykjjmigy;

public class CWUsTkhDhNSqiWmIUfrczRE {
    private TTvVyJBikEjkvfEQPPobmUz rHAjVyBgPhqkQKsOvJMPMYn;
    private cmBIzvlUaDPTiIjykjjmigy QPeIwmpzLZIktKLXAJOQHcO = new cmBIzvlUaDPTiIjykjjmigy();
    private NwteqrdXWwWpaoJmiBDNxxz JSuXbPLjXcQLpTiButqPpoI;
    private int iwitQCGCnkthNoQBBlYaPUM = 0;
    private int dnqxuOOQwmxxivZzrQBWydh;
    private boolean VZagBOcdslnIaKEkojULJvx;
    private String VmkNmvoUyyfcyaaKFyveguY = "";
    private byte[] YGjBevanihqaxYKnUNtrNeA = new byte[81920];

    public CWUsTkhDhNSqiWmIUfrczRE() {
        this.rHAjVyBgPhqkQKsOvJMPMYn = new TTvVyJBikEjkvfEQPPobmUz();
    }

    public TTvVyJBikEjkvfEQPPobmUz rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(TTvVyJBikEjkvfEQPPobmUz tTvVyJBikEjkvfEQPPobmUz) {
        this.rHAjVyBgPhqkQKsOvJMPMYn = tTvVyJBikEjkvfEQPPobmUz;
    }

    public cmBIzvlUaDPTiIjykjjmigy QPeIwmpzLZIktKLXAJOQHcO() {
        return this.QPeIwmpzLZIktKLXAJOQHcO;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(cmBIzvlUaDPTiIjykjjmigy cmBIzvlUaDPTiIjykjjmigy2) {
        this.QPeIwmpzLZIktKLXAJOQHcO = cmBIzvlUaDPTiIjykjjmigy2;
    }

    public NwteqrdXWwWpaoJmiBDNxxz JSuXbPLjXcQLpTiButqPpoI() {
        return this.JSuXbPLjXcQLpTiButqPpoI;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(NwteqrdXWwWpaoJmiBDNxxz nwteqrdXWwWpaoJmiBDNxxz) {
        this.JSuXbPLjXcQLpTiButqPpoI = nwteqrdXWwWpaoJmiBDNxxz;
    }

    public int iwitQCGCnkthNoQBBlYaPUM() {
        return this.iwitQCGCnkthNoQBBlYaPUM;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(int n) {
        this.iwitQCGCnkthNoQBBlYaPUM = n;
    }

    public int dnqxuOOQwmxxivZzrQBWydh() {
        return this.dnqxuOOQwmxxivZzrQBWydh;
    }

    public void QPeIwmpzLZIktKLXAJOQHcO(int n) {
        this.dnqxuOOQwmxxivZzrQBWydh = n;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(boolean bl) {
        this.VZagBOcdslnIaKEkojULJvx = bl;
    }

    public String VZagBOcdslnIaKEkojULJvx() {
        return this.VmkNmvoUyyfcyaaKFyveguY;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(String string) {
        this.VmkNmvoUyyfcyaaKFyveguY = string;
    }

    public byte[] VmkNmvoUyyfcyaaKFyveguY() {
        return this.YGjBevanihqaxYKnUNtrNeA;
    }
}

