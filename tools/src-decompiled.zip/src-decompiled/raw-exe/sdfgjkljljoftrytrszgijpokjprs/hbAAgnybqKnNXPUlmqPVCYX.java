/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Mixer;

public interface hbAAgnybqKnNXPUlmqPVCYX {
    public Mixer.Info QPeIwmpzLZIktKLXAJOQHcO() throws LineUnavailableException;

    public boolean JSuXbPLjXcQLpTiButqPpoI();
}

