/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

public class ajlSZBxlJSwYUTeUsFfhumH {
    private int rHAjVyBgPhqkQKsOvJMPMYn;
    private int QPeIwmpzLZIktKLXAJOQHcO;
    private int JSuXbPLjXcQLpTiButqPpoI;

    public void rHAjVyBgPhqkQKsOvJMPMYn(int n) {
        this.rHAjVyBgPhqkQKsOvJMPMYn = n;
    }

    public void QPeIwmpzLZIktKLXAJOQHcO(int n) {
        this.QPeIwmpzLZIktKLXAJOQHcO = n;
    }

    public void JSuXbPLjXcQLpTiButqPpoI(int n) {
        this.JSuXbPLjXcQLpTiButqPpoI = n;
    }
}

