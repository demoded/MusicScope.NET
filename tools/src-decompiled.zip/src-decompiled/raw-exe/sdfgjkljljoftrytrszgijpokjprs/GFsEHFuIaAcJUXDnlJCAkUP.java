/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.GFDfJcQwFRWsKLEqUzyzjuA;
import sdfgjkljljoftrytrszgijpokjprs.YRJGfWcyJJQdwqOWeghJzoA;
import sdfgjkljljoftrytrszgijpokjprs.ZBNFgJwMMkkaOLFmIBSJWbh;
import sdfgjkljljoftrytrszgijpokjprs.kNJpubvMpXzMSIqgitDifgT;
import sdfgjkljljoftrytrszgijpokjprs.tyOkjsTUxOpfPxqEnMYqtXo;

@YRJGfWcyJJQdwqOWeghJzoA
@tyOkjsTUxOpfPxqEnMYqtXo(rHAjVyBgPhqkQKsOvJMPMYn="FS  ")
public class GFsEHFuIaAcJUXDnlJCAkUP
extends kNJpubvMpXzMSIqgitDifgT {
    private int rHAjVyBgPhqkQKsOvJMPMYn;

    public int rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }

    @Override
    public long JSuXbPLjXcQLpTiButqPpoI() {
        return 4L + super.JSuXbPLjXcQLpTiButqPpoI();
    }

    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(ZBNFgJwMMkkaOLFmIBSJWbh zBNFgJwMMkkaOLFmIBSJWbh) throws GFDfJcQwFRWsKLEqUzyzjuA {
        this.rHAjVyBgPhqkQKsOvJMPMYn = -1;
        super.rHAjVyBgPhqkQKsOvJMPMYn(zBNFgJwMMkkaOLFmIBSJWbh);
        this.rHAjVyBgPhqkQKsOvJMPMYn = zBNFgJwMMkkaOLFmIBSJWbh.QPeIwmpzLZIktKLXAJOQHcO(4).getInt();
    }

    @Override
    public boolean VZagBOcdslnIaKEkojULJvx() {
        boolean bl = super.VZagBOcdslnIaKEkojULJvx();
        bl &= this.rHAjVyBgPhqkQKsOvJMPMYn > 0;
        return bl &= this.rHAjVyBgPhqkQKsOvJMPMYn % 44100 == 0;
    }
}

