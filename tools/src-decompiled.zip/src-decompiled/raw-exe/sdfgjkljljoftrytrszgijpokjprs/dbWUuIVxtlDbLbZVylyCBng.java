/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.util.HashMap;
import sdfgjkljljoftrytrszgijpokjprs.cJizbPrgAISXyzXrgujHPeB;

public class dbWUuIVxtlDbLbZVylyCBng {
    private final HashMap<cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn, Object> rHAjVyBgPhqkQKsOvJMPMYn = new HashMap(0);

    void rHAjVyBgPhqkQKsOvJMPMYn(cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn rHAjVyBgPhqkQKsOvJMPMYn2, Object object) {
        this.rHAjVyBgPhqkQKsOvJMPMYn.put(rHAjVyBgPhqkQKsOvJMPMYn2, object);
    }

    public Object rHAjVyBgPhqkQKsOvJMPMYn(cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn rHAjVyBgPhqkQKsOvJMPMYn2) {
        return this.rHAjVyBgPhqkQKsOvJMPMYn.get((Object)rHAjVyBgPhqkQKsOvJMPMYn2);
    }
}

