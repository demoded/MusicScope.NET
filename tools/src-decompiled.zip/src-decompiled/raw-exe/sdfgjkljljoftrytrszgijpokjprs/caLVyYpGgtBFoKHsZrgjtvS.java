/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import com.xivero.hraa.Main;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.LayoutStyle;
import javax.swing.OverlayLayout;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import sdfgjkljljoftrytrszgijpokjprs.JdVJXxffjyJZAkqbiFsaDCr;
import sdfgjkljljoftrytrszgijpokjprs.YzXXpcCCVJkKMcoHoACbjGG;
import sdfgjkljljoftrytrszgijpokjprs.hdtwbvZSeJsEBjhsjhkgMoS;
import sdfgjkljljoftrytrszgijpokjprs.kTbZASHDopQBPRkAiVONWbv;

public class caLVyYpGgtBFoKHsZrgjtvS
extends JDialog {
    private static final long serialVersionUID = 1L;
    private final ResourceBundle rHAjVyBgPhqkQKsOvJMPMYn = ResourceBundle.getBundle("com/xivero/hraa/gui/frame/about/Bundle");
    private Thread QPeIwmpzLZIktKLXAJOQHcO;
    private Frame JSuXbPLjXcQLpTiButqPpoI;
    private JdVJXxffjyJZAkqbiFsaDCr iwitQCGCnkthNoQBBlYaPUM;
    private JButton dnqxuOOQwmxxivZzrQBWydh;
    private JPanel VZagBOcdslnIaKEkojULJvx;
    private JPanel VmkNmvoUyyfcyaaKFyveguY;
    private JScrollPane YGjBevanihqaxYKnUNtrNeA;
    private JScrollPane wunjGuaHWPKejzkQKUJfPKe;
    private JTextPane NuCoRkdmXmpraThwzNAiTcw;
    private JTextPane OrmpCzNZzYDlbDZDBXyofLf;

    public caLVyYpGgtBFoKHsZrgjtvS(Frame frame, boolean bl) {
        super(frame, bl);
        this.rHAjVyBgPhqkQKsOvJMPMYn();
        this.JSuXbPLjXcQLpTiButqPpoI = frame;
        this.OrmpCzNZzYDlbDZDBXyofLf.setText(String.format(this.rHAjVyBgPhqkQKsOvJMPMYn.getString("AboutBox.jTextPaneVersion.check"), Main.rHAjVyBgPhqkQKsOvJMPMYn.QPeIwmpzLZIktKLXAJOQHcO(2)));
        this.setLocationRelativeTo(null);
    }

    private void rHAjVyBgPhqkQKsOvJMPMYn() {
        this.VZagBOcdslnIaKEkojULJvx = new JPanel();
        this.dnqxuOOQwmxxivZzrQBWydh = new JButton();
        this.wunjGuaHWPKejzkQKUJfPKe = new JScrollPane();
        this.OrmpCzNZzYDlbDZDBXyofLf = new JTextPane();
        this.YGjBevanihqaxYKnUNtrNeA = new JScrollPane();
        this.NuCoRkdmXmpraThwzNAiTcw = new JTextPane();
        this.VmkNmvoUyyfcyaaKFyveguY = new JPanel();
        this.setDefaultCloseOperation(2);
        ResourceBundle resourceBundle = ResourceBundle.getBundle("com/xivero/hraa/gui/frame/about/Bundle");
        this.setTitle(resourceBundle.getString("AboutBox.title"));
        this.setMaximumSize(new Dimension(558, 303));
        this.setMinimumSize(new Dimension(558, 303));
        this.setResizable(false);
        this.dnqxuOOQwmxxivZzrQBWydh.setText(resourceBundle.getString("AboutBox.jButtonClose.text"));
        this.dnqxuOOQwmxxivZzrQBWydh.setFocusable(false);
        this.dnqxuOOQwmxxivZzrQBWydh.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                caLVyYpGgtBFoKHsZrgjtvS.this.rHAjVyBgPhqkQKsOvJMPMYn(actionEvent);
            }
        });
        this.wunjGuaHWPKejzkQKUJfPKe.setBorder(null);
        this.wunjGuaHWPKejzkQKUJfPKe.setHorizontalScrollBarPolicy(31);
        this.wunjGuaHWPKejzkQKUJfPKe.setVerticalScrollBarPolicy(21);
        this.OrmpCzNZzYDlbDZDBXyofLf.setEditable(false);
        this.OrmpCzNZzYDlbDZDBXyofLf.setBackground(new Color(240, 240, 240));
        this.OrmpCzNZzYDlbDZDBXyofLf.setBorder(null);
        this.OrmpCzNZzYDlbDZDBXyofLf.setContentType("text/html");
        this.OrmpCzNZzYDlbDZDBXyofLf.addHyperlinkListener(new HyperlinkListener(){

            @Override
            public void hyperlinkUpdate(HyperlinkEvent hyperlinkEvent) {
                caLVyYpGgtBFoKHsZrgjtvS.this.QPeIwmpzLZIktKLXAJOQHcO(hyperlinkEvent);
            }
        });
        this.wunjGuaHWPKejzkQKUJfPKe.setViewportView(this.OrmpCzNZzYDlbDZDBXyofLf);
        this.YGjBevanihqaxYKnUNtrNeA.setBorder(null);
        this.YGjBevanihqaxYKnUNtrNeA.setHorizontalScrollBarPolicy(31);
        this.YGjBevanihqaxYKnUNtrNeA.setVerticalScrollBarPolicy(21);
        this.NuCoRkdmXmpraThwzNAiTcw.setEditable(false);
        this.NuCoRkdmXmpraThwzNAiTcw.setBackground(new Color(240, 240, 240));
        this.NuCoRkdmXmpraThwzNAiTcw.setBorder(null);
        this.NuCoRkdmXmpraThwzNAiTcw.setContentType("text/html");
        this.NuCoRkdmXmpraThwzNAiTcw.setText(resourceBundle.getString("AboutBox.jTextAbout.text"));
        this.NuCoRkdmXmpraThwzNAiTcw.setFocusable(false);
        this.NuCoRkdmXmpraThwzNAiTcw.addHyperlinkListener(new HyperlinkListener(){

            @Override
            public void hyperlinkUpdate(HyperlinkEvent hyperlinkEvent) {
                caLVyYpGgtBFoKHsZrgjtvS.this.rHAjVyBgPhqkQKsOvJMPMYn(hyperlinkEvent);
            }
        });
        this.YGjBevanihqaxYKnUNtrNeA.setViewportView(this.NuCoRkdmXmpraThwzNAiTcw);
        this.VmkNmvoUyyfcyaaKFyveguY.setLayout(new OverlayLayout(this.VmkNmvoUyyfcyaaKFyveguY));
        GroupLayout groupLayout = new GroupLayout(this.VZagBOcdslnIaKEkojULJvx);
        this.VZagBOcdslnIaKEkojULJvx.setLayout(groupLayout);
        groupLayout.setHorizontalGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout.createSequentialGroup().addGap(16, 16, 16).addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.YGjBevanihqaxYKnUNtrNeA, -1, 528, Short.MAX_VALUE).addComponent(this.wunjGuaHWPKejzkQKUJfPKe).addGroup(groupLayout.createSequentialGroup().addComponent(this.VmkNmvoUyyfcyaaKFyveguY, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, Short.MAX_VALUE).addComponent(this.dnqxuOOQwmxxivZzrQBWydh, -2, 106, -2))).addGap(14, 14, 14)));
        groupLayout.setVerticalGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, groupLayout.createSequentialGroup().addGap(14, 14, 14).addComponent(this.wunjGuaHWPKejzkQKUJfPKe, -2, 21, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.YGjBevanihqaxYKnUNtrNeA, -1, 246, Short.MAX_VALUE).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.dnqxuOOQwmxxivZzrQBWydh).addComponent(this.VmkNmvoUyyfcyaaKFyveguY, -2, -1, -2)).addContainerGap()));
        GroupLayout groupLayout2 = new GroupLayout(this.getContentPane());
        this.getContentPane().setLayout(groupLayout2);
        groupLayout2.setHorizontalGroup(groupLayout2.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.VZagBOcdslnIaKEkojULJvx, -1, -1, Short.MAX_VALUE));
        groupLayout2.setVerticalGroup(groupLayout2.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.VZagBOcdslnIaKEkojULJvx, -1, -1, Short.MAX_VALUE));
        this.pack();
    }

    private void rHAjVyBgPhqkQKsOvJMPMYn(ActionEvent actionEvent) {
        this.setVisible(false);
    }

    private void rHAjVyBgPhqkQKsOvJMPMYn(HyperlinkEvent hyperlinkEvent) {
        if (hyperlinkEvent.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
            if (hyperlinkEvent.getURL().toString().equals("http://show.license/")) {
                this.QPeIwmpzLZIktKLXAJOQHcO();
            } else {
                Desktop desktop;
                Desktop desktop2 = desktop = Desktop.isDesktopSupported() ? Desktop.getDesktop() : null;
                if (desktop != null && desktop.isSupported(Desktop.Action.BROWSE)) {
                    try {
                        desktop.browse(hyperlinkEvent.getURL().toURI());
                    }
                    catch (IOException | URISyntaxException exception) {
                        // empty catch block
                    }
                }
            }
        }
    }

    private void QPeIwmpzLZIktKLXAJOQHcO() {
        EventQueue.invokeLater(new Runnable(){

            @Override
            public void run() {
                if (YzXXpcCCVJkKMcoHoACbjGG.QPeIwmpzLZIktKLXAJOQHcO()) {
                    try {
                        UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
                    }
                    catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException exception) {
                        Logger.getLogger(caLVyYpGgtBFoKHsZrgjtvS.class.getName()).log(Level.SEVERE, null, exception);
                    }
                }
                caLVyYpGgtBFoKHsZrgjtvS.this.iwitQCGCnkthNoQBBlYaPUM = new JdVJXxffjyJZAkqbiFsaDCr(caLVyYpGgtBFoKHsZrgjtvS.this.JSuXbPLjXcQLpTiButqPpoI, true);
                caLVyYpGgtBFoKHsZrgjtvS.this.iwitQCGCnkthNoQBBlYaPUM.setLocationRelativeTo(null);
                caLVyYpGgtBFoKHsZrgjtvS.this.iwitQCGCnkthNoQBBlYaPUM.setVisible(true);
            }
        });
    }

    private void QPeIwmpzLZIktKLXAJOQHcO(HyperlinkEvent hyperlinkEvent) {
        if (hyperlinkEvent.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
            if (hyperlinkEvent.getDescription().equals("VERSION")) {
                this.OrmpCzNZzYDlbDZDBXyofLf.setText(String.format(this.rHAjVyBgPhqkQKsOvJMPMYn.getString("AboutBox.jTextPaneVersion.checking"), Main.rHAjVyBgPhqkQKsOvJMPMYn.QPeIwmpzLZIktKLXAJOQHcO(2)));
                if (this.QPeIwmpzLZIktKLXAJOQHcO == null || this.QPeIwmpzLZIktKLXAJOQHcO != null && !this.QPeIwmpzLZIktKLXAJOQHcO.isAlive()) {
                    this.QPeIwmpzLZIktKLXAJOQHcO = new Thread(new Runnable(){

                        @Override
                        public void run() {
                            try {
                                URL uRL = new URL("https://www.xivero.com/downloads/MusicScope-Version.txt");
                                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(uRL.openStream()));
                                String string = bufferedReader.readLine();
                                kTbZASHDopQBPRkAiVONWbv kTbZASHDopQBPRkAiVONWbv2 = new kTbZASHDopQBPRkAiVONWbv(string, "\\.", new hdtwbvZSeJsEBjhsjhkgMoS());
                                if (Main.rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn(kTbZASHDopQBPRkAiVONWbv2)) {
                                    caLVyYpGgtBFoKHsZrgjtvS.this.OrmpCzNZzYDlbDZDBXyofLf.setText(String.format(caLVyYpGgtBFoKHsZrgjtvS.this.rHAjVyBgPhqkQKsOvJMPMYn.getString("AboutBox.jTextPaneVersion.newVersion"), Main.rHAjVyBgPhqkQKsOvJMPMYn.QPeIwmpzLZIktKLXAJOQHcO(2), kTbZASHDopQBPRkAiVONWbv2.QPeIwmpzLZIktKLXAJOQHcO(2)));
                                } else {
                                    caLVyYpGgtBFoKHsZrgjtvS.this.OrmpCzNZzYDlbDZDBXyofLf.setText(String.format(caLVyYpGgtBFoKHsZrgjtvS.this.rHAjVyBgPhqkQKsOvJMPMYn.getString("AboutBox.jTextPaneVersion.sameVersion"), Main.rHAjVyBgPhqkQKsOvJMPMYn.QPeIwmpzLZIktKLXAJOQHcO(2)));
                                }
                            }
                            catch (MalformedURLException malformedURLException) {
                                Logger.getLogger(caLVyYpGgtBFoKHsZrgjtvS.class.getName()).log(Level.SEVERE, null, malformedURLException);
                            }
                            catch (IOException iOException) {
                                Logger.getLogger(caLVyYpGgtBFoKHsZrgjtvS.class.getName()).log(Level.SEVERE, null, iOException);
                            }
                        }
                    });
                    this.QPeIwmpzLZIktKLXAJOQHcO.start();
                }
            } else {
                this.rHAjVyBgPhqkQKsOvJMPMYn(hyperlinkEvent);
            }
        }
    }

    @Override
    public void setVisible(boolean bl) {
        super.setVisible(bl);
    }
}

