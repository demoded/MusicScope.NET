/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ArrayBlockingQueue;
import sdfgjkljljoftrytrszgijpokjprs.AbkRNvAOeWIbEeMzsGvXdIr;
import sdfgjkljljoftrytrszgijpokjprs.DsdbIJsDbOeENdTpaIDYbiZ;
import sdfgjkljljoftrytrszgijpokjprs.ctKiKlqApLnHbBGBCfyBTor;
import sdfgjkljljoftrytrszgijpokjprs.dBprZQxZjIUbnidwEbEFsgB;
import sdfgjkljljoftrytrszgijpokjprs.mzuRiLdvInzoAeWfRiBnJOp;
import sdfgjkljljoftrytrszgijpokjprs.yKwRggLaMfgwMIUFQoKHBce;

public class fTYgHRsyVHrYUHzMatjQAKU
extends dBprZQxZjIUbnidwEbEFsgB
implements mzuRiLdvInzoAeWfRiBnJOp {
    private final int iwitQCGCnkthNoQBBlYaPUM;
    private final int dnqxuOOQwmxxivZzrQBWydh;
    private final int VZagBOcdslnIaKEkojULJvx;
    private final int VmkNmvoUyyfcyaaKFyveguY;
    private final yKwRggLaMfgwMIUFQoKHBce YGjBevanihqaxYKnUNtrNeA;
    private byte[] wunjGuaHWPKejzkQKUJfPKe;
    private HashMap<Integer, AbkRNvAOeWIbEeMzsGvXdIr> NuCoRkdmXmpraThwzNAiTcw;
    private HashMap<Integer, ArrayBlockingQueue<AbkRNvAOeWIbEeMzsGvXdIr>> OrmpCzNZzYDlbDZDBXyofLf;

    public fTYgHRsyVHrYUHzMatjQAKU(int n, int n2, yKwRggLaMfgwMIUFQoKHBce yKwRggLaMfgwMIUFQoKHBce2) {
        this(n, 10, n2, yKwRggLaMfgwMIUFQoKHBce2);
    }

    public fTYgHRsyVHrYUHzMatjQAKU(int n, int n2, int n3, yKwRggLaMfgwMIUFQoKHBce yKwRggLaMfgwMIUFQoKHBce2) {
        this.iwitQCGCnkthNoQBBlYaPUM = n;
        this.YGjBevanihqaxYKnUNtrNeA = yKwRggLaMfgwMIUFQoKHBce2;
        this.dnqxuOOQwmxxivZzrQBWydh = n2;
        this.VmkNmvoUyyfcyaaKFyveguY = n3;
        this.VZagBOcdslnIaKEkojULJvx = 4096;
        this.NuCoRkdmXmpraThwzNAiTcw = new HashMap(0);
        this.OrmpCzNZzYDlbDZDBXyofLf = new HashMap(0);
        this.wunjGuaHWPKejzkQKUJfPKe = new byte[this.VZagBOcdslnIaKEkojULJvx * n];
        for (int i = 0; i < n; ++i) {
            this.OrmpCzNZzYDlbDZDBXyofLf.put(i, new ArrayBlockingQueue(n2));
        }
        this.rHAjVyBgPhqkQKsOvJMPMYn("Channel Splitter");
    }

    @Override
    public int rHAjVyBgPhqkQKsOvJMPMYn(int n, byte[] byArray, int n2, int n3) {
        int n4 = 0;
        if (this.OrmpCzNZzYDlbDZDBXyofLf.get(n).peek() instanceof ctKiKlqApLnHbBGBCfyBTor) {
            return -1;
        }
        int n5 = n2;
        while (n5 < n3 && this.rHAjVyBgPhqkQKsOvJMPMYn() == DsdbIJsDbOeENdTpaIDYbiZ.JSuXbPLjXcQLpTiButqPpoI) {
            AbkRNvAOeWIbEeMzsGvXdIr abkRNvAOeWIbEeMzsGvXdIr;
            if (this.NuCoRkdmXmpraThwzNAiTcw.get(n) == null || !this.NuCoRkdmXmpraThwzNAiTcw.get(n).rHAjVyBgPhqkQKsOvJMPMYn()) {
                this.NuCoRkdmXmpraThwzNAiTcw.put(n, this.OrmpCzNZzYDlbDZDBXyofLf.get(n).poll());
            }
            if ((abkRNvAOeWIbEeMzsGvXdIr = this.NuCoRkdmXmpraThwzNAiTcw.get(n)) == null && this.rHAjVyBgPhqkQKsOvJMPMYn() == DsdbIJsDbOeENdTpaIDYbiZ.JSuXbPLjXcQLpTiButqPpoI) continue;
            if (abkRNvAOeWIbEeMzsGvXdIr instanceof ctKiKlqApLnHbBGBCfyBTor || this.rHAjVyBgPhqkQKsOvJMPMYn() != DsdbIJsDbOeENdTpaIDYbiZ.JSuXbPLjXcQLpTiButqPpoI) break;
            int n6 = abkRNvAOeWIbEeMzsGvXdIr.QPeIwmpzLZIktKLXAJOQHcO(byArray, n5, n3 - n5);
            n5 += n6;
            n4 += n6;
        }
        return n4;
    }

    private void rHAjVyBgPhqkQKsOvJMPMYn(int n, AbkRNvAOeWIbEeMzsGvXdIr abkRNvAOeWIbEeMzsGvXdIr) {
        try {
            this.OrmpCzNZzYDlbDZDBXyofLf.get(n).put(abkRNvAOeWIbEeMzsGvXdIr);
        }
        catch (InterruptedException interruptedException) {
            Thread.currentThread().interrupt();
        }
    }

    @Override
    public void QPeIwmpzLZIktKLXAJOQHcO() {
        block5: {
            int n;
            block6: {
                int n2;
                if (this.YGjBevanihqaxYKnUNtrNeA == null) break block5;
                ArrayList<AbkRNvAOeWIbEeMzsGvXdIr> arrayList = new ArrayList<AbkRNvAOeWIbEeMzsGvXdIr>(this.iwitQCGCnkthNoQBBlYaPUM);
                for (n = 0; n < this.iwitQCGCnkthNoQBBlYaPUM; ++n) {
                    arrayList.add(new AbkRNvAOeWIbEeMzsGvXdIr(this.VZagBOcdslnIaKEkojULJvx));
                }
                n = this.YGjBevanihqaxYKnUNtrNeA.rHAjVyBgPhqkQKsOvJMPMYn(this.wunjGuaHWPKejzkQKUJfPKe);
                if (n <= 0) break block6;
                for (n2 = 0; n2 < n; n2 += this.VmkNmvoUyyfcyaaKFyveguY * this.iwitQCGCnkthNoQBBlYaPUM) {
                    for (int i = 0; i < this.iwitQCGCnkthNoQBBlYaPUM; ++i) {
                        ((AbkRNvAOeWIbEeMzsGvXdIr)arrayList.get(i)).rHAjVyBgPhqkQKsOvJMPMYn(this.wunjGuaHWPKejzkQKUJfPKe, i * this.VmkNmvoUyyfcyaaKFyveguY + n2, this.VmkNmvoUyyfcyaaKFyveguY);
                    }
                }
                for (n2 = 0; n2 < this.iwitQCGCnkthNoQBBlYaPUM; ++n2) {
                    this.rHAjVyBgPhqkQKsOvJMPMYn(n2, (AbkRNvAOeWIbEeMzsGvXdIr)arrayList.get(n2));
                }
                break block5;
            }
            if (n != -1) break block5;
            for (int i = 0; i < this.iwitQCGCnkthNoQBBlYaPUM; ++i) {
                this.rHAjVyBgPhqkQKsOvJMPMYn(i, new ctKiKlqApLnHbBGBCfyBTor());
            }
        }
    }
}

