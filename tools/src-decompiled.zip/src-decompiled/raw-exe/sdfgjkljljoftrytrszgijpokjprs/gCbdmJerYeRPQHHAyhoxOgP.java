/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.io.IOException;
import sdfgjkljljoftrytrszgijpokjprs.eJnHMGFAPyJBjoMvbKedmZt;
import sdfgjkljljoftrytrszgijpokjprs.hrgPgVhiQYIZXeWOluMaPwR;

public class gCbdmJerYeRPQHHAyhoxOgP
extends eJnHMGFAPyJBjoMvbKedmZt {
    public gCbdmJerYeRPQHHAyhoxOgP(hrgPgVhiQYIZXeWOluMaPwR hrgPgVhiQYIZXeWOluMaPwR2, int n, boolean bl) throws IOException {
        super(bl, n);
        hrgPgVhiQYIZXeWOluMaPwR2.rHAjVyBgPhqkQKsOvJMPMYn(null, n);
    }

    public String toString() {
        return "Padding (Length=" + this.VmkNmvoUyyfcyaaKFyveguY + ") last =" + this.VZagBOcdslnIaKEkojULJvx;
    }
}

