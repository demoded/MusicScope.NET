/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.util.concurrent.ArrayBlockingQueue;
import sdfgjkljljoftrytrszgijpokjprs.AbkRNvAOeWIbEeMzsGvXdIr;
import sdfgjkljljoftrytrszgijpokjprs.DsdbIJsDbOeENdTpaIDYbiZ;
import sdfgjkljljoftrytrszgijpokjprs.KFVWmcqOBgYFxPgeswapvPe;
import sdfgjkljljoftrytrszgijpokjprs.RRnnNgUDxUFGFeaiYduOghS;
import sdfgjkljljoftrytrszgijpokjprs.ctKiKlqApLnHbBGBCfyBTor;
import sdfgjkljljoftrytrszgijpokjprs.dBprZQxZjIUbnidwEbEFsgB;

public class CMOfeAVHYgkhoDpCHlrIxZW
extends dBprZQxZjIUbnidwEbEFsgB {
    private static final KFVWmcqOBgYFxPgeswapvPe iwitQCGCnkthNoQBBlYaPUM = KFVWmcqOBgYFxPgeswapvPe.iwitQCGCnkthNoQBBlYaPUM;
    private final int dnqxuOOQwmxxivZzrQBWydh;
    private final int VZagBOcdslnIaKEkojULJvx;
    private final RRnnNgUDxUFGFeaiYduOghS VmkNmvoUyyfcyaaKFyveguY;
    private final int YGjBevanihqaxYKnUNtrNeA;
    private final byte[][] wunjGuaHWPKejzkQKUJfPKe;
    private final int[] NuCoRkdmXmpraThwzNAiTcw;
    private AbkRNvAOeWIbEeMzsGvXdIr OrmpCzNZzYDlbDZDBXyofLf;
    private final ArrayBlockingQueue<AbkRNvAOeWIbEeMzsGvXdIr> ibbBhgWhrhhiOLwDlcriPhb;

    public CMOfeAVHYgkhoDpCHlrIxZW(int n, int n2, int n3, RRnnNgUDxUFGFeaiYduOghS rRnnNgUDxUFGFeaiYduOghS) {
        this.dnqxuOOQwmxxivZzrQBWydh = n;
        this.VZagBOcdslnIaKEkojULJvx = n2;
        this.YGjBevanihqaxYKnUNtrNeA = n3;
        this.VmkNmvoUyyfcyaaKFyveguY = rRnnNgUDxUFGFeaiYduOghS;
        this.ibbBhgWhrhhiOLwDlcriPhb = new ArrayBlockingQueue(n2);
        this.wunjGuaHWPKejzkQKUJfPKe = new byte[n][n3];
        this.NuCoRkdmXmpraThwzNAiTcw = new int[n];
        this.rHAjVyBgPhqkQKsOvJMPMYn("Interleaved Buffer Builder");
    }

    public synchronized int rHAjVyBgPhqkQKsOvJMPMYn(byte[] byArray, int n, int n2) {
        int n3 = 0;
        if (this.OrmpCzNZzYDlbDZDBXyofLf instanceof ctKiKlqApLnHbBGBCfyBTor) {
            return -1;
        }
        int n4 = n;
        while (n4 < n2) {
            if (this.OrmpCzNZzYDlbDZDBXyofLf == null || !this.OrmpCzNZzYDlbDZDBXyofLf.rHAjVyBgPhqkQKsOvJMPMYn()) {
                try {
                    this.OrmpCzNZzYDlbDZDBXyofLf = this.ibbBhgWhrhhiOLwDlcriPhb.take();
                }
                catch (InterruptedException interruptedException) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            if (this.OrmpCzNZzYDlbDZDBXyofLf == null && this.rHAjVyBgPhqkQKsOvJMPMYn() == DsdbIJsDbOeENdTpaIDYbiZ.JSuXbPLjXcQLpTiButqPpoI) continue;
            if (this.OrmpCzNZzYDlbDZDBXyofLf instanceof ctKiKlqApLnHbBGBCfyBTor || this.rHAjVyBgPhqkQKsOvJMPMYn() != DsdbIJsDbOeENdTpaIDYbiZ.JSuXbPLjXcQLpTiButqPpoI) break;
            int n5 = this.OrmpCzNZzYDlbDZDBXyofLf.QPeIwmpzLZIktKLXAJOQHcO(byArray, n4, n2 - n4);
            n4 += n5;
            n3 += n5;
        }
        return n3;
    }

    private void rHAjVyBgPhqkQKsOvJMPMYn(AbkRNvAOeWIbEeMzsGvXdIr abkRNvAOeWIbEeMzsGvXdIr) {
        try {
            this.ibbBhgWhrhhiOLwDlcriPhb.put(abkRNvAOeWIbEeMzsGvXdIr);
        }
        catch (InterruptedException interruptedException) {
            Thread.currentThread().interrupt();
        }
    }

    @Override
    public void QPeIwmpzLZIktKLXAJOQHcO() {
        for (int i = 0; i < this.dnqxuOOQwmxxivZzrQBWydh; ++i) {
            this.NuCoRkdmXmpraThwzNAiTcw[i] = this.VmkNmvoUyyfcyaaKFyveguY.rHAjVyBgPhqkQKsOvJMPMYn(i, this.wunjGuaHWPKejzkQKUJfPKe[i]);
        }
        if (this.rHAjVyBgPhqkQKsOvJMPMYn(this.NuCoRkdmXmpraThwzNAiTcw)) {
            this.rHAjVyBgPhqkQKsOvJMPMYn(new ctKiKlqApLnHbBGBCfyBTor());
            return;
        }
        AbkRNvAOeWIbEeMzsGvXdIr abkRNvAOeWIbEeMzsGvXdIr = new AbkRNvAOeWIbEeMzsGvXdIr(this.QPeIwmpzLZIktKLXAJOQHcO(this.NuCoRkdmXmpraThwzNAiTcw));
        for (int i = 0; i < this.NuCoRkdmXmpraThwzNAiTcw[0]; i += iwitQCGCnkthNoQBBlYaPUM.QPeIwmpzLZIktKLXAJOQHcO()) {
            for (int j = 0; j < this.dnqxuOOQwmxxivZzrQBWydh; ++j) {
                abkRNvAOeWIbEeMzsGvXdIr.rHAjVyBgPhqkQKsOvJMPMYn(this.wunjGuaHWPKejzkQKUJfPKe[j], i, iwitQCGCnkthNoQBBlYaPUM.QPeIwmpzLZIktKLXAJOQHcO());
            }
        }
        this.rHAjVyBgPhqkQKsOvJMPMYn(abkRNvAOeWIbEeMzsGvXdIr);
    }

    private boolean rHAjVyBgPhqkQKsOvJMPMYn(int[] nArray) {
        for (int n : nArray) {
            if (n != -1) continue;
            return true;
        }
        return false;
    }

    private int QPeIwmpzLZIktKLXAJOQHcO(int[] nArray) {
        int n = 0;
        for (int n2 : nArray) {
            n += n2;
        }
        return n;
    }
}

