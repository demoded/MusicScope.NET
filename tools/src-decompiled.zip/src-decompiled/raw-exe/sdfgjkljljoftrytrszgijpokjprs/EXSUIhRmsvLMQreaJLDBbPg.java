/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.GFDfJcQwFRWsKLEqUzyzjuA;
import sdfgjkljljoftrytrszgijpokjprs.LMMqFwohHquNkNfhbpHHdcV;
import sdfgjkljljoftrytrszgijpokjprs.ZBNFgJwMMkkaOLFmIBSJWbh;

public class EXSUIhRmsvLMQreaJLDBbPg
implements LMMqFwohHquNkNfhbpHHdcV {
    private String rHAjVyBgPhqkQKsOvJMPMYn;
    private long QPeIwmpzLZIktKLXAJOQHcO;
    private long JSuXbPLjXcQLpTiButqPpoI;
    private long iwitQCGCnkthNoQBBlYaPUM;

    @Override
    public String QPeIwmpzLZIktKLXAJOQHcO() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }

    public long VmkNmvoUyyfcyaaKFyveguY() {
        return this.QPeIwmpzLZIktKLXAJOQHcO;
    }

    @Override
    public long JSuXbPLjXcQLpTiButqPpoI() {
        return this.VmkNmvoUyyfcyaaKFyveguY();
    }

    @Override
    public long iwitQCGCnkthNoQBBlYaPUM() {
        return this.JSuXbPLjXcQLpTiButqPpoI;
    }

    @Override
    public long dnqxuOOQwmxxivZzrQBWydh() {
        return this.iwitQCGCnkthNoQBBlYaPUM;
    }

    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(ZBNFgJwMMkkaOLFmIBSJWbh zBNFgJwMMkkaOLFmIBSJWbh) throws GFDfJcQwFRWsKLEqUzyzjuA {
        byte[] byArray;
        this.rHAjVyBgPhqkQKsOvJMPMYn = "";
        this.QPeIwmpzLZIktKLXAJOQHcO = -1L;
        this.JSuXbPLjXcQLpTiButqPpoI = -1L;
        this.iwitQCGCnkthNoQBBlYaPUM = -1L;
        this.JSuXbPLjXcQLpTiButqPpoI = zBNFgJwMMkkaOLFmIBSJWbh.iwitQCGCnkthNoQBBlYaPUM();
        for (byte by : byArray = zBNFgJwMMkkaOLFmIBSJWbh.QPeIwmpzLZIktKLXAJOQHcO(4).array()) {
            this.rHAjVyBgPhqkQKsOvJMPMYn = this.rHAjVyBgPhqkQKsOvJMPMYn + (char)by;
        }
        this.QPeIwmpzLZIktKLXAJOQHcO = zBNFgJwMMkkaOLFmIBSJWbh.rHAjVyBgPhqkQKsOvJMPMYn(8).getLong();
        this.iwitQCGCnkthNoQBBlYaPUM = zBNFgJwMMkkaOLFmIBSJWbh.iwitQCGCnkthNoQBBlYaPUM();
    }

    @Override
    public boolean VZagBOcdslnIaKEkojULJvx() {
        boolean bl = true;
        bl &= this.rHAjVyBgPhqkQKsOvJMPMYn != null && this.rHAjVyBgPhqkQKsOvJMPMYn.length() == 4;
        bl &= this.QPeIwmpzLZIktKLXAJOQHcO > 0L;
        bl &= this.JSuXbPLjXcQLpTiButqPpoI >= 0L;
        return bl &= this.iwitQCGCnkthNoQBBlYaPUM >= 12L;
    }
}

