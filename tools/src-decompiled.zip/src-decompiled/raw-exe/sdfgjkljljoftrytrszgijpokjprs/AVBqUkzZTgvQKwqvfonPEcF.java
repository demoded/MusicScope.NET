/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.awt.Color;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import sdfgjkljljoftrytrszgijpokjprs.QQsnPoyMVxorlAjmSBkmMwZ;
import sdfgjkljljoftrytrszgijpokjprs.fdLwzVOPYyeAPmrtqvpdjBY;

public class AVBqUkzZTgvQKwqvfonPEcF
extends JPanel {
    private static final long serialVersionUID = 1L;
    private static final QQsnPoyMVxorlAjmSBkmMwZ rHAjVyBgPhqkQKsOvJMPMYn = new QQsnPoyMVxorlAjmSBkmMwZ(null, false);
    private JButton QPeIwmpzLZIktKLXAJOQHcO;

    public AVBqUkzZTgvQKwqvfonPEcF() {
        this.QPeIwmpzLZIktKLXAJOQHcO();
    }

    public int rHAjVyBgPhqkQKsOvJMPMYn() {
        return rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn();
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(fdLwzVOPYyeAPmrtqvpdjBY fdLwzVOPYyeAPmrtqvpdjBY2) {
        rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn(fdLwzVOPYyeAPmrtqvpdjBY2);
    }

    private void QPeIwmpzLZIktKLXAJOQHcO() {
        this.QPeIwmpzLZIktKLXAJOQHcO = new JButton();
        this.setBackground(new Color(0, 0, 0));
        this.QPeIwmpzLZIktKLXAJOQHcO.setBackground(new Color(0, 0, 0));
        this.QPeIwmpzLZIktKLXAJOQHcO.setIcon(new ImageIcon(this.getClass().getResource("/com/xivero/hraa/icons/volume_up-16.png")));
        this.QPeIwmpzLZIktKLXAJOQHcO.setBorder(null);
        this.QPeIwmpzLZIktKLXAJOQHcO.setDefaultCapable(false);
        this.QPeIwmpzLZIktKLXAJOQHcO.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseEntered(MouseEvent mouseEvent) {
                AVBqUkzZTgvQKwqvfonPEcF.this.rHAjVyBgPhqkQKsOvJMPMYn(mouseEvent);
            }

            @Override
            public void mouseExited(MouseEvent mouseEvent) {
                AVBqUkzZTgvQKwqvfonPEcF.this.QPeIwmpzLZIktKLXAJOQHcO(mouseEvent);
            }
        });
        this.QPeIwmpzLZIktKLXAJOQHcO.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                AVBqUkzZTgvQKwqvfonPEcF.this.rHAjVyBgPhqkQKsOvJMPMYn(actionEvent);
            }
        });
        GroupLayout groupLayout = new GroupLayout(this);
        this.setLayout(groupLayout);
        groupLayout.setHorizontalGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.QPeIwmpzLZIktKLXAJOQHcO, -2, 31, -2));
        groupLayout.setVerticalGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.QPeIwmpzLZIktKLXAJOQHcO, -1, 25, Short.MAX_VALUE));
    }

    private void rHAjVyBgPhqkQKsOvJMPMYn(MouseEvent mouseEvent) {
    }

    private void QPeIwmpzLZIktKLXAJOQHcO(MouseEvent mouseEvent) {
        rHAjVyBgPhqkQKsOvJMPMYn.JSuXbPLjXcQLpTiButqPpoI();
    }

    private void rHAjVyBgPhqkQKsOvJMPMYn(ActionEvent actionEvent) {
        Point point = MouseInfo.getPointerInfo().getLocation();
        rHAjVyBgPhqkQKsOvJMPMYn.setLocation((int)point.getX() + 1, (int)point.getY() + 1);
        rHAjVyBgPhqkQKsOvJMPMYn.iwitQCGCnkthNoQBBlYaPUM();
        rHAjVyBgPhqkQKsOvJMPMYn.setVisible(true);
    }
}

