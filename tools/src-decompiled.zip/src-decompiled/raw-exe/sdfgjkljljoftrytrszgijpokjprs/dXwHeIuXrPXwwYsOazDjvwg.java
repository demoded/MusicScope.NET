/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package sdfgjkljljoftrytrszgijpokjprs;

import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.List;
import sdfgjkljljoftrytrszgijpokjprs.ZVnipNutzPTkUTYOtYDkVhZ;

public class dXwHeIuXrPXwwYsOazDjvwg {
    @SerializedName(value="error")
    private boolean rHAjVyBgPhqkQKsOvJMPMYn;
    @SerializedName(value="messages")
    private ZVnipNutzPTkUTYOtYDkVhZ[] QPeIwmpzLZIktKLXAJOQHcO;

    public boolean rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }

    public ZVnipNutzPTkUTYOtYDkVhZ[] QPeIwmpzLZIktKLXAJOQHcO() {
        return this.QPeIwmpzLZIktKLXAJOQHcO;
    }

    public List<Integer> JSuXbPLjXcQLpTiButqPpoI() {
        ArrayList<Integer> arrayList = new ArrayList<Integer>(0);
        for (ZVnipNutzPTkUTYOtYDkVhZ zVnipNutzPTkUTYOtYDkVhZ : this.QPeIwmpzLZIktKLXAJOQHcO) {
            arrayList.add(zVnipNutzPTkUTYOtYDkVhZ.rHAjVyBgPhqkQKsOvJMPMYn());
        }
        return arrayList;
    }
}

