/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.util.ArrayList;

public class GHZgLGQAyrKtRkmFCeaixlU
extends Exception {
    private ArrayList<String> rHAjVyBgPhqkQKsOvJMPMYn = new ArrayList(0);

    public GHZgLGQAyrKtRkmFCeaixlU(String string) {
        super(string);
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(String string) {
        this.rHAjVyBgPhqkQKsOvJMPMYn.add(string);
    }

    public ArrayList<String> rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }
}

