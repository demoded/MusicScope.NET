/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package sdfgjkljljoftrytrszgijpokjprs;

import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import sdfgjkljljoftrytrszgijpokjprs.IAOlbhzKtGpcbDBaJetftIG;
import sdfgjkljljoftrytrszgijpokjprs.cxgXPZvqmsDtmYhggfCRwiz;
import sdfgjkljljoftrytrszgijpokjprs.iAZFzvHVmGVFKKhFOLoTZwF;

public class fikLFfybOLBBPFzDSaJuDxU {
    @SerializedName(value="name")
    private String rHAjVyBgPhqkQKsOvJMPMYn;
    @SerializedName(value="fileExtension")
    private String QPeIwmpzLZIktKLXAJOQHcO;
    @SerializedName(value="label")
    private String JSuXbPLjXcQLpTiButqPpoI;
    @SerializedName(value="source")
    private String iwitQCGCnkthNoQBBlYaPUM;
    @SerializedName(value="totalTime")
    private int dnqxuOOQwmxxivZzrQBWydh;
    @SerializedName(value="sampleRate")
    private int VZagBOcdslnIaKEkojULJvx;
    @SerializedName(value="bitDepth")
    private int VmkNmvoUyyfcyaaKFyveguY;
    @SerializedName(value="numberTracks")
    private int YGjBevanihqaxYKnUNtrNeA;
    @SerializedName(value="releaseYear")
    private int wunjGuaHWPKejzkQKUJfPKe;
    @SerializedName(value="albumMeasurement")
    private cxgXPZvqmsDtmYhggfCRwiz NuCoRkdmXmpraThwzNAiTcw;
    @SerializedName(value="artists")
    private ArrayList<IAOlbhzKtGpcbDBaJetftIG> OrmpCzNZzYDlbDZDBXyofLf = new ArrayList(0);
    @SerializedName(value="tracks")
    private ArrayList<iAZFzvHVmGVFKKhFOLoTZwF> ibbBhgWhrhhiOLwDlcriPhb = new ArrayList(0);

    public String rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }

    public String QPeIwmpzLZIktKLXAJOQHcO() {
        return this.QPeIwmpzLZIktKLXAJOQHcO;
    }

    public int JSuXbPLjXcQLpTiButqPpoI() {
        return this.VZagBOcdslnIaKEkojULJvx;
    }

    public int iwitQCGCnkthNoQBBlYaPUM() {
        return this.VmkNmvoUyyfcyaaKFyveguY;
    }

    public int dnqxuOOQwmxxivZzrQBWydh() {
        return this.YGjBevanihqaxYKnUNtrNeA;
    }

    public ArrayList<iAZFzvHVmGVFKKhFOLoTZwF> VZagBOcdslnIaKEkojULJvx() {
        return this.ibbBhgWhrhhiOLwDlcriPhb;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(String string) {
        this.rHAjVyBgPhqkQKsOvJMPMYn = string;
    }

    public void QPeIwmpzLZIktKLXAJOQHcO(String string) {
        this.QPeIwmpzLZIktKLXAJOQHcO = string;
    }

    public void JSuXbPLjXcQLpTiButqPpoI(String string) {
        this.JSuXbPLjXcQLpTiButqPpoI = string;
    }

    public void iwitQCGCnkthNoQBBlYaPUM(String string) {
        this.iwitQCGCnkthNoQBBlYaPUM = string;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(int n) {
        this.dnqxuOOQwmxxivZzrQBWydh = n;
    }

    public void QPeIwmpzLZIktKLXAJOQHcO(int n) {
        this.VZagBOcdslnIaKEkojULJvx = n;
    }

    public void JSuXbPLjXcQLpTiButqPpoI(int n) {
        this.VmkNmvoUyyfcyaaKFyveguY = n;
    }

    public void iwitQCGCnkthNoQBBlYaPUM(int n) {
        this.YGjBevanihqaxYKnUNtrNeA = n;
    }

    public void dnqxuOOQwmxxivZzrQBWydh(int n) {
        this.wunjGuaHWPKejzkQKUJfPKe = n;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(cxgXPZvqmsDtmYhggfCRwiz cxgXPZvqmsDtmYhggfCRwiz2) {
        this.NuCoRkdmXmpraThwzNAiTcw = cxgXPZvqmsDtmYhggfCRwiz2;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(IAOlbhzKtGpcbDBaJetftIG iAOlbhzKtGpcbDBaJetftIG) {
        if (!this.OrmpCzNZzYDlbDZDBXyofLf.contains(iAOlbhzKtGpcbDBaJetftIG)) {
            this.OrmpCzNZzYDlbDZDBXyofLf.add(iAOlbhzKtGpcbDBaJetftIG);
        }
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(iAZFzvHVmGVFKKhFOLoTZwF iAZFzvHVmGVFKKhFOLoTZwF2) {
        this.ibbBhgWhrhhiOLwDlcriPhb.add(iAZFzvHVmGVFKKhFOLoTZwF2);
    }
}

