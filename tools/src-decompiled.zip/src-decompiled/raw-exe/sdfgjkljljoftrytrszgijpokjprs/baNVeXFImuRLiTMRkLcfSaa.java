/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

public class baNVeXFImuRLiTMRkLcfSaa {
    protected int[] rHAjVyBgPhqkQKsOvJMPMYn;
    protected int[] QPeIwmpzLZIktKLXAJOQHcO;
    protected int JSuXbPLjXcQLpTiButqPpoI = 0;

    public void rHAjVyBgPhqkQKsOvJMPMYn(int n) {
        if (this.JSuXbPLjXcQLpTiButqPpoI >= n) {
            return;
        }
        this.rHAjVyBgPhqkQKsOvJMPMYn = new int[1 << n];
        this.QPeIwmpzLZIktKLXAJOQHcO = new int[1 << n];
        this.JSuXbPLjXcQLpTiButqPpoI = n;
    }
}

