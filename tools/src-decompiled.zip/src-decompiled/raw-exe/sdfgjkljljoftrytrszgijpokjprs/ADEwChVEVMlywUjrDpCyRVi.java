/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.BrqrCQbbknwtebNWiMmRwch;
import sdfgjkljljoftrytrszgijpokjprs.EYLjCFiTTOgnPWQPYoTfNzn;
import sdfgjkljljoftrytrszgijpokjprs.HKBxrELLGRJjtHxTgkzIOlv;
import sdfgjkljljoftrytrszgijpokjprs.cJizbPrgAISXyzXrgujHPeB;

@BrqrCQbbknwtebNWiMmRwch(rHAjVyBgPhqkQKsOvJMPMYn=cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn.Composed_LevelsLoudness)
public class ADEwChVEVMlywUjrDpCyRVi
extends HKBxrELLGRJjtHxTgkzIOlv {
    public ADEwChVEVMlywUjrDpCyRVi(EYLjCFiTTOgnPWQPYoTfNzn ... eYLjCFiTTOgnPWQPYoTfNznArray) {
        super(eYLjCFiTTOgnPWQPYoTfNznArray);
    }
}

