/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import sdfgjkljljoftrytrszgijpokjprs.EYLjCFiTTOgnPWQPYoTfNzn;
import sdfgjkljljoftrytrszgijpokjprs.OVwxYDEnxDAUeujkyADMYmG;
import sdfgjkljljoftrytrszgijpokjprs.ObpHVCnoGMfrEhxVmwqzGgu;
import sdfgjkljljoftrytrszgijpokjprs.PYJBgzPCdrZnekQfrnwIPxJ;
import sdfgjkljljoftrytrszgijpokjprs.YGjBevanihqaxYKnUNtrNeA;
import sdfgjkljljoftrytrszgijpokjprs.ZvOTVUaKFTNpNSbbMYZfoXf;
import sdfgjkljljoftrytrszgijpokjprs.ekxmGzMKSyHUczkNwMvschV;
import sdfgjkljljoftrytrszgijpokjprs.oiyflxXGGmIcWtyMJWwDpJe;

public class cJizbPrgAISXyzXrgujHPeB {
    private final PYJBgzPCdrZnekQfrnwIPxJ rHAjVyBgPhqkQKsOvJMPMYn;
    private final ArrayList<ObpHVCnoGMfrEhxVmwqzGgu> QPeIwmpzLZIktKLXAJOQHcO;
    private final HashMap<rHAjVyBgPhqkQKsOvJMPMYn, ArrayList<ekxmGzMKSyHUczkNwMvschV>> JSuXbPLjXcQLpTiButqPpoI;
    private final ArrayList<oiyflxXGGmIcWtyMJWwDpJe> iwitQCGCnkthNoQBBlYaPUM = new ArrayList(0);
    private final ExecutorService dnqxuOOQwmxxivZzrQBWydh;
    private OVwxYDEnxDAUeujkyADMYmG VZagBOcdslnIaKEkojULJvx;

    public cJizbPrgAISXyzXrgujHPeB() {
        this.rHAjVyBgPhqkQKsOvJMPMYn = PYJBgzPCdrZnekQfrnwIPxJ.rHAjVyBgPhqkQKsOvJMPMYn();
        this.QPeIwmpzLZIktKLXAJOQHcO = new ArrayList(0);
        this.dnqxuOOQwmxxivZzrQBWydh = Executors.newCachedThreadPool();
        this.JSuXbPLjXcQLpTiButqPpoI = new HashMap(0);
        for (rHAjVyBgPhqkQKsOvJMPMYn rHAjVyBgPhqkQKsOvJMPMYn2 : sdfgjkljljoftrytrszgijpokjprs.cJizbPrgAISXyzXrgujHPeB$rHAjVyBgPhqkQKsOvJMPMYn.values()) {
            this.JSuXbPLjXcQLpTiButqPpoI.put(rHAjVyBgPhqkQKsOvJMPMYn2, new ArrayList(0));
        }
    }

    public synchronized void rHAjVyBgPhqkQKsOvJMPMYn(ZvOTVUaKFTNpNSbbMYZfoXf zvOTVUaKFTNpNSbbMYZfoXf) {
        this.rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn(zvOTVUaKFTNpNSbbMYZfoXf);
    }

    public synchronized void rHAjVyBgPhqkQKsOvJMPMYn(YGjBevanihqaxYKnUNtrNeA yGjBevanihqaxYKnUNtrNeA) {
        this.rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn(yGjBevanihqaxYKnUNtrNeA);
    }

    public synchronized void QPeIwmpzLZIktKLXAJOQHcO(YGjBevanihqaxYKnUNtrNeA yGjBevanihqaxYKnUNtrNeA) {
        this.rHAjVyBgPhqkQKsOvJMPMYn.QPeIwmpzLZIktKLXAJOQHcO(yGjBevanihqaxYKnUNtrNeA);
    }

    public double rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.VZagBOcdslnIaKEkojULJvx.dnqxuOOQwmxxivZzrQBWydh();
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(EYLjCFiTTOgnPWQPYoTfNzn<?> eYLjCFiTTOgnPWQPYoTfNzn) {
        this.QPeIwmpzLZIktKLXAJOQHcO.add(new ObpHVCnoGMfrEhxVmwqzGgu(eYLjCFiTTOgnPWQPYoTfNzn));
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(ekxmGzMKSyHUczkNwMvschV<?> ekxmGzMKSyHUczkNwMvschV2, rHAjVyBgPhqkQKsOvJMPMYn ... rHAjVyBgPhqkQKsOvJMPMYnArray) {
        for (rHAjVyBgPhqkQKsOvJMPMYn rHAjVyBgPhqkQKsOvJMPMYn2 : rHAjVyBgPhqkQKsOvJMPMYnArray) {
            ArrayList<ekxmGzMKSyHUczkNwMvschV> arrayList = this.rHAjVyBgPhqkQKsOvJMPMYn(rHAjVyBgPhqkQKsOvJMPMYn2);
            if (arrayList.contains(ekxmGzMKSyHUczkNwMvschV2)) continue;
            arrayList.add(ekxmGzMKSyHUczkNwMvschV2);
        }
    }

    public synchronized void QPeIwmpzLZIktKLXAJOQHcO() {
        this.iwitQCGCnkthNoQBBlYaPUM.clear();
        for (ObpHVCnoGMfrEhxVmwqzGgu object : this.QPeIwmpzLZIktKLXAJOQHcO) {
            EYLjCFiTTOgnPWQPYoTfNzn eYLjCFiTTOgnPWQPYoTfNzn = object.QPeIwmpzLZIktKLXAJOQHcO();
            eYLjCFiTTOgnPWQPYoTfNzn.rHAjVyBgPhqkQKsOvJMPMYn(this.VZagBOcdslnIaKEkojULJvx.iwitQCGCnkthNoQBBlYaPUM());
            Future future = this.dnqxuOOQwmxxivZzrQBWydh.submit(eYLjCFiTTOgnPWQPYoTfNzn);
            this.iwitQCGCnkthNoQBBlYaPUM.add(new oiyflxXGGmIcWtyMJWwDpJe(future, object.rHAjVyBgPhqkQKsOvJMPMYn()));
        }
        while (this.rHAjVyBgPhqkQKsOvJMPMYn(this.iwitQCGCnkthNoQBBlYaPUM)) {
            for (oiyflxXGGmIcWtyMJWwDpJe oiyflxXGGmIcWtyMJWwDpJe2 : this.iwitQCGCnkthNoQBBlYaPUM) {
                if (!oiyflxXGGmIcWtyMJWwDpJe2.JSuXbPLjXcQLpTiButqPpoI() || !oiyflxXGGmIcWtyMJWwDpJe2.rHAjVyBgPhqkQKsOvJMPMYn().isDone()) continue;
                try {
                    this.rHAjVyBgPhqkQKsOvJMPMYn(oiyflxXGGmIcWtyMJWwDpJe2.QPeIwmpzLZIktKLXAJOQHcO(), oiyflxXGGmIcWtyMJWwDpJe2.rHAjVyBgPhqkQKsOvJMPMYn().get());
                    oiyflxXGGmIcWtyMJWwDpJe2.iwitQCGCnkthNoQBBlYaPUM();
                }
                catch (InterruptedException | ExecutionException exception) {
                    oiyflxXGGmIcWtyMJWwDpJe2.iwitQCGCnkthNoQBBlYaPUM();
                }
            }
        }
    }

    private boolean rHAjVyBgPhqkQKsOvJMPMYn(ArrayList<oiyflxXGGmIcWtyMJWwDpJe> arrayList) {
        for (oiyflxXGGmIcWtyMJWwDpJe oiyflxXGGmIcWtyMJWwDpJe2 : arrayList) {
            if (oiyflxXGGmIcWtyMJWwDpJe2 == null || !oiyflxXGGmIcWtyMJWwDpJe2.JSuXbPLjXcQLpTiButqPpoI()) continue;
            return true;
        }
        return false;
    }

    private synchronized <V> void rHAjVyBgPhqkQKsOvJMPMYn(rHAjVyBgPhqkQKsOvJMPMYn rHAjVyBgPhqkQKsOvJMPMYn2, V v) {
        if (v != null) {
            ArrayList<ekxmGzMKSyHUczkNwMvschV> arrayList = this.rHAjVyBgPhqkQKsOvJMPMYn(rHAjVyBgPhqkQKsOvJMPMYn2);
            for (ekxmGzMKSyHUczkNwMvschV ekxmGzMKSyHUczkNwMvschV2 : arrayList) {
                ekxmGzMKSyHUczkNwMvschV2.rHAjVyBgPhqkQKsOvJMPMYn(v, rHAjVyBgPhqkQKsOvJMPMYn2);
            }
        }
    }

    private ArrayList<ekxmGzMKSyHUczkNwMvschV> rHAjVyBgPhqkQKsOvJMPMYn(rHAjVyBgPhqkQKsOvJMPMYn rHAjVyBgPhqkQKsOvJMPMYn2) {
        return this.JSuXbPLjXcQLpTiButqPpoI.get((Object)rHAjVyBgPhqkQKsOvJMPMYn2);
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(OVwxYDEnxDAUeujkyADMYmG oVwxYDEnxDAUeujkyADMYmG) {
        this.VZagBOcdslnIaKEkojULJvx = oVwxYDEnxDAUeujkyADMYmG;
    }

    public static enum rHAjVyBgPhqkQKsOvJMPMYn {
        rHAjVyBgPhqkQKsOvJMPMYn,
        QPeIwmpzLZIktKLXAJOQHcO,
        JSuXbPLjXcQLpTiButqPpoI,
        iwitQCGCnkthNoQBBlYaPUM,
        dnqxuOOQwmxxivZzrQBWydh,
        VZagBOcdslnIaKEkojULJvx,
        VmkNmvoUyyfcyaaKFyveguY;

    }
}

