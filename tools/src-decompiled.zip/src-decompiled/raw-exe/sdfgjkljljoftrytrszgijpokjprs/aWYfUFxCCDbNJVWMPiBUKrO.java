/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;
import sdfgjkljljoftrytrszgijpokjprs.KsHoYvJaofzRsWbjpDlDnPw;
import sdfgjkljljoftrytrszgijpokjprs.MhVrMnbsUmIgwNYekMCIkde;
import sdfgjkljljoftrytrszgijpokjprs.WnqvfCcrLvcneTJidLxiKam;
import sdfgjkljljoftrytrszgijpokjprs.YGjBevanihqaxYKnUNtrNeA;
import sdfgjkljljoftrytrszgijpokjprs.ZvOTVUaKFTNpNSbbMYZfoXf;
import sdfgjkljljoftrytrszgijpokjprs.ZwGjAePXQvUAdydJLUqmNBz;
import sdfgjkljljoftrytrszgijpokjprs.cJizbPrgAISXyzXrgujHPeB;
import sdfgjkljljoftrytrszgijpokjprs.lKkynTEEZVTbuSJCgDWFhnQ;

public class aWYfUFxCCDbNJVWMPiBUKrO
implements MhVrMnbsUmIgwNYekMCIkde,
ZwGjAePXQvUAdydJLUqmNBz {
    private final Object rHAjVyBgPhqkQKsOvJMPMYn = new Object();
    private final cJizbPrgAISXyzXrgujHPeB QPeIwmpzLZIktKLXAJOQHcO;
    private final ArrayList<lKkynTEEZVTbuSJCgDWFhnQ<Future<ZvOTVUaKFTNpNSbbMYZfoXf>>> JSuXbPLjXcQLpTiButqPpoI;
    private final LinkedBlockingQueue<Future<ZvOTVUaKFTNpNSbbMYZfoXf>> iwitQCGCnkthNoQBBlYaPUM;
    private final Thread dnqxuOOQwmxxivZzrQBWydh;
    private final ExecutorService VZagBOcdslnIaKEkojULJvx = Executors.newCachedThreadPool();

    public aWYfUFxCCDbNJVWMPiBUKrO(cJizbPrgAISXyzXrgujHPeB cJizbPrgAISXyzXrgujHPeB2, KsHoYvJaofzRsWbjpDlDnPw ksHoYvJaofzRsWbjpDlDnPw, aWYfUFxCCDbNJVWMPiBUKrO aWYfUFxCCDbNJVWMPiBUKrO2) {
        this.QPeIwmpzLZIktKLXAJOQHcO = cJizbPrgAISXyzXrgujHPeB2;
        this.JSuXbPLjXcQLpTiButqPpoI = new ArrayList(0);
        this.iwitQCGCnkthNoQBBlYaPUM = new LinkedBlockingQueue(1);
        if (aWYfUFxCCDbNJVWMPiBUKrO2 != null) {
            for (lKkynTEEZVTbuSJCgDWFhnQ<Future<ZvOTVUaKFTNpNSbbMYZfoXf>> lKkynTEEZVTbuSJCgDWFhnQ2 : aWYfUFxCCDbNJVWMPiBUKrO2.rHAjVyBgPhqkQKsOvJMPMYn()) {
                this.rHAjVyBgPhqkQKsOvJMPMYn(lKkynTEEZVTbuSJCgDWFhnQ2);
            }
        }
        this.dnqxuOOQwmxxivZzrQBWydh = new Thread(new rHAjVyBgPhqkQKsOvJMPMYn(ksHoYvJaofzRsWbjpDlDnPw, this.iwitQCGCnkthNoQBBlYaPUM));
        this.QPeIwmpzLZIktKLXAJOQHcO();
    }

    private void QPeIwmpzLZIktKLXAJOQHcO() {
        this.dnqxuOOQwmxxivZzrQBWydh.start();
    }

    @Override
    public boolean rHAjVyBgPhqkQKsOvJMPMYn(ZvOTVUaKFTNpNSbbMYZfoXf zvOTVUaKFTNpNSbbMYZfoXf) {
        QPeIwmpzLZIktKLXAJOQHcO qPeIwmpzLZIktKLXAJOQHcO = new QPeIwmpzLZIktKLXAJOQHcO(zvOTVUaKFTNpNSbbMYZfoXf);
        Future<?> future = this.VZagBOcdslnIaKEkojULJvx.submit(qPeIwmpzLZIktKLXAJOQHcO);
        try {
            future.get(200L, TimeUnit.MILLISECONDS);
        }
        catch (InterruptedException | ExecutionException | TimeoutException exception) {
            return false;
        }
        return qPeIwmpzLZIktKLXAJOQHcO.rHAjVyBgPhqkQKsOvJMPMYn();
    }

    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(YGjBevanihqaxYKnUNtrNeA yGjBevanihqaxYKnUNtrNeA, YGjBevanihqaxYKnUNtrNeA yGjBevanihqaxYKnUNtrNeA2) {
        this.QPeIwmpzLZIktKLXAJOQHcO.rHAjVyBgPhqkQKsOvJMPMYn(yGjBevanihqaxYKnUNtrNeA);
        this.QPeIwmpzLZIktKLXAJOQHcO.QPeIwmpzLZIktKLXAJOQHcO(yGjBevanihqaxYKnUNtrNeA2);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public boolean rHAjVyBgPhqkQKsOvJMPMYn(lKkynTEEZVTbuSJCgDWFhnQ<Future<ZvOTVUaKFTNpNSbbMYZfoXf>> lKkynTEEZVTbuSJCgDWFhnQ2) {
        if (lKkynTEEZVTbuSJCgDWFhnQ2 != null && !this.JSuXbPLjXcQLpTiButqPpoI.contains(lKkynTEEZVTbuSJCgDWFhnQ2)) {
            Object object = this.rHAjVyBgPhqkQKsOvJMPMYn;
            synchronized (object) {
                return this.JSuXbPLjXcQLpTiButqPpoI.add(lKkynTEEZVTbuSJCgDWFhnQ2);
            }
        }
        return false;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public boolean QPeIwmpzLZIktKLXAJOQHcO(lKkynTEEZVTbuSJCgDWFhnQ<Future<ZvOTVUaKFTNpNSbbMYZfoXf>> lKkynTEEZVTbuSJCgDWFhnQ2) {
        boolean bl;
        Object object = this.rHAjVyBgPhqkQKsOvJMPMYn;
        synchronized (object) {
            bl = this.JSuXbPLjXcQLpTiButqPpoI.remove(lKkynTEEZVTbuSJCgDWFhnQ2);
            if (bl) {
                this.iwitQCGCnkthNoQBBlYaPUM.clear();
            }
        }
        return bl;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public Future<ZvOTVUaKFTNpNSbbMYZfoXf> QPeIwmpzLZIktKLXAJOQHcO(ZvOTVUaKFTNpNSbbMYZfoXf zvOTVUaKFTNpNSbbMYZfoXf) {
        Object object = new WnqvfCcrLvcneTJidLxiKam(zvOTVUaKFTNpNSbbMYZfoXf);
        Object object2 = this.rHAjVyBgPhqkQKsOvJMPMYn;
        synchronized (object2) {
            for (lKkynTEEZVTbuSJCgDWFhnQ<Future<ZvOTVUaKFTNpNSbbMYZfoXf>> lKkynTEEZVTbuSJCgDWFhnQ2 : this.JSuXbPLjXcQLpTiButqPpoI) {
                if (lKkynTEEZVTbuSJCgDWFhnQ2 == null) continue;
                try {
                    object = lKkynTEEZVTbuSJCgDWFhnQ2.QPeIwmpzLZIktKLXAJOQHcO((ZvOTVUaKFTNpNSbbMYZfoXf)object.get());
                }
                catch (InterruptedException | ExecutionException exception) {
                    Logger.getLogger(aWYfUFxCCDbNJVWMPiBUKrO.class.getName()).log(Level.SEVERE, null, exception);
                    return new WnqvfCcrLvcneTJidLxiKam(zvOTVUaKFTNpNSbbMYZfoXf);
                }
            }
        }
        return object;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public List<lKkynTEEZVTbuSJCgDWFhnQ<Future<ZvOTVUaKFTNpNSbbMYZfoXf>>> rHAjVyBgPhqkQKsOvJMPMYn() {
        Object object = this.rHAjVyBgPhqkQKsOvJMPMYn;
        synchronized (object) {
            return Collections.unmodifiableList(this.JSuXbPLjXcQLpTiButqPpoI);
        }
    }

    private class QPeIwmpzLZIktKLXAJOQHcO
    implements Runnable {
        private final ZvOTVUaKFTNpNSbbMYZfoXf QPeIwmpzLZIktKLXAJOQHcO;
        private boolean JSuXbPLjXcQLpTiButqPpoI = true;

        QPeIwmpzLZIktKLXAJOQHcO(ZvOTVUaKFTNpNSbbMYZfoXf zvOTVUaKFTNpNSbbMYZfoXf) {
            this.QPeIwmpzLZIktKLXAJOQHcO = zvOTVUaKFTNpNSbbMYZfoXf;
        }

        /*
         * WARNING - Removed try catching itself - possible behaviour change.
         */
        @Override
        public void run() {
            Thread.currentThread().setName("WriteSampleWorker");
            aWYfUFxCCDbNJVWMPiBUKrO.this.QPeIwmpzLZIktKLXAJOQHcO.rHAjVyBgPhqkQKsOvJMPMYn(this.QPeIwmpzLZIktKLXAJOQHcO);
            aWYfUFxCCDbNJVWMPiBUKrO.this.QPeIwmpzLZIktKLXAJOQHcO.QPeIwmpzLZIktKLXAJOQHcO();
            Object object = aWYfUFxCCDbNJVWMPiBUKrO.this.rHAjVyBgPhqkQKsOvJMPMYn;
            synchronized (object) {
                Future<ZvOTVUaKFTNpNSbbMYZfoXf> future = aWYfUFxCCDbNJVWMPiBUKrO.this.QPeIwmpzLZIktKLXAJOQHcO(this.QPeIwmpzLZIktKLXAJOQHcO);
                try {
                    aWYfUFxCCDbNJVWMPiBUKrO.this.iwitQCGCnkthNoQBBlYaPUM.put(future);
                }
                catch (InterruptedException interruptedException) {
                    Logger.getLogger(aWYfUFxCCDbNJVWMPiBUKrO.class.getName()).log(Level.SEVERE, null, interruptedException);
                    this.JSuXbPLjXcQLpTiButqPpoI = false;
                }
            }
        }

        public boolean rHAjVyBgPhqkQKsOvJMPMYn() {
            return this.JSuXbPLjXcQLpTiButqPpoI;
        }
    }

    private class rHAjVyBgPhqkQKsOvJMPMYn
    implements Runnable {
        private final KsHoYvJaofzRsWbjpDlDnPw QPeIwmpzLZIktKLXAJOQHcO;
        private final LinkedBlockingQueue<Future<ZvOTVUaKFTNpNSbbMYZfoXf>> JSuXbPLjXcQLpTiButqPpoI;

        private rHAjVyBgPhqkQKsOvJMPMYn(KsHoYvJaofzRsWbjpDlDnPw ksHoYvJaofzRsWbjpDlDnPw, LinkedBlockingQueue<Future<ZvOTVUaKFTNpNSbbMYZfoXf>> linkedBlockingQueue) {
            this.QPeIwmpzLZIktKLXAJOQHcO = ksHoYvJaofzRsWbjpDlDnPw;
            this.JSuXbPLjXcQLpTiButqPpoI = linkedBlockingQueue;
        }

        @Override
        public void run() {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    Future<ZvOTVUaKFTNpNSbbMYZfoXf> future = this.JSuXbPLjXcQLpTiButqPpoI.take();
                    this.QPeIwmpzLZIktKLXAJOQHcO.rHAjVyBgPhqkQKsOvJMPMYn(future.get());
                }
                catch (InterruptedException | ExecutionException exception) {
                    Logger.getLogger(aWYfUFxCCDbNJVWMPiBUKrO.class.getName()).log(Level.SEVERE, null, exception);
                }
            }
        }
    }
}

