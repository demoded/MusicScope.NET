/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.EjrvtUxaUIJixnuJbyIXpxs;

public enum AGpEswewZOXTtopHPFqtErb {
    rHAjVyBgPhqkQKsOvJMPMYn("m4a", EjrvtUxaUIJixnuJbyIXpxs.rHAjVyBgPhqkQKsOvJMPMYn),
    QPeIwmpzLZIktKLXAJOQHcO("m4a", EjrvtUxaUIJixnuJbyIXpxs.rHAjVyBgPhqkQKsOvJMPMYn),
    JSuXbPLjXcQLpTiButqPpoI("wav", EjrvtUxaUIJixnuJbyIXpxs.rHAjVyBgPhqkQKsOvJMPMYn),
    iwitQCGCnkthNoQBBlYaPUM("wav", EjrvtUxaUIJixnuJbyIXpxs.rHAjVyBgPhqkQKsOvJMPMYn),
    dnqxuOOQwmxxivZzrQBWydh("flac", EjrvtUxaUIJixnuJbyIXpxs.rHAjVyBgPhqkQKsOvJMPMYn),
    VZagBOcdslnIaKEkojULJvx("dsf", EjrvtUxaUIJixnuJbyIXpxs.QPeIwmpzLZIktKLXAJOQHcO),
    VmkNmvoUyyfcyaaKFyveguY("dff", EjrvtUxaUIJixnuJbyIXpxs.QPeIwmpzLZIktKLXAJOQHcO),
    YGjBevanihqaxYKnUNtrNeA("mp3", EjrvtUxaUIJixnuJbyIXpxs.rHAjVyBgPhqkQKsOvJMPMYn),
    wunjGuaHWPKejzkQKUJfPKe("aif", EjrvtUxaUIJixnuJbyIXpxs.rHAjVyBgPhqkQKsOvJMPMYn),
    NuCoRkdmXmpraThwzNAiTcw("", EjrvtUxaUIJixnuJbyIXpxs.rHAjVyBgPhqkQKsOvJMPMYn),
    OrmpCzNZzYDlbDZDBXyofLf("", EjrvtUxaUIJixnuJbyIXpxs.rHAjVyBgPhqkQKsOvJMPMYn),
    ibbBhgWhrhhiOLwDlcriPhb("", EjrvtUxaUIJixnuJbyIXpxs.JSuXbPLjXcQLpTiButqPpoI);

    private final String kVXnygMrAwyMajIgLatcyWS;
    private final EjrvtUxaUIJixnuJbyIXpxs vJgxuXjYdOvTUFZsFThavLL;

    private AGpEswewZOXTtopHPFqtErb(String string2, EjrvtUxaUIJixnuJbyIXpxs ejrvtUxaUIJixnuJbyIXpxs) {
        this.kVXnygMrAwyMajIgLatcyWS = string2;
        this.vJgxuXjYdOvTUFZsFThavLL = ejrvtUxaUIJixnuJbyIXpxs;
    }

    public String rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.kVXnygMrAwyMajIgLatcyWS;
    }

    public EjrvtUxaUIJixnuJbyIXpxs QPeIwmpzLZIktKLXAJOQHcO() {
        return this.vJgxuXjYdOvTUFZsFThavLL;
    }
}

