/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package sdfgjkljljoftrytrszgijpokjprs;

import com.google.gson.annotations.SerializedName;
import sdfgjkljljoftrytrszgijpokjprs.fikLFfybOLBBPFzDSaJuDxU;

public class fkymSnbJojnjWTHxKogeOzr {
    @SerializedName(value="album")
    private final fikLFfybOLBBPFzDSaJuDxU rHAjVyBgPhqkQKsOvJMPMYn;

    public fkymSnbJojnjWTHxKogeOzr(fikLFfybOLBBPFzDSaJuDxU fikLFfybOLBBPFzDSaJuDxU2) {
        this.rHAjVyBgPhqkQKsOvJMPMYn = fikLFfybOLBBPFzDSaJuDxU2;
    }
}

