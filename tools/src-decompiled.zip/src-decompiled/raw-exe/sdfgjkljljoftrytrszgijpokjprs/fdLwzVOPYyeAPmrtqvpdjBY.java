/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

public interface fdLwzVOPYyeAPmrtqvpdjBY {
    public void rHAjVyBgPhqkQKsOvJMPMYn(int var1);
}

