/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.io.Files
 */
package sdfgjkljljoftrytrszgijpokjprs;

import com.google.common.io.Files;
import com.xivero.hraa.icons.Icons;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FilenameFilter;
import java.util.Arrays;
import java.util.ResourceBundle;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import sdfgjkljljoftrytrszgijpokjprs.AGpEswewZOXTtopHPFqtErb;
import sdfgjkljljoftrytrszgijpokjprs.BtSxiFJlPwYFcLNMFEsrKYC;
import sdfgjkljljoftrytrszgijpokjprs.HAfXhvYubJkskjSMlFLLdgY;
import sdfgjkljljoftrytrszgijpokjprs.MhVrMnbsUmIgwNYekMCIkde;
import sdfgjkljljoftrytrszgijpokjprs.NmkQXzdXSthcCtycxNGkyHA;
import sdfgjkljljoftrytrszgijpokjprs.YGjBevanihqaxYKnUNtrNeA;
import sdfgjkljljoftrytrszgijpokjprs.YzXXpcCCVJkKMcoHoACbjGG;
import sdfgjkljljoftrytrszgijpokjprs.ZjoyaRSokkGYDwXHPKTBIiX;
import sdfgjkljljoftrytrszgijpokjprs.kfrVEsKUvFeBfAoSkvCCRmV;
import sdfgjkljljoftrytrszgijpokjprs.lXCOGwZXVelwEKHMMPwpSAO;
import sdfgjkljljoftrytrszgijpokjprs.tSwCDjQKHwQVvbvetpZIATg;

public class GGiRamzaArNdRQDukShvdNU
extends JPanel
implements HAfXhvYubJkskjSMlFLLdgY,
MhVrMnbsUmIgwNYekMCIkde {
    public static final String[] rHAjVyBgPhqkQKsOvJMPMYn = new String[]{"wav", "dff", "dsf", "flac", "m4a", "aif", "aiff", "mp3"};
    private static final long serialVersionUID = 1L;
    private final String[] QPeIwmpzLZIktKLXAJOQHcO = new String[]{"wav"};
    private final String[] JSuXbPLjXcQLpTiButqPpoI = new String[]{"dff", "dsf"};
    private final String[] iwitQCGCnkthNoQBBlYaPUM = new String[]{"flac"};
    private final String[] dnqxuOOQwmxxivZzrQBWydh = new String[]{"m4a"};
    private final String[] VZagBOcdslnIaKEkojULJvx = new String[]{"mp3"};
    private final String[] VmkNmvoUyyfcyaaKFyveguY = new String[]{"aif", "aiff"};
    private final NmkQXzdXSthcCtycxNGkyHA YGjBevanihqaxYKnUNtrNeA = NmkQXzdXSthcCtycxNGkyHA.rHAjVyBgPhqkQKsOvJMPMYn();
    private final JFrame wunjGuaHWPKejzkQKUJfPKe = new JFrame();
    private final FileDialog NuCoRkdmXmpraThwzNAiTcw;
    private tSwCDjQKHwQVvbvetpZIATg OrmpCzNZzYDlbDZDBXyofLf;
    private BtSxiFJlPwYFcLNMFEsrKYC ibbBhgWhrhhiOLwDlcriPhb;
    private AGpEswewZOXTtopHPFqtErb kVXnygMrAwyMajIgLatcyWS;
    private final ResourceBundle vJgxuXjYdOvTUFZsFThavLL = ResourceBundle.getBundle("com/xivero/hraa/gui/control/player/Strings");
    private JButton FoVkhFqKjpvomrYQnnVFKwY;
    private JButton kMqExmRlFLPTFqBDauCBKYL;
    private JButton uAGKHXCiDSbltWOPIpXUgwC;
    private JButton TNdBwPzcCrGifNBGlgVkPGL;

    public GGiRamzaArNdRQDukShvdNU() {
        this.rHAjVyBgPhqkQKsOvJMPMYn();
        this.NuCoRkdmXmpraThwzNAiTcw = new FileDialog(this.wunjGuaHWPKejzkQKUJfPKe);
        this.NuCoRkdmXmpraThwzNAiTcw.setMultipleMode(true);
        this.NuCoRkdmXmpraThwzNAiTcw.setMode(0);
        if (YzXXpcCCVJkKMcoHoACbjGG.QPeIwmpzLZIktKLXAJOQHcO()) {
            String string = "";
            for (String string2 : rHAjVyBgPhqkQKsOvJMPMYn) {
                string = string + "*." + string2 + ";";
            }
            this.NuCoRkdmXmpraThwzNAiTcw.setFile(string);
        }
        this.NuCoRkdmXmpraThwzNAiTcw.setFilenameFilter(new FilenameFilter(){

            @Override
            public boolean accept(File file, String string) {
                return Arrays.asList(rHAjVyBgPhqkQKsOvJMPMYn).contains(Files.getFileExtension((String)string));
            }
        });
        this.rHAjVyBgPhqkQKsOvJMPMYn(NmkQXzdXSthcCtycxNGkyHA.rHAjVyBgPhqkQKsOvJMPMYn().QPeIwmpzLZIktKLXAJOQHcO());
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(tSwCDjQKHwQVvbvetpZIATg tSwCDjQKHwQVvbvetpZIATg2) {
        this.OrmpCzNZzYDlbDZDBXyofLf = tSwCDjQKHwQVvbvetpZIATg2;
        this.ibbBhgWhrhhiOLwDlcriPhb = new BtSxiFJlPwYFcLNMFEsrKYC(tSwCDjQKHwQVvbvetpZIATg2);
    }

    private void rHAjVyBgPhqkQKsOvJMPMYn() {
        this.kMqExmRlFLPTFqBDauCBKYL = new JButton();
        this.TNdBwPzcCrGifNBGlgVkPGL = new JButton();
        this.uAGKHXCiDSbltWOPIpXUgwC = new JButton();
        this.FoVkhFqKjpvomrYQnnVFKwY = new JButton();
        this.setBackground(new Color(0, 0, 0));
        this.setLayout(new GridLayout(1, 0));
        this.kMqExmRlFLPTFqBDauCBKYL.setBackground(new Color(0, 0, 0));
        this.kMqExmRlFLPTFqBDauCBKYL.setForeground(new Color(255, 255, 255));
        this.kMqExmRlFLPTFqBDauCBKYL.setIcon(new ImageIcon(this.getClass().getResource("/com/xivero/hraa/icons/folder.png")));
        this.kMqExmRlFLPTFqBDauCBKYL.setBorder(null);
        this.kMqExmRlFLPTFqBDauCBKYL.setBorderPainted(false);
        this.kMqExmRlFLPTFqBDauCBKYL.setContentAreaFilled(false);
        this.kMqExmRlFLPTFqBDauCBKYL.setFocusPainted(false);
        this.kMqExmRlFLPTFqBDauCBKYL.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                GGiRamzaArNdRQDukShvdNU.this.rHAjVyBgPhqkQKsOvJMPMYn(actionEvent);
            }
        });
        this.add(this.kMqExmRlFLPTFqBDauCBKYL);
        this.TNdBwPzcCrGifNBGlgVkPGL.setBackground(new Color(0, 0, 0));
        this.TNdBwPzcCrGifNBGlgVkPGL.setForeground(new Color(255, 255, 255));
        this.TNdBwPzcCrGifNBGlgVkPGL.setIcon(new ImageIcon(this.getClass().getResource("/com/xivero/hraa/icons/stop.png")));
        this.TNdBwPzcCrGifNBGlgVkPGL.setBorder(null);
        this.TNdBwPzcCrGifNBGlgVkPGL.setBorderPainted(false);
        this.TNdBwPzcCrGifNBGlgVkPGL.setContentAreaFilled(false);
        this.TNdBwPzcCrGifNBGlgVkPGL.setFocusPainted(false);
        this.TNdBwPzcCrGifNBGlgVkPGL.setMinimumSize(new Dimension(55, 22));
        this.TNdBwPzcCrGifNBGlgVkPGL.setPreferredSize(new Dimension(55, 22));
        this.TNdBwPzcCrGifNBGlgVkPGL.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                GGiRamzaArNdRQDukShvdNU.this.QPeIwmpzLZIktKLXAJOQHcO(actionEvent);
            }
        });
        this.add(this.TNdBwPzcCrGifNBGlgVkPGL);
        this.uAGKHXCiDSbltWOPIpXUgwC.setBackground(new Color(0, 0, 0));
        this.uAGKHXCiDSbltWOPIpXUgwC.setForeground(new Color(255, 255, 255));
        this.uAGKHXCiDSbltWOPIpXUgwC.setIcon(new ImageIcon(this.getClass().getResource("/com/xivero/hraa/icons/play.png")));
        this.uAGKHXCiDSbltWOPIpXUgwC.setBorder(null);
        this.uAGKHXCiDSbltWOPIpXUgwC.setBorderPainted(false);
        this.uAGKHXCiDSbltWOPIpXUgwC.setContentAreaFilled(false);
        this.uAGKHXCiDSbltWOPIpXUgwC.setFocusPainted(false);
        this.uAGKHXCiDSbltWOPIpXUgwC.setMinimumSize(new Dimension(55, 22));
        this.uAGKHXCiDSbltWOPIpXUgwC.setPreferredSize(new Dimension(55, 22));
        this.uAGKHXCiDSbltWOPIpXUgwC.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                GGiRamzaArNdRQDukShvdNU.this.iwitQCGCnkthNoQBBlYaPUM(actionEvent);
            }
        });
        this.add(this.uAGKHXCiDSbltWOPIpXUgwC);
        this.FoVkhFqKjpvomrYQnnVFKwY.setBackground(new Color(0, 0, 0));
        this.FoVkhFqKjpvomrYQnnVFKwY.setForeground(new Color(255, 255, 255));
        this.FoVkhFqKjpvomrYQnnVFKwY.setIcon(new ImageIcon(this.getClass().getResource("/com/xivero/hraa/icons/research.png")));
        this.FoVkhFqKjpvomrYQnnVFKwY.setBorder(null);
        this.FoVkhFqKjpvomrYQnnVFKwY.setBorderPainted(false);
        this.FoVkhFqKjpvomrYQnnVFKwY.setContentAreaFilled(false);
        this.FoVkhFqKjpvomrYQnnVFKwY.setFocusPainted(false);
        this.FoVkhFqKjpvomrYQnnVFKwY.setPreferredSize(new Dimension(55, 22));
        this.FoVkhFqKjpvomrYQnnVFKwY.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                GGiRamzaArNdRQDukShvdNU.this.JSuXbPLjXcQLpTiButqPpoI(actionEvent);
            }
        });
        this.add(this.FoVkhFqKjpvomrYQnnVFKwY);
    }

    private void rHAjVyBgPhqkQKsOvJMPMYn(ActionEvent actionEvent) {
        kfrVEsKUvFeBfAoSkvCCRmV kfrVEsKUvFeBfAoSkvCCRmV2 = kfrVEsKUvFeBfAoSkvCCRmV.rHAjVyBgPhqkQKsOvJMPMYn();
        if (this.ibbBhgWhrhhiOLwDlcriPhb != null) {
            this.NuCoRkdmXmpraThwzNAiTcw.setVisible(true);
            File[] fileArray = this.NuCoRkdmXmpraThwzNAiTcw.getFiles();
            if (fileArray.length > 0) {
                if (fileArray.length > 1) {
                    for (File file : fileArray) {
                        if (!Arrays.asList(rHAjVyBgPhqkQKsOvJMPMYn).contains(Files.getFileExtension((String)file.getAbsolutePath()).toLowerCase())) continue;
                        this.ibbBhgWhrhhiOLwDlcriPhb.rHAjVyBgPhqkQKsOvJMPMYn(file);
                    }
                    this.ibbBhgWhrhhiOLwDlcriPhb.rHAjVyBgPhqkQKsOvJMPMYn();
                } else if (Arrays.asList(rHAjVyBgPhqkQKsOvJMPMYn).contains(Files.getFileExtension((String)this.NuCoRkdmXmpraThwzNAiTcw.getFiles()[0].getAbsolutePath()).toLowerCase())) {
                    if (kfrVEsKUvFeBfAoSkvCCRmV2.QPeIwmpzLZIktKLXAJOQHcO()) {
                        kfrVEsKUvFeBfAoSkvCCRmV2.rHAjVyBgPhqkQKsOvJMPMYn(this.NuCoRkdmXmpraThwzNAiTcw.getFiles()[0].getAbsolutePath());
                        kfrVEsKUvFeBfAoSkvCCRmV2.rHAjVyBgPhqkQKsOvJMPMYn(true);
                    } else {
                        this.ibbBhgWhrhhiOLwDlcriPhb.rHAjVyBgPhqkQKsOvJMPMYn(this.NuCoRkdmXmpraThwzNAiTcw.getFiles()[0]);
                        this.ibbBhgWhrhhiOLwDlcriPhb.rHAjVyBgPhqkQKsOvJMPMYn();
                    }
                }
            }
        }
    }

    private void QPeIwmpzLZIktKLXAJOQHcO(ActionEvent actionEvent) {
        if (this.OrmpCzNZzYDlbDZDBXyofLf != null && this.YGjBevanihqaxYKnUNtrNeA.QPeIwmpzLZIktKLXAJOQHcO(lXCOGwZXVelwEKHMMPwpSAO.iwitQCGCnkthNoQBBlYaPUM)) {
            this.OrmpCzNZzYDlbDZDBXyofLf.JSuXbPLjXcQLpTiButqPpoI();
        } else if (this.OrmpCzNZzYDlbDZDBXyofLf != null && this.YGjBevanihqaxYKnUNtrNeA.QPeIwmpzLZIktKLXAJOQHcO(lXCOGwZXVelwEKHMMPwpSAO.JSuXbPLjXcQLpTiButqPpoI)) {
            this.OrmpCzNZzYDlbDZDBXyofLf.QPeIwmpzLZIktKLXAJOQHcO();
        }
    }

    private void JSuXbPLjXcQLpTiButqPpoI(ActionEvent actionEvent) {
        if (this.OrmpCzNZzYDlbDZDBXyofLf != null) {
            this.OrmpCzNZzYDlbDZDBXyofLf.iwitQCGCnkthNoQBBlYaPUM();
        }
    }

    private void iwitQCGCnkthNoQBBlYaPUM(ActionEvent actionEvent) {
        if (this.OrmpCzNZzYDlbDZDBXyofLf != null) {
            this.OrmpCzNZzYDlbDZDBXyofLf.dnqxuOOQwmxxivZzrQBWydh();
        }
    }

    @Override
    public final void rHAjVyBgPhqkQKsOvJMPMYn(ZjoyaRSokkGYDwXHPKTBIiX zjoyaRSokkGYDwXHPKTBIiX) {
        this.FoVkhFqKjpvomrYQnnVFKwY.setEnabled(this.YGjBevanihqaxYKnUNtrNeA.QPeIwmpzLZIktKLXAJOQHcO(lXCOGwZXVelwEKHMMPwpSAO.VmkNmvoUyyfcyaaKFyveguY) && !this.QPeIwmpzLZIktKLXAJOQHcO());
        this.uAGKHXCiDSbltWOPIpXUgwC.setEnabled(this.YGjBevanihqaxYKnUNtrNeA.QPeIwmpzLZIktKLXAJOQHcO(lXCOGwZXVelwEKHMMPwpSAO.YGjBevanihqaxYKnUNtrNeA));
        this.kMqExmRlFLPTFqBDauCBKYL.setEnabled(this.YGjBevanihqaxYKnUNtrNeA.QPeIwmpzLZIktKLXAJOQHcO(lXCOGwZXVelwEKHMMPwpSAO.rHAjVyBgPhqkQKsOvJMPMYn));
        this.rHAjVyBgPhqkQKsOvJMPMYn(this.YGjBevanihqaxYKnUNtrNeA);
    }

    private void rHAjVyBgPhqkQKsOvJMPMYn(NmkQXzdXSthcCtycxNGkyHA nmkQXzdXSthcCtycxNGkyHA) {
        if (nmkQXzdXSthcCtycxNGkyHA.QPeIwmpzLZIktKLXAJOQHcO(lXCOGwZXVelwEKHMMPwpSAO.iwitQCGCnkthNoQBBlYaPUM)) {
            this.TNdBwPzcCrGifNBGlgVkPGL.setIcon(new ImageIcon(Icons.class.getResource("pause.png")));
            this.TNdBwPzcCrGifNBGlgVkPGL.setEnabled(true);
        } else if (nmkQXzdXSthcCtycxNGkyHA.QPeIwmpzLZIktKLXAJOQHcO(lXCOGwZXVelwEKHMMPwpSAO.JSuXbPLjXcQLpTiButqPpoI)) {
            this.TNdBwPzcCrGifNBGlgVkPGL.setIcon(new ImageIcon(Icons.class.getResource("stop.png")));
            this.TNdBwPzcCrGifNBGlgVkPGL.setEnabled(true);
        } else {
            this.TNdBwPzcCrGifNBGlgVkPGL.setIcon(new ImageIcon(Icons.class.getResource("stop.png")));
            this.TNdBwPzcCrGifNBGlgVkPGL.setEnabled(false);
        }
    }

    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(YGjBevanihqaxYKnUNtrNeA yGjBevanihqaxYKnUNtrNeA, YGjBevanihqaxYKnUNtrNeA yGjBevanihqaxYKnUNtrNeA2) {
        this.kVXnygMrAwyMajIgLatcyWS = yGjBevanihqaxYKnUNtrNeA.NuCoRkdmXmpraThwzNAiTcw();
    }

    private boolean QPeIwmpzLZIktKLXAJOQHcO() {
        return this.kVXnygMrAwyMajIgLatcyWS == AGpEswewZOXTtopHPFqtErb.NuCoRkdmXmpraThwzNAiTcw || this.kVXnygMrAwyMajIgLatcyWS == AGpEswewZOXTtopHPFqtErb.OrmpCzNZzYDlbDZDBXyofLf;
    }
}

