/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.fegnCROFfntWhihpSdONLyP;

public class AslFQuXDSXcUlvqmnZBFpYW {
    double rHAjVyBgPhqkQKsOvJMPMYn;
    double QPeIwmpzLZIktKLXAJOQHcO;
    double JSuXbPLjXcQLpTiButqPpoI;
    double iwitQCGCnkthNoQBBlYaPUM;
    @fegnCROFfntWhihpSdONLyP(rHAjVyBgPhqkQKsOvJMPMYn="TPL Left:", QPeIwmpzLZIktKLXAJOQHcO="dB")
    double dnqxuOOQwmxxivZzrQBWydh;
    @fegnCROFfntWhihpSdONLyP(rHAjVyBgPhqkQKsOvJMPMYn="TPL Right:", QPeIwmpzLZIktKLXAJOQHcO="dB")
    double VZagBOcdslnIaKEkojULJvx;
    @fegnCROFfntWhihpSdONLyP(rHAjVyBgPhqkQKsOvJMPMYn="TPL Mid:", QPeIwmpzLZIktKLXAJOQHcO="dB")
    double VmkNmvoUyyfcyaaKFyveguY;
    @fegnCROFfntWhihpSdONLyP(rHAjVyBgPhqkQKsOvJMPMYn="TPL Side:", QPeIwmpzLZIktKLXAJOQHcO="dB")
    double YGjBevanihqaxYKnUNtrNeA;
    @fegnCROFfntWhihpSdONLyP(rHAjVyBgPhqkQKsOvJMPMYn="RMS Left:", QPeIwmpzLZIktKLXAJOQHcO="dB")
    double wunjGuaHWPKejzkQKUJfPKe;
    @fegnCROFfntWhihpSdONLyP(rHAjVyBgPhqkQKsOvJMPMYn="RMS Right:", QPeIwmpzLZIktKLXAJOQHcO="dB")
    double NuCoRkdmXmpraThwzNAiTcw;
    @fegnCROFfntWhihpSdONLyP(rHAjVyBgPhqkQKsOvJMPMYn="RMS Mid:", QPeIwmpzLZIktKLXAJOQHcO="dB")
    double OrmpCzNZzYDlbDZDBXyofLf;
    @fegnCROFfntWhihpSdONLyP(rHAjVyBgPhqkQKsOvJMPMYn="RMS Side:", QPeIwmpzLZIktKLXAJOQHcO="dB")
    double ibbBhgWhrhhiOLwDlcriPhb;
    @fegnCROFfntWhihpSdONLyP(rHAjVyBgPhqkQKsOvJMPMYn="CREST Avg.:", QPeIwmpzLZIktKLXAJOQHcO="dB")
    double kVXnygMrAwyMajIgLatcyWS;
    @fegnCROFfntWhihpSdONLyP(rHAjVyBgPhqkQKsOvJMPMYn="IS L/M:", JSuXbPLjXcQLpTiButqPpoI={"DSD"})
    int vJgxuXjYdOvTUFZsFThavLL;
    @fegnCROFfntWhihpSdONLyP(rHAjVyBgPhqkQKsOvJMPMYn="IS R/S:", JSuXbPLjXcQLpTiButqPpoI={"DSD"})
    int FoVkhFqKjpvomrYQnnVFKwY;
    double kMqExmRlFLPTFqBDauCBKYL;
    double uAGKHXCiDSbltWOPIpXUgwC;
    double TNdBwPzcCrGifNBGlgVkPGL;
    String CWUsTkhDhNSqiWmIUfrczRE;
    String XphHMDaiRLyTnLXiOVlLPqZ;
    boolean cmBIzvlUaDPTiIjykjjmigy;
    boolean NwteqrdXWwWpaoJmiBDNxxz;
    double SYnuCfTgzCxensnEBdDedFe;
    double ajlSZBxlJSwYUTeUsFfhumH;
    double TTvVyJBikEjkvfEQPPobmUz;
    double IiqlRFfWYxYaAobCQvdRFEl;
    double gLHqHFGBEIDXbcqrsZzduVF;
    double xurJiSGFDQVeEtISoLSazWS;
    int[] KLSmtNpcsSwOKRbEbUKdpqL;
    int[] DamZYXCIxKyKrnRzlNpeRfa;

    public AslFQuXDSXcUlvqmnZBFpYW(double d, double d2, double d3, double d4, double d5, double d6, int n, int n2, double d7, double d8, double d9, double d10, double d11, double d12, String string, String string2, boolean bl, boolean bl2, double d13, double d14, double d15, double d16, double d17, double d18, double d19, double d20, double d21, double d22, int[] nArray, int[] nArray2) {
        this.rHAjVyBgPhqkQKsOvJMPMYn = d;
        this.QPeIwmpzLZIktKLXAJOQHcO = d2;
        this.JSuXbPLjXcQLpTiButqPpoI = d3;
        this.iwitQCGCnkthNoQBBlYaPUM = d4;
        this.dnqxuOOQwmxxivZzrQBWydh = d5;
        this.VZagBOcdslnIaKEkojULJvx = d6;
        this.vJgxuXjYdOvTUFZsFThavLL = n;
        this.FoVkhFqKjpvomrYQnnVFKwY = n2;
        this.kMqExmRlFLPTFqBDauCBKYL = d7;
        this.uAGKHXCiDSbltWOPIpXUgwC = d8;
        this.TNdBwPzcCrGifNBGlgVkPGL = d9;
        this.kVXnygMrAwyMajIgLatcyWS = d10;
        this.wunjGuaHWPKejzkQKUJfPKe = d11;
        this.NuCoRkdmXmpraThwzNAiTcw = d12;
        this.CWUsTkhDhNSqiWmIUfrczRE = string;
        this.XphHMDaiRLyTnLXiOVlLPqZ = string2;
        this.cmBIzvlUaDPTiIjykjjmigy = bl;
        this.NwteqrdXWwWpaoJmiBDNxxz = bl2;
        this.SYnuCfTgzCxensnEBdDedFe = d13;
        this.ajlSZBxlJSwYUTeUsFfhumH = d14;
        this.TTvVyJBikEjkvfEQPPobmUz = d15;
        this.IiqlRFfWYxYaAobCQvdRFEl = d16;
        this.VmkNmvoUyyfcyaaKFyveguY = d17;
        this.YGjBevanihqaxYKnUNtrNeA = d18;
        this.gLHqHFGBEIDXbcqrsZzduVF = d19;
        this.xurJiSGFDQVeEtISoLSazWS = d20;
        this.OrmpCzNZzYDlbDZDBXyofLf = d21;
        this.ibbBhgWhrhhiOLwDlcriPhb = d22;
        this.KLSmtNpcsSwOKRbEbUKdpqL = nArray;
        this.DamZYXCIxKyKrnRzlNpeRfa = nArray2;
    }

    public AslFQuXDSXcUlvqmnZBFpYW(AslFQuXDSXcUlvqmnZBFpYW aslFQuXDSXcUlvqmnZBFpYW) {
        this(aslFQuXDSXcUlvqmnZBFpYW.rHAjVyBgPhqkQKsOvJMPMYn(), aslFQuXDSXcUlvqmnZBFpYW.QPeIwmpzLZIktKLXAJOQHcO(), aslFQuXDSXcUlvqmnZBFpYW.JSuXbPLjXcQLpTiButqPpoI(), aslFQuXDSXcUlvqmnZBFpYW.iwitQCGCnkthNoQBBlYaPUM(), aslFQuXDSXcUlvqmnZBFpYW.dnqxuOOQwmxxivZzrQBWydh(), aslFQuXDSXcUlvqmnZBFpYW.VZagBOcdslnIaKEkojULJvx(), aslFQuXDSXcUlvqmnZBFpYW.VmkNmvoUyyfcyaaKFyveguY(), aslFQuXDSXcUlvqmnZBFpYW.YGjBevanihqaxYKnUNtrNeA(), aslFQuXDSXcUlvqmnZBFpYW.wunjGuaHWPKejzkQKUJfPKe(), aslFQuXDSXcUlvqmnZBFpYW.NuCoRkdmXmpraThwzNAiTcw(), aslFQuXDSXcUlvqmnZBFpYW.OrmpCzNZzYDlbDZDBXyofLf(), aslFQuXDSXcUlvqmnZBFpYW.ibbBhgWhrhhiOLwDlcriPhb(), aslFQuXDSXcUlvqmnZBFpYW.kVXnygMrAwyMajIgLatcyWS(), aslFQuXDSXcUlvqmnZBFpYW.vJgxuXjYdOvTUFZsFThavLL(), aslFQuXDSXcUlvqmnZBFpYW.FoVkhFqKjpvomrYQnnVFKwY(), aslFQuXDSXcUlvqmnZBFpYW.kMqExmRlFLPTFqBDauCBKYL(), aslFQuXDSXcUlvqmnZBFpYW.uAGKHXCiDSbltWOPIpXUgwC(), aslFQuXDSXcUlvqmnZBFpYW.TNdBwPzcCrGifNBGlgVkPGL(), aslFQuXDSXcUlvqmnZBFpYW.CWUsTkhDhNSqiWmIUfrczRE(), aslFQuXDSXcUlvqmnZBFpYW.XphHMDaiRLyTnLXiOVlLPqZ(), aslFQuXDSXcUlvqmnZBFpYW.cmBIzvlUaDPTiIjykjjmigy(), aslFQuXDSXcUlvqmnZBFpYW.NwteqrdXWwWpaoJmiBDNxxz(), aslFQuXDSXcUlvqmnZBFpYW.SYnuCfTgzCxensnEBdDedFe(), aslFQuXDSXcUlvqmnZBFpYW.ajlSZBxlJSwYUTeUsFfhumH(), aslFQuXDSXcUlvqmnZBFpYW.TTvVyJBikEjkvfEQPPobmUz(), aslFQuXDSXcUlvqmnZBFpYW.IiqlRFfWYxYaAobCQvdRFEl(), aslFQuXDSXcUlvqmnZBFpYW.gLHqHFGBEIDXbcqrsZzduVF(), aslFQuXDSXcUlvqmnZBFpYW.xurJiSGFDQVeEtISoLSazWS(), aslFQuXDSXcUlvqmnZBFpYW.KLSmtNpcsSwOKRbEbUKdpqL(), aslFQuXDSXcUlvqmnZBFpYW.DamZYXCIxKyKrnRzlNpeRfa());
    }

    public double rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }

    public double QPeIwmpzLZIktKLXAJOQHcO() {
        return this.QPeIwmpzLZIktKLXAJOQHcO;
    }

    public double JSuXbPLjXcQLpTiButqPpoI() {
        return this.JSuXbPLjXcQLpTiButqPpoI;
    }

    public double iwitQCGCnkthNoQBBlYaPUM() {
        return this.iwitQCGCnkthNoQBBlYaPUM;
    }

    public double dnqxuOOQwmxxivZzrQBWydh() {
        return this.dnqxuOOQwmxxivZzrQBWydh;
    }

    public double VZagBOcdslnIaKEkojULJvx() {
        return this.VZagBOcdslnIaKEkojULJvx;
    }

    public int VmkNmvoUyyfcyaaKFyveguY() {
        return this.vJgxuXjYdOvTUFZsFThavLL;
    }

    public int YGjBevanihqaxYKnUNtrNeA() {
        return this.FoVkhFqKjpvomrYQnnVFKwY;
    }

    public double wunjGuaHWPKejzkQKUJfPKe() {
        return this.kMqExmRlFLPTFqBDauCBKYL;
    }

    public double NuCoRkdmXmpraThwzNAiTcw() {
        return this.uAGKHXCiDSbltWOPIpXUgwC;
    }

    public double OrmpCzNZzYDlbDZDBXyofLf() {
        return this.TNdBwPzcCrGifNBGlgVkPGL;
    }

    public double ibbBhgWhrhhiOLwDlcriPhb() {
        return this.kVXnygMrAwyMajIgLatcyWS;
    }

    public double kVXnygMrAwyMajIgLatcyWS() {
        return this.wunjGuaHWPKejzkQKUJfPKe;
    }

    public double vJgxuXjYdOvTUFZsFThavLL() {
        return this.NuCoRkdmXmpraThwzNAiTcw;
    }

    public String FoVkhFqKjpvomrYQnnVFKwY() {
        return this.CWUsTkhDhNSqiWmIUfrczRE;
    }

    public String kMqExmRlFLPTFqBDauCBKYL() {
        return this.XphHMDaiRLyTnLXiOVlLPqZ;
    }

    public boolean uAGKHXCiDSbltWOPIpXUgwC() {
        return this.cmBIzvlUaDPTiIjykjjmigy;
    }

    public boolean TNdBwPzcCrGifNBGlgVkPGL() {
        return this.NwteqrdXWwWpaoJmiBDNxxz;
    }

    public double CWUsTkhDhNSqiWmIUfrczRE() {
        return this.SYnuCfTgzCxensnEBdDedFe;
    }

    public double XphHMDaiRLyTnLXiOVlLPqZ() {
        return this.ajlSZBxlJSwYUTeUsFfhumH;
    }

    public double cmBIzvlUaDPTiIjykjjmigy() {
        return this.TTvVyJBikEjkvfEQPPobmUz;
    }

    public double NwteqrdXWwWpaoJmiBDNxxz() {
        return this.IiqlRFfWYxYaAobCQvdRFEl;
    }

    public double SYnuCfTgzCxensnEBdDedFe() {
        return this.VmkNmvoUyyfcyaaKFyveguY;
    }

    public double ajlSZBxlJSwYUTeUsFfhumH() {
        return this.YGjBevanihqaxYKnUNtrNeA;
    }

    public double TTvVyJBikEjkvfEQPPobmUz() {
        return this.gLHqHFGBEIDXbcqrsZzduVF;
    }

    public double IiqlRFfWYxYaAobCQvdRFEl() {
        return this.xurJiSGFDQVeEtISoLSazWS;
    }

    public double gLHqHFGBEIDXbcqrsZzduVF() {
        return this.OrmpCzNZzYDlbDZDBXyofLf;
    }

    public double xurJiSGFDQVeEtISoLSazWS() {
        return this.ibbBhgWhrhhiOLwDlcriPhb;
    }

    public int[] KLSmtNpcsSwOKRbEbUKdpqL() {
        return this.KLSmtNpcsSwOKRbEbUKdpqL;
    }

    public int[] DamZYXCIxKyKrnRzlNpeRfa() {
        return this.DamZYXCIxKyKrnRzlNpeRfa;
    }
}

