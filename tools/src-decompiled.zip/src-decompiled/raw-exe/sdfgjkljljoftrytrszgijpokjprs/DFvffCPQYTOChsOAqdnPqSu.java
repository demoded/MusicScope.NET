/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.BrqrCQbbknwtebNWiMmRwch;
import sdfgjkljljoftrytrszgijpokjprs.HAfXhvYubJkskjSMlFLLdgY;
import sdfgjkljljoftrytrszgijpokjprs.KXzLGKHeRupGOUCLSJARWrw;
import sdfgjkljljoftrytrszgijpokjprs.LwMnHLCbJlVyuQgcwIapPMa;
import sdfgjkljljoftrytrszgijpokjprs.NusIkxnhKbIEOcBmUnwuuOS;
import sdfgjkljljoftrytrszgijpokjprs.PYJBgzPCdrZnekQfrnwIPxJ;
import sdfgjkljljoftrytrszgijpokjprs.UOePwZnqrhIubqtrnzwsUoR;
import sdfgjkljljoftrytrszgijpokjprs.YGjBevanihqaxYKnUNtrNeA;
import sdfgjkljljoftrytrszgijpokjprs.ZjoyaRSokkGYDwXHPKTBIiX;
import sdfgjkljljoftrytrszgijpokjprs.ZvOTVUaKFTNpNSbbMYZfoXf;
import sdfgjkljljoftrytrszgijpokjprs.cJizbPrgAISXyzXrgujHPeB;
import sdfgjkljljoftrytrszgijpokjprs.lXCOGwZXVelwEKHMMPwpSAO;
import sdfgjkljljoftrytrszgijpokjprs.oJKdRGEwipDKnLCbDZfxxHL;
import sdfgjkljljoftrytrszgijpokjprs.rLTzSWcNicpRLKKlkUbbehc;
import sdfgjkljljoftrytrszgijpokjprs.uzZiPWteQonnOTzvIEnZmpw;

@BrqrCQbbknwtebNWiMmRwch(rHAjVyBgPhqkQKsOvJMPMYn=cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn.Loudness)
public class DFvffCPQYTOChsOAqdnPqSu
extends LwMnHLCbJlVyuQgcwIapPMa<NusIkxnhKbIEOcBmUnwuuOS>
implements HAfXhvYubJkskjSMlFLLdgY,
KXzLGKHeRupGOUCLSJARWrw,
oJKdRGEwipDKnLCbDZfxxHL<NusIkxnhKbIEOcBmUnwuuOS>,
rLTzSWcNicpRLKKlkUbbehc,
uzZiPWteQonnOTzvIEnZmpw {
    static double[] rHAjVyBgPhqkQKsOvJMPMYn = new double[19200];
    static double[] QPeIwmpzLZIktKLXAJOQHcO = new double[19200];
    static double[] JSuXbPLjXcQLpTiButqPpoI = new double[8];
    static double[] iwitQCGCnkthNoQBBlYaPUM = new double[60];
    static double[] dnqxuOOQwmxxivZzrQBWydh = new double[8];
    static int VZagBOcdslnIaKEkojULJvx = 0;
    static int VmkNmvoUyyfcyaaKFyveguY = 0;
    static int YGjBevanihqaxYKnUNtrNeA = 0;
    static int[] wunjGuaHWPKejzkQKUJfPKe = new int[800];
    static int[] NuCoRkdmXmpraThwzNAiTcw = new int[800];
    static double OrmpCzNZzYDlbDZDBXyofLf;
    static double ibbBhgWhrhhiOLwDlcriPhb;
    static double kVXnygMrAwyMajIgLatcyWS;
    static double vJgxuXjYdOvTUFZsFThavLL;
    private double SYnuCfTgzCxensnEBdDedFe;
    private double ajlSZBxlJSwYUTeUsFfhumH;
    private double TTvVyJBikEjkvfEQPPobmUz;
    private double IiqlRFfWYxYaAobCQvdRFEl;
    static int FoVkhFqKjpvomrYQnnVFKwY;
    static int kMqExmRlFLPTFqBDauCBKYL;
    static int uAGKHXCiDSbltWOPIpXUgwC;
    static int TNdBwPzcCrGifNBGlgVkPGL;
    static int CWUsTkhDhNSqiWmIUfrczRE;
    static int XphHMDaiRLyTnLXiOVlLPqZ;
    private static int gLHqHFGBEIDXbcqrsZzduVF;
    private static int xurJiSGFDQVeEtISoLSazWS;
    private static int KLSmtNpcsSwOKRbEbUKdpqL;
    private static int DamZYXCIxKyKrnRzlNpeRfa;
    private NusIkxnhKbIEOcBmUnwuuOS ggsqrqYbiokXEjuGiCwGpvf;
    UOePwZnqrhIubqtrnzwsUoR cmBIzvlUaDPTiIjykjjmigy;
    PYJBgzPCdrZnekQfrnwIPxJ NwteqrdXWwWpaoJmiBDNxxz = this.rHAjVyBgPhqkQKsOvJMPMYn();

    public DFvffCPQYTOChsOAqdnPqSu() {
        this.YGjBevanihqaxYKnUNtrNeA();
    }

    private void YGjBevanihqaxYKnUNtrNeA() {
        int n;
        YGjBevanihqaxYKnUNtrNeA yGjBevanihqaxYKnUNtrNeA = this.NwteqrdXWwWpaoJmiBDNxxz.QPeIwmpzLZIktKLXAJOQHcO();
        FoVkhFqKjpvomrYQnnVFKwY = yGjBevanihqaxYKnUNtrNeA.rHAjVyBgPhqkQKsOvJMPMYn();
        kMqExmRlFLPTFqBDauCBKYL = yGjBevanihqaxYKnUNtrNeA.QPeIwmpzLZIktKLXAJOQHcO().rHAjVyBgPhqkQKsOvJMPMYn();
        this.cmBIzvlUaDPTiIjykjjmigy = new UOePwZnqrhIubqtrnzwsUoR(FoVkhFqKjpvomrYQnnVFKwY);
        OrmpCzNZzYDlbDZDBXyofLf = -60.0;
        vJgxuXjYdOvTUFZsFThavLL = -60.0;
        kVXnygMrAwyMajIgLatcyWS = -60.0;
        ibbBhgWhrhhiOLwDlcriPhb = 0.0;
        this.ajlSZBxlJSwYUTeUsFfhumH = 0.0;
        this.TTvVyJBikEjkvfEQPPobmUz = 1.0;
        DamZYXCIxKyKrnRzlNpeRfa = 0;
        for (n = 0; n < 800; ++n) {
            DFvffCPQYTOChsOAqdnPqSu.NuCoRkdmXmpraThwzNAiTcw[n] = 0;
            DFvffCPQYTOChsOAqdnPqSu.wunjGuaHWPKejzkQKUJfPKe[n] = 0;
        }
        for (n = 0; n < 8; ++n) {
            DFvffCPQYTOChsOAqdnPqSu.dnqxuOOQwmxxivZzrQBWydh[n] = 0.0;
            DFvffCPQYTOChsOAqdnPqSu.JSuXbPLjXcQLpTiButqPpoI[n] = 0.0;
        }
        for (n = 0; n < 60; ++n) {
            DFvffCPQYTOChsOAqdnPqSu.iwitQCGCnkthNoQBBlYaPUM[n] = 0.0;
        }
        YGjBevanihqaxYKnUNtrNeA = 0;
        VmkNmvoUyyfcyaaKFyveguY = 0;
        VZagBOcdslnIaKEkojULJvx = 0;
        CWUsTkhDhNSqiWmIUfrczRE = 0;
        XphHMDaiRLyTnLXiOVlLPqZ = 0;
        KLSmtNpcsSwOKRbEbUKdpqL = 0;
    }

    public void JSuXbPLjXcQLpTiButqPpoI() {
    }

    public static void rHAjVyBgPhqkQKsOvJMPMYn(double d, double d2) {
        double d3;
        double d4;
        int n;
        int n2;
        int n3;
        if (d >= -70.0 && d <= 5.0 && XphHMDaiRLyTnLXiOVlLPqZ > 7) {
            int n4 = n3 = (int)Math.round(10.0 * (d + 70.0));
            NuCoRkdmXmpraThwzNAiTcw[n4] = NuCoRkdmXmpraThwzNAiTcw[n4] + 1;
            n2 = 0;
            double d5 = 0;
            uAGKHXCiDSbltWOPIpXUgwC = 1;
            for (n = 0; n < 751; ++n) {
                d4 = (double)n / 10.0 - 70.0;
                d3 = Math.pow(10.0, d4 / 10.0);
                n2 += NuCoRkdmXmpraThwzNAiTcw[n];
                d5 += (double)NuCoRkdmXmpraThwzNAiTcw[n] * d3;
                if (uAGKHXCiDSbltWOPIpXUgwC >= NuCoRkdmXmpraThwzNAiTcw[n]) continue;
                uAGKHXCiDSbltWOPIpXUgwC = NuCoRkdmXmpraThwzNAiTcw[n];
            }
            d5 /= (double)n2;
            double d6 = (d5 = 10.0 * Math.log10(d5)) - 10.0;
            if (d6 < -70.0) {
                d6 = -70.0;
            }
            n3 = (int)Math.round(10.0 * (d6 + 70.0));
            OrmpCzNZzYDlbDZDBXyofLf = 0.0;
            n2 = 0;
            for (n = n3; n < 751; ++n) {
                d4 = (double)n / 10.0 - 70.0;
                d3 = Math.pow(10.0, d4 / 10.0);
                n2 += NuCoRkdmXmpraThwzNAiTcw[n];
                OrmpCzNZzYDlbDZDBXyofLf += (double)NuCoRkdmXmpraThwzNAiTcw[n] * d3;
            }
            OrmpCzNZzYDlbDZDBXyofLf /= (double)n2;
            OrmpCzNZzYDlbDZDBXyofLf = 10.0 * Math.log10(OrmpCzNZzYDlbDZDBXyofLf);
        } else {
            ++XphHMDaiRLyTnLXiOVlLPqZ;
        }
        if (d2 >= -70.0 && d2 <= 5.0 && CWUsTkhDhNSqiWmIUfrczRE > 59) {
            KLSmtNpcsSwOKRbEbUKdpqL = 1;
            int n5 = n3 = (int)Math.round(10.0 * (d2 + 70.0));
            wunjGuaHWPKejzkQKUJfPKe[n5] = wunjGuaHWPKejzkQKUJfPKe[n5] + 1;
            n2 = 0;
            double d7 = 0;
            TNdBwPzcCrGifNBGlgVkPGL = 1;
            for (n = 0; n < 751; ++n) {
                d4 = (double)n / 10.0 - 70.0;
                d3 = Math.pow(10.0, d4 / 10.0);
                n2 += wunjGuaHWPKejzkQKUJfPKe[n];
                d7 += (double)wunjGuaHWPKejzkQKUJfPKe[n] * d3;
                if (TNdBwPzcCrGifNBGlgVkPGL >= wunjGuaHWPKejzkQKUJfPKe[n]) continue;
                TNdBwPzcCrGifNBGlgVkPGL = wunjGuaHWPKejzkQKUJfPKe[n];
            }
            d7 /= (double)n2;
            double d8 = (d7 = 10.0 * Math.log10(d7)) - 20.0;
            if (d8 < -70.0) {
                d8 = -70.0;
            }
            n3 = (int)Math.round(10.0 * (d8 + 70.0));
            n2 = 0;
            for (n = n3; n < 751; ++n) {
                n2 += wunjGuaHWPKejzkQKUJfPKe[n];
            }
            int n6 = 0;
            gLHqHFGBEIDXbcqrsZzduVF = -1;
            xurJiSGFDQVeEtISoLSazWS = -1;
            for (n = n3; n < 751; ++n) {
                if ((double)(n6 += wunjGuaHWPKejzkQKUJfPKe[n]) / (double)n2 > 0.1 && gLHqHFGBEIDXbcqrsZzduVF == -1) {
                    gLHqHFGBEIDXbcqrsZzduVF = n;
                }
                if (!((double)n6 / (double)n2 > 0.95) || xurJiSGFDQVeEtISoLSazWS != -1) continue;
                xurJiSGFDQVeEtISoLSazWS = n;
            }
            double d9 = (double)gLHqHFGBEIDXbcqrsZzduVF / 10.0 - 70.0;
            double d10 = (double)xurJiSGFDQVeEtISoLSazWS / 10.0 - 70.0;
            ibbBhgWhrhhiOLwDlcriPhb = d10 - d9;
        } else {
            ++CWUsTkhDhNSqiWmIUfrczRE;
        }
    }

    public NusIkxnhKbIEOcBmUnwuuOS VZagBOcdslnIaKEkojULJvx() throws Exception {
        int n;
        Thread.currentThread().setName(this.getClass().getSimpleName());
        ZvOTVUaKFTNpNSbbMYZfoXf zvOTVUaKFTNpNSbbMYZfoXf = this.NwteqrdXWwWpaoJmiBDNxxz.JSuXbPLjXcQLpTiButqPpoI();
        int n2 = zvOTVUaKFTNpNSbbMYZfoXf.JSuXbPLjXcQLpTiButqPpoI().length;
        this.cmBIzvlUaDPTiIjykjjmigy.rHAjVyBgPhqkQKsOvJMPMYn(1, zvOTVUaKFTNpNSbbMYZfoXf.JSuXbPLjXcQLpTiButqPpoI(), rHAjVyBgPhqkQKsOvJMPMYn, n2);
        this.cmBIzvlUaDPTiIjykjjmigy.rHAjVyBgPhqkQKsOvJMPMYn(2, zvOTVUaKFTNpNSbbMYZfoXf.QPeIwmpzLZIktKLXAJOQHcO(), QPeIwmpzLZIktKLXAJOQHcO, n2);
        this.cmBIzvlUaDPTiIjykjjmigy.rHAjVyBgPhqkQKsOvJMPMYn(3, rHAjVyBgPhqkQKsOvJMPMYn, rHAjVyBgPhqkQKsOvJMPMYn, n2);
        this.cmBIzvlUaDPTiIjykjjmigy.rHAjVyBgPhqkQKsOvJMPMYn(4, QPeIwmpzLZIktKLXAJOQHcO, QPeIwmpzLZIktKLXAJOQHcO, n2);
        double d = 0.0;
        double d2 = 0.0;
        double d3 = 0.0;
        double d4 = 0.0;
        for (n = 0; n < n2; ++n) {
            double d5 = rHAjVyBgPhqkQKsOvJMPMYn[n];
            double d6 = QPeIwmpzLZIktKLXAJOQHcO[n];
            d4 += d5 * d5;
            d3 += d6 * d6;
            double d7 = Math.abs(d5);
            double d8 = Math.abs(d6);
            if (d2 < d7) {
                d2 = d7;
            }
            if (!(d < d8)) continue;
            d = d8;
        }
        double d9 = (d4 + d3) / (double)n2;
        if (d2 < d) {
            d2 = d;
        }
        DFvffCPQYTOChsOAqdnPqSu.dnqxuOOQwmxxivZzrQBWydh[DFvffCPQYTOChsOAqdnPqSu.VZagBOcdslnIaKEkojULJvx] = d2;
        if (++VZagBOcdslnIaKEkojULJvx > 7) {
            VZagBOcdslnIaKEkojULJvx = 0;
        }
        double d10 = 0.0;
        for (n = 0; n < 8; ++n) {
            d10 += dnqxuOOQwmxxivZzrQBWydh[n];
        }
        if ((d10 = (d10 /= 8.0) > 0.0 ? 20.0 * Math.log10(d10) - 0.691 : -60.0) < -60.0) {
            d10 = -60.0;
        }
        DFvffCPQYTOChsOAqdnPqSu.JSuXbPLjXcQLpTiButqPpoI[DFvffCPQYTOChsOAqdnPqSu.VmkNmvoUyyfcyaaKFyveguY] = d9;
        if (++VmkNmvoUyyfcyaaKFyveguY > 7) {
            VmkNmvoUyyfcyaaKFyveguY = 0;
        }
        double d11 = 0.0;
        for (n = 0; n < 8; ++n) {
            d11 += JSuXbPLjXcQLpTiButqPpoI[n];
        }
        double d12 = (d11 /= 8.0) > 0.0 ? 10.0 * Math.log10(d11) - 0.691 : -90.0;
        DFvffCPQYTOChsOAqdnPqSu.iwitQCGCnkthNoQBBlYaPUM[DFvffCPQYTOChsOAqdnPqSu.YGjBevanihqaxYKnUNtrNeA] = d9;
        if (++YGjBevanihqaxYKnUNtrNeA > 59) {
            YGjBevanihqaxYKnUNtrNeA = 0;
        }
        d11 = 0.0;
        for (n = 0; n < 60; ++n) {
            d11 += iwitQCGCnkthNoQBBlYaPUM[n];
        }
        double d13 = (d11 /= 60.0) > 0.0 ? 10.0 * Math.log10(d11) - 0.691 : -90.0;
        DFvffCPQYTOChsOAqdnPqSu.rHAjVyBgPhqkQKsOvJMPMYn(d12, d13);
        if (d12 < -60.0) {
            d12 = -60.0;
        }
        if (d13 < -60.0) {
            d13 = -60.0;
        }
        this.SYnuCfTgzCxensnEBdDedFe = d10 - d12;
        if (this.SYnuCfTgzCxensnEBdDedFe < 0.0) {
            this.SYnuCfTgzCxensnEBdDedFe = 0.0;
        }
        if (DamZYXCIxKyKrnRzlNpeRfa < 8) {
            ++DamZYXCIxKyKrnRzlNpeRfa;
            this.SYnuCfTgzCxensnEBdDedFe = 0.0;
        } else {
            this.ajlSZBxlJSwYUTeUsFfhumH += Math.pow(10.0, this.SYnuCfTgzCxensnEBdDedFe / 20.0);
            this.TTvVyJBikEjkvfEQPPobmUz += 1.0;
            this.IiqlRFfWYxYaAobCQvdRFEl = this.ajlSZBxlJSwYUTeUsFfhumH > 0.0 ? 20.0 * Math.log10(this.ajlSZBxlJSwYUTeUsFfhumH / this.TTvVyJBikEjkvfEQPPobmUz) : 0.0;
        }
        if (kVXnygMrAwyMajIgLatcyWS < d12) {
            kVXnygMrAwyMajIgLatcyWS = d12;
        }
        if (vJgxuXjYdOvTUFZsFThavLL < d13) {
            vJgxuXjYdOvTUFZsFThavLL = d13;
        }
        if (OrmpCzNZzYDlbDZDBXyofLf < -60.0) {
            OrmpCzNZzYDlbDZDBXyofLf = -60.0;
        }
        this.ggsqrqYbiokXEjuGiCwGpvf = new NusIkxnhKbIEOcBmUnwuuOS(d12, d13, kVXnygMrAwyMajIgLatcyWS, vJgxuXjYdOvTUFZsFThavLL, OrmpCzNZzYDlbDZDBXyofLf, ibbBhgWhrhhiOLwDlcriPhb, NuCoRkdmXmpraThwzNAiTcw, uAGKHXCiDSbltWOPIpXUgwC, wunjGuaHWPKejzkQKUJfPKe, TNdBwPzcCrGifNBGlgVkPGL, gLHqHFGBEIDXbcqrsZzduVF, xurJiSGFDQVeEtISoLSazWS, KLSmtNpcsSwOKRbEbUKdpqL, this.SYnuCfTgzCxensnEBdDedFe, this.IiqlRFfWYxYaAobCQvdRFEl);
        return this.ggsqrqYbiokXEjuGiCwGpvf;
    }

    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(String string) {
        this.YGjBevanihqaxYKnUNtrNeA();
    }

    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(ZjoyaRSokkGYDwXHPKTBIiX zjoyaRSokkGYDwXHPKTBIiX) {
        if (zjoyaRSokkGYDwXHPKTBIiX == ZjoyaRSokkGYDwXHPKTBIiX.iwitQCGCnkthNoQBBlYaPUM) {
            this.JSuXbPLjXcQLpTiButqPpoI();
        }
    }

    @Override
    public boolean rHAjVyBgPhqkQKsOvJMPMYn(lXCOGwZXVelwEKHMMPwpSAO lXCOGwZXVelwEKHMMPwpSAO2, Object object) {
        switch (lXCOGwZXVelwEKHMMPwpSAO2) {
            case dnqxuOOQwmxxivZzrQBWydh: {
                this.YGjBevanihqaxYKnUNtrNeA();
            }
        }
        return true;
    }

    @Override
    public void iwitQCGCnkthNoQBBlYaPUM() {
        this.YGjBevanihqaxYKnUNtrNeA();
    }

    public NusIkxnhKbIEOcBmUnwuuOS VmkNmvoUyyfcyaaKFyveguY() {
        return this.ggsqrqYbiokXEjuGiCwGpvf;
    }

    @Override
    public /* synthetic */ Object QPeIwmpzLZIktKLXAJOQHcO() throws Exception {
        return this.VZagBOcdslnIaKEkojULJvx();
    }

    @Override
    public /* synthetic */ Object dnqxuOOQwmxxivZzrQBWydh() {
        return this.VmkNmvoUyyfcyaaKFyveguY();
    }

    static {
        KLSmtNpcsSwOKRbEbUKdpqL = 0;
        DamZYXCIxKyKrnRzlNpeRfa = 0;
    }
}

