/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.baNVeXFImuRLiTMRkLcfSaa;

public class EXlCnePJhpzaNHMHTvZqRrN {
    private int[] rHAjVyBgPhqkQKsOvJMPMYn;
    private int[] QPeIwmpzLZIktKLXAJOQHcO;
    private baNVeXFImuRLiTMRkLcfSaa JSuXbPLjXcQLpTiButqPpoI;

    public EXlCnePJhpzaNHMHTvZqRrN(int n) {
        this.rHAjVyBgPhqkQKsOvJMPMYn = new int[n];
        this.QPeIwmpzLZIktKLXAJOQHcO = new int[n];
        this.JSuXbPLjXcQLpTiButqPpoI = new baNVeXFImuRLiTMRkLcfSaa();
    }

    public int[] rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }

    public baNVeXFImuRLiTMRkLcfSaa QPeIwmpzLZIktKLXAJOQHcO() {
        return this.JSuXbPLjXcQLpTiButqPpoI;
    }

    public int[] JSuXbPLjXcQLpTiButqPpoI() {
        return this.QPeIwmpzLZIktKLXAJOQHcO;
    }
}

