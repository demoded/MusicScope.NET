/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.DsdbIJsDbOeENdTpaIDYbiZ;

public abstract class dBprZQxZjIUbnidwEbEFsgB
implements Runnable {
    protected final Object rHAjVyBgPhqkQKsOvJMPMYn = new Object();
    protected DsdbIJsDbOeENdTpaIDYbiZ QPeIwmpzLZIktKLXAJOQHcO = DsdbIJsDbOeENdTpaIDYbiZ.rHAjVyBgPhqkQKsOvJMPMYn;
    protected String JSuXbPLjXcQLpTiButqPpoI;
    private int iwitQCGCnkthNoQBBlYaPUM = 5;

    public DsdbIJsDbOeENdTpaIDYbiZ rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.QPeIwmpzLZIktKLXAJOQHcO;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(String string) {
        this.JSuXbPLjXcQLpTiButqPpoI = string;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(int n) {
        this.iwitQCGCnkthNoQBBlYaPUM = n;
    }

    public abstract void QPeIwmpzLZIktKLXAJOQHcO();

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void run() {
        Thread.currentThread().setName(this.JSuXbPLjXcQLpTiButqPpoI);
        Thread.currentThread().setPriority(this.iwitQCGCnkthNoQBBlYaPUM);
        this.QPeIwmpzLZIktKLXAJOQHcO = DsdbIJsDbOeENdTpaIDYbiZ.JSuXbPLjXcQLpTiButqPpoI;
        while (this.QPeIwmpzLZIktKLXAJOQHcO == DsdbIJsDbOeENdTpaIDYbiZ.JSuXbPLjXcQLpTiButqPpoI && !Thread.currentThread().isInterrupted()) {
            this.QPeIwmpzLZIktKLXAJOQHcO();
        }
        this.QPeIwmpzLZIktKLXAJOQHcO = DsdbIJsDbOeENdTpaIDYbiZ.rHAjVyBgPhqkQKsOvJMPMYn;
        Object object = this.rHAjVyBgPhqkQKsOvJMPMYn;
        synchronized (object) {
            this.rHAjVyBgPhqkQKsOvJMPMYn.notify();
        }
    }
}

