/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(value=RetentionPolicy.RUNTIME)
public @interface fegnCROFfntWhihpSdONLyP {
    public String rHAjVyBgPhqkQKsOvJMPMYn();

    public String QPeIwmpzLZIktKLXAJOQHcO() default "";

    public String[] JSuXbPLjXcQLpTiButqPpoI() default {""};

    public boolean iwitQCGCnkthNoQBBlYaPUM() default true;

    public boolean dnqxuOOQwmxxivZzrQBWydh() default false;
}

