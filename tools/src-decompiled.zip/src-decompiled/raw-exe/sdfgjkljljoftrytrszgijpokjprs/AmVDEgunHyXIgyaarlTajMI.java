/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.GFDfJcQwFRWsKLEqUzyzjuA;
import sdfgjkljljoftrytrszgijpokjprs.YRJGfWcyJJQdwqOWeghJzoA;
import sdfgjkljljoftrytrszgijpokjprs.ZBNFgJwMMkkaOLFmIBSJWbh;
import sdfgjkljljoftrytrszgijpokjprs.kNJpubvMpXzMSIqgitDifgT;
import sdfgjkljljoftrytrszgijpokjprs.tyOkjsTUxOpfPxqEnMYqtXo;

@YRJGfWcyJJQdwqOWeghJzoA
@tyOkjsTUxOpfPxqEnMYqtXo(rHAjVyBgPhqkQKsOvJMPMYn="CMPR")
public class AmVDEgunHyXIgyaarlTajMI
extends kNJpubvMpXzMSIqgitDifgT {
    private rHAjVyBgPhqkQKsOvJMPMYn rHAjVyBgPhqkQKsOvJMPMYn;
    private short QPeIwmpzLZIktKLXAJOQHcO;
    private String JSuXbPLjXcQLpTiButqPpoI;

    public rHAjVyBgPhqkQKsOvJMPMYn rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }

    @Override
    public long JSuXbPLjXcQLpTiButqPpoI() {
        return 5L + super.JSuXbPLjXcQLpTiButqPpoI();
    }

    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(ZBNFgJwMMkkaOLFmIBSJWbh zBNFgJwMMkkaOLFmIBSJWbh) throws GFDfJcQwFRWsKLEqUzyzjuA {
        this.rHAjVyBgPhqkQKsOvJMPMYn = null;
        this.QPeIwmpzLZIktKLXAJOQHcO = (short)-1;
        this.JSuXbPLjXcQLpTiButqPpoI = "";
        super.rHAjVyBgPhqkQKsOvJMPMYn(zBNFgJwMMkkaOLFmIBSJWbh);
        this.rHAjVyBgPhqkQKsOvJMPMYn = sdfgjkljljoftrytrszgijpokjprs.AmVDEgunHyXIgyaarlTajMI$rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn(zBNFgJwMMkkaOLFmIBSJWbh.QPeIwmpzLZIktKLXAJOQHcO(4).array());
        this.QPeIwmpzLZIktKLXAJOQHcO = zBNFgJwMMkkaOLFmIBSJWbh.QPeIwmpzLZIktKLXAJOQHcO(1).get();
        byte[] byArray = zBNFgJwMMkkaOLFmIBSJWbh.QPeIwmpzLZIktKLXAJOQHcO(this.QPeIwmpzLZIktKLXAJOQHcO).array();
        for (int i = 0; i < this.QPeIwmpzLZIktKLXAJOQHcO; ++i) {
            this.JSuXbPLjXcQLpTiButqPpoI = this.JSuXbPLjXcQLpTiButqPpoI + (char)byArray[i];
        }
    }

    @Override
    public boolean VZagBOcdslnIaKEkojULJvx() {
        boolean bl = super.VZagBOcdslnIaKEkojULJvx();
        bl &= this.rHAjVyBgPhqkQKsOvJMPMYn != null && this.rHAjVyBgPhqkQKsOvJMPMYn != sdfgjkljljoftrytrszgijpokjprs.AmVDEgunHyXIgyaarlTajMI$rHAjVyBgPhqkQKsOvJMPMYn.JSuXbPLjXcQLpTiButqPpoI;
        bl &= this.QPeIwmpzLZIktKLXAJOQHcO >= 0;
        return bl &= !this.JSuXbPLjXcQLpTiButqPpoI.isEmpty() && this.JSuXbPLjXcQLpTiButqPpoI.length() == this.QPeIwmpzLZIktKLXAJOQHcO;
    }

    public static enum rHAjVyBgPhqkQKsOvJMPMYn {
        rHAjVyBgPhqkQKsOvJMPMYn("DSD ", "not compressed", "Uncompressed, plain DSD audio data"),
        QPeIwmpzLZIktKLXAJOQHcO("DST ", "DST Encoded", "DST Encoded audio data"),
        JSuXbPLjXcQLpTiButqPpoI("Unknown", "Unknown", "Unknown");

        private final String iwitQCGCnkthNoQBBlYaPUM;
        private final String dnqxuOOQwmxxivZzrQBWydh;
        private final String VZagBOcdslnIaKEkojULJvx;

        private rHAjVyBgPhqkQKsOvJMPMYn(String string2, String string3, String string4) {
            this.iwitQCGCnkthNoQBBlYaPUM = string2;
            this.dnqxuOOQwmxxivZzrQBWydh = string3;
            this.VZagBOcdslnIaKEkojULJvx = string4;
        }

        public String rHAjVyBgPhqkQKsOvJMPMYn() {
            return this.iwitQCGCnkthNoQBBlYaPUM;
        }

        public static rHAjVyBgPhqkQKsOvJMPMYn rHAjVyBgPhqkQKsOvJMPMYn(byte[] byArray) {
            String string = "";
            for (byte by : byArray) {
                string = string + (char)by;
            }
            for (rHAjVyBgPhqkQKsOvJMPMYn rHAjVyBgPhqkQKsOvJMPMYn2 : sdfgjkljljoftrytrszgijpokjprs.AmVDEgunHyXIgyaarlTajMI$rHAjVyBgPhqkQKsOvJMPMYn.values()) {
                if (!rHAjVyBgPhqkQKsOvJMPMYn2.rHAjVyBgPhqkQKsOvJMPMYn().equals(string)) continue;
                return rHAjVyBgPhqkQKsOvJMPMYn2;
            }
            return JSuXbPLjXcQLpTiButqPpoI;
        }
    }
}

