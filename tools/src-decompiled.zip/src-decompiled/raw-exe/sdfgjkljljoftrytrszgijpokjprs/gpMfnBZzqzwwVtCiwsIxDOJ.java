/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.util.Arrays;
import sdfgjkljljoftrytrszgijpokjprs.hbrLeGaBQpowiGXcxllRUam;

public class gpMfnBZzqzwwVtCiwsIxDOJ {
    private static final int rHAjVyBgPhqkQKsOvJMPMYn = (int)Math.pow(2.0, 9.0);
    private int QPeIwmpzLZIktKLXAJOQHcO = 24;
    private int JSuXbPLjXcQLpTiButqPpoI = 44100;
    private double iwitQCGCnkthNoQBBlYaPUM = Math.pow(2.0, this.QPeIwmpzLZIktKLXAJOQHcO - 1);
    private hbrLeGaBQpowiGXcxllRUam dnqxuOOQwmxxivZzrQBWydh;
    private double VZagBOcdslnIaKEkojULJvx;
    private final double[][] VmkNmvoUyyfcyaaKFyveguY = new double[20000][rHAjVyBgPhqkQKsOvJMPMYn / 2];
    private final double[] YGjBevanihqaxYKnUNtrNeA = new double[rHAjVyBgPhqkQKsOvJMPMYn];
    private final int[] wunjGuaHWPKejzkQKUJfPKe = new int[rHAjVyBgPhqkQKsOvJMPMYn / 2];
    private final int[] NuCoRkdmXmpraThwzNAiTcw = new int[rHAjVyBgPhqkQKsOvJMPMYn / 2];
    private final int[] OrmpCzNZzYDlbDZDBXyofLf = new int[rHAjVyBgPhqkQKsOvJMPMYn / 2];
    private final int[] ibbBhgWhrhhiOLwDlcriPhb = new int[rHAjVyBgPhqkQKsOvJMPMYn / 2];
    private final int[] kVXnygMrAwyMajIgLatcyWS = new int[rHAjVyBgPhqkQKsOvJMPMYn / 2];
    private final double[] vJgxuXjYdOvTUFZsFThavLL = new double[rHAjVyBgPhqkQKsOvJMPMYn / 2];
    private final double[] FoVkhFqKjpvomrYQnnVFKwY = new double[rHAjVyBgPhqkQKsOvJMPMYn / 2];
    private final double[] kMqExmRlFLPTFqBDauCBKYL = new double[rHAjVyBgPhqkQKsOvJMPMYn / 2];
    private final double[] uAGKHXCiDSbltWOPIpXUgwC = new double[rHAjVyBgPhqkQKsOvJMPMYn / 2];
    private int TNdBwPzcCrGifNBGlgVkPGL;
    private int CWUsTkhDhNSqiWmIUfrczRE;
    private int XphHMDaiRLyTnLXiOVlLPqZ;
    private int cmBIzvlUaDPTiIjykjjmigy;
    private int NwteqrdXWwWpaoJmiBDNxxz;

    public void rHAjVyBgPhqkQKsOvJMPMYn(int n, int n2) {
        this.JSuXbPLjXcQLpTiButqPpoI = n;
        this.QPeIwmpzLZIktKLXAJOQHcO = n2;
        this.iwitQCGCnkthNoQBBlYaPUM = Math.pow(2.0, n2 - 1);
        this.VZagBOcdslnIaKEkojULJvx = (double)n / (double)rHAjVyBgPhqkQKsOvJMPMYn;
        this.TNdBwPzcCrGifNBGlgVkPGL = 0;
        this.NwteqrdXWwWpaoJmiBDNxxz = 10 * n / rHAjVyBgPhqkQKsOvJMPMYn;
        this.CWUsTkhDhNSqiWmIUfrczRE = n / 2;
        this.dnqxuOOQwmxxivZzrQBWydh = new hbrLeGaBQpowiGXcxllRUam(rHAjVyBgPhqkQKsOvJMPMYn);
        this.cmBIzvlUaDPTiIjykjjmigy = 0;
        this.XphHMDaiRLyTnLXiOVlLPqZ = 0;
        for (int i = 0; i < rHAjVyBgPhqkQKsOvJMPMYn / 2; ++i) {
            this.kMqExmRlFLPTFqBDauCBKYL[i] = 1.0;
        }
        this.QPeIwmpzLZIktKLXAJOQHcO();
    }

    public int rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.TNdBwPzcCrGifNBGlgVkPGL;
    }

    public void QPeIwmpzLZIktKLXAJOQHcO() {
        for (int i = 0; i < 256; ++i) {
            this.vJgxuXjYdOvTUFZsFThavLL[i] = 0.0;
            this.FoVkhFqKjpvomrYQnnVFKwY[i] = 0.0;
            this.wunjGuaHWPKejzkQKUJfPKe[i] = 0;
            this.OrmpCzNZzYDlbDZDBXyofLf[i] = 0;
            this.kVXnygMrAwyMajIgLatcyWS[i] = 0;
            this.ibbBhgWhrhhiOLwDlcriPhb[i] = 0;
            this.NuCoRkdmXmpraThwzNAiTcw[i] = 0;
            for (int j = 0; j < 20000; ++j) {
                this.kMqExmRlFLPTFqBDauCBKYL[i] = 1.0;
                this.uAGKHXCiDSbltWOPIpXUgwC[i] = 0.0;
            }
        }
        this.XphHMDaiRLyTnLXiOVlLPqZ = 0;
    }

    private void JSuXbPLjXcQLpTiButqPpoI() {
        int n;
        int n2;
        int[][] nArray = new int[8][256];
        int[] nArray2 = new int[256];
        for (n2 = 0; n2 < 256; ++n2) {
            for (n = 0; n < 20000; ++n) {
                this.vJgxuXjYdOvTUFZsFThavLL[n2] = this.vJgxuXjYdOvTUFZsFThavLL[n2] + this.VmkNmvoUyyfcyaaKFyveguY[n][n2];
                if (this.kMqExmRlFLPTFqBDauCBKYL[n2] > this.VmkNmvoUyyfcyaaKFyveguY[n][n2]) {
                    this.kMqExmRlFLPTFqBDauCBKYL[n2] = this.VmkNmvoUyyfcyaaKFyveguY[n][n2];
                }
                if (!(this.uAGKHXCiDSbltWOPIpXUgwC[n2] < this.VmkNmvoUyyfcyaaKFyveguY[n][n2])) continue;
                this.uAGKHXCiDSbltWOPIpXUgwC[n2] = this.VmkNmvoUyyfcyaaKFyveguY[n][n2];
            }
            this.vJgxuXjYdOvTUFZsFThavLL[n2] = this.vJgxuXjYdOvTUFZsFThavLL[n2] / 20000.0;
        }
        for (n2 = 0; n2 < 256; ++n2) {
            for (n = 0; n < 20000; ++n) {
                this.VmkNmvoUyyfcyaaKFyveguY[n][n2] = this.VmkNmvoUyyfcyaaKFyveguY[n][n2] >= this.vJgxuXjYdOvTUFZsFThavLL[n2] ? 1.0 : 0.0;
            }
        }
        for (n2 = 0; n2 < 256; ++n2) {
            for (n = 0; n < 20000; ++n) {
                if (this.VmkNmvoUyyfcyaaKFyveguY[n][n2] != 1.0) continue;
                int n3 = n2;
                this.wunjGuaHWPKejzkQKUJfPKe[n3] = this.wunjGuaHWPKejzkQKUJfPKe[n3] + 1;
            }
        }
        for (n2 = 0; n2 < 256; ++n2) {
            for (n = 0; n < 20000; ++n) {
                if (this.VmkNmvoUyyfcyaaKFyveguY[n][n2] == (double)this.kVXnygMrAwyMajIgLatcyWS[n2]) {
                    int n4 = n2;
                    nArray2[n4] = nArray2[n4] + 1;
                    continue;
                }
                if (nArray2[n2] < 6) {
                    int[] nArray3 = nArray[nArray2[n2]];
                    int n5 = n2;
                    nArray3[n5] = nArray3[n5] + 1;
                } else {
                    int[] nArray4 = nArray[6];
                    int n6 = n2;
                    nArray4[n6] = nArray4[n6] + 1;
                }
                this.kVXnygMrAwyMajIgLatcyWS[n2] = (int)this.VmkNmvoUyyfcyaaKFyveguY[n][n2];
                nArray2[n2] = 0;
            }
        }
        for (n2 = 0; n2 < 256; ++n2) {
            if (this.wunjGuaHWPKejzkQKUJfPKe[n2] <= 9050 || this.wunjGuaHWPKejzkQKUJfPKe[n2] >= 10346) continue;
            int n7 = n2;
            this.NuCoRkdmXmpraThwzNAiTcw[n7] = this.NuCoRkdmXmpraThwzNAiTcw[n7] + 1;
            this.OrmpCzNZzYDlbDZDBXyofLf[n2] = 1;
        }
        for (n2 = 0; n2 < 256; ++n2) {
            if (nArray[1][n2] < 2267 || nArray[1][n2] > 2733 || nArray[2][n2] < 1079 || nArray[2][n2] > 1421 || nArray[3][n2] < 502 || nArray[3][n2] > 748 || nArray[4][n2] < 223 || nArray[4][n2] > 402 || nArray[5][n2] < 90 || nArray[5][n2] > 223 || nArray[6][n2] < 90 || nArray[6][n2] > 223) continue;
            int n8 = n2;
            this.NuCoRkdmXmpraThwzNAiTcw[n8] = this.NuCoRkdmXmpraThwzNAiTcw[n8] + 1;
            this.ibbBhgWhrhhiOLwDlcriPhb[n2] = 1;
        }
        for (n2 = 0; n2 < 256; ++n2) {
            if (this.NuCoRkdmXmpraThwzNAiTcw[n2] != 2) continue;
            this.CWUsTkhDhNSqiWmIUfrczRE = (int)((double)n2 * this.VZagBOcdslnIaKEkojULJvx);
            if (this.CWUsTkhDhNSqiWmIUfrczRE <= this.TNdBwPzcCrGifNBGlgVkPGL) break;
            this.TNdBwPzcCrGifNBGlgVkPGL = this.CWUsTkhDhNSqiWmIUfrczRE;
            break;
        }
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(double[] dArray) {
        if (this.XphHMDaiRLyTnLXiOVlLPqZ < 20000 && this.cmBIzvlUaDPTiIjykjjmigy > this.NwteqrdXWwWpaoJmiBDNxxz) {
            Arrays.fill(this.YGjBevanihqaxYKnUNtrNeA, 0, rHAjVyBgPhqkQKsOvJMPMYn, 0.0);
            this.dnqxuOOQwmxxivZzrQBWydh.rHAjVyBgPhqkQKsOvJMPMYn(1, true, dArray, this.YGjBevanihqaxYKnUNtrNeA);
            for (int i = 0; i < 256; ++i) {
                this.VmkNmvoUyyfcyaaKFyveguY[this.XphHMDaiRLyTnLXiOVlLPqZ][i] = Math.sqrt(dArray[i] * dArray[i] + this.YGjBevanihqaxYKnUNtrNeA[i] * this.YGjBevanihqaxYKnUNtrNeA[i]);
            }
            ++this.XphHMDaiRLyTnLXiOVlLPqZ;
        } else if (this.XphHMDaiRLyTnLXiOVlLPqZ >= 20000) {
            this.JSuXbPLjXcQLpTiButqPpoI();
            this.QPeIwmpzLZIktKLXAJOQHcO();
        }
        ++this.cmBIzvlUaDPTiIjykjjmigy;
    }
}

