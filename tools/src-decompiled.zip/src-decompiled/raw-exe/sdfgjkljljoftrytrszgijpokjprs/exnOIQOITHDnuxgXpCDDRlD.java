/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import sdfgjkljljoftrytrszgijpokjprs.DzeHJEjXSeqlfumFByehgcX;
import sdfgjkljljoftrytrszgijpokjprs.YKTWEeEoGctvADZOqBEefOZ;
import sdfgjkljljoftrytrszgijpokjprs.ZDSaXekyHHNqfExESErZUQI;

public class exnOIQOITHDnuxgXpCDDRlD<B extends DzeHJEjXSeqlfumFByehgcX, R extends B> {
    private final Class<R> rHAjVyBgPhqkQKsOvJMPMYn;
    private final HashMap<String, rHAjVyBgPhqkQKsOvJMPMYn<B>> QPeIwmpzLZIktKLXAJOQHcO;
    private final int JSuXbPLjXcQLpTiButqPpoI;

    public exnOIQOITHDnuxgXpCDDRlD(Class<B> clazz, Class<R> clazz2) {
        this.rHAjVyBgPhqkQKsOvJMPMYn = clazz2;
        this.JSuXbPLjXcQLpTiButqPpoI = this.rHAjVyBgPhqkQKsOvJMPMYn(clazz);
        this.QPeIwmpzLZIktKLXAJOQHcO = new HashMap(0);
    }

    public Set<String> rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.QPeIwmpzLZIktKLXAJOQHcO.keySet();
    }

    public long rHAjVyBgPhqkQKsOvJMPMYn(String string) {
        rHAjVyBgPhqkQKsOvJMPMYn<B> rHAjVyBgPhqkQKsOvJMPMYn2 = this.QPeIwmpzLZIktKLXAJOQHcO.get(string);
        return ((DzeHJEjXSeqlfumFByehgcX)rHAjVyBgPhqkQKsOvJMPMYn2.QPeIwmpzLZIktKLXAJOQHcO).QPeIwmpzLZIktKLXAJOQHcO();
    }

    public long QPeIwmpzLZIktKLXAJOQHcO() {
        long l = 0L;
        l += (long)this.JSuXbPLjXcQLpTiButqPpoI;
        l += (long)this.rHAjVyBgPhqkQKsOvJMPMYn(this.rHAjVyBgPhqkQKsOvJMPMYn);
        for (String string : this.rHAjVyBgPhqkQKsOvJMPMYn()) {
            l += this.rHAjVyBgPhqkQKsOvJMPMYn(string) % 2L == 0L ? 0L : 1L;
            l += this.rHAjVyBgPhqkQKsOvJMPMYn(string);
            l += (long)this.JSuXbPLjXcQLpTiButqPpoI;
        }
        return l;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(R r, RandomAccessFile randomAccessFile) throws IOException {
        Field[] fieldArray;
        int n = this.rHAjVyBgPhqkQKsOvJMPMYn(r.getClass());
        ByteBuffer byteBuffer = this.rHAjVyBgPhqkQKsOvJMPMYn(0L, this.JSuXbPLjXcQLpTiButqPpoI, randomAccessFile);
        ByteBuffer byteBuffer2 = this.rHAjVyBgPhqkQKsOvJMPMYn(this.JSuXbPLjXcQLpTiButqPpoI, n, randomAccessFile);
        r.rHAjVyBgPhqkQKsOvJMPMYn(byteBuffer);
        r.QPeIwmpzLZIktKLXAJOQHcO(byteBuffer2);
        this.rHAjVyBgPhqkQKsOvJMPMYn(n + this.JSuXbPLjXcQLpTiButqPpoI, randomAccessFile);
        Class<?> clazz = r.getClass();
        for (Field field : fieldArray = clazz.getDeclaredFields()) {
            try {
                field.setAccessible(true);
                Object object = field.get(r);
                Class<?> clazz2 = object.getClass();
                YKTWEeEoGctvADZOqBEefOZ yKTWEeEoGctvADZOqBEefOZ = clazz2.getAnnotation(YKTWEeEoGctvADZOqBEefOZ.class);
                if (yKTWEeEoGctvADZOqBEefOZ == null) continue;
                String string = yKTWEeEoGctvADZOqBEefOZ.rHAjVyBgPhqkQKsOvJMPMYn();
                boolean bl = yKTWEeEoGctvADZOqBEefOZ.QPeIwmpzLZIktKLXAJOQHcO();
                long l = yKTWEeEoGctvADZOqBEefOZ.JSuXbPLjXcQLpTiButqPpoI();
                rHAjVyBgPhqkQKsOvJMPMYn<B> rHAjVyBgPhqkQKsOvJMPMYn2 = this.QPeIwmpzLZIktKLXAJOQHcO.get(string);
                if (rHAjVyBgPhqkQKsOvJMPMYn2 == null) continue;
                DzeHJEjXSeqlfumFByehgcX dzeHJEjXSeqlfumFByehgcX = (DzeHJEjXSeqlfumFByehgcX)object;
                rHAjVyBgPhqkQKsOvJMPMYn2.rHAjVyBgPhqkQKsOvJMPMYn.position(0);
                dzeHJEjXSeqlfumFByehgcX.rHAjVyBgPhqkQKsOvJMPMYn(rHAjVyBgPhqkQKsOvJMPMYn2.rHAjVyBgPhqkQKsOvJMPMYn);
                dzeHJEjXSeqlfumFByehgcX.rHAjVyBgPhqkQKsOvJMPMYn(((DzeHJEjXSeqlfumFByehgcX)rHAjVyBgPhqkQKsOvJMPMYn2.QPeIwmpzLZIktKLXAJOQHcO).rHAjVyBgPhqkQKsOvJMPMYn());
                if (!bl) continue;
                dzeHJEjXSeqlfumFByehgcX.QPeIwmpzLZIktKLXAJOQHcO(this.rHAjVyBgPhqkQKsOvJMPMYn(((DzeHJEjXSeqlfumFByehgcX)rHAjVyBgPhqkQKsOvJMPMYn2.QPeIwmpzLZIktKLXAJOQHcO).rHAjVyBgPhqkQKsOvJMPMYn(), (int)Math.min(((DzeHJEjXSeqlfumFByehgcX)rHAjVyBgPhqkQKsOvJMPMYn2.QPeIwmpzLZIktKLXAJOQHcO).QPeIwmpzLZIktKLXAJOQHcO(), l), randomAccessFile));
            }
            catch (IllegalAccessException | IllegalArgumentException | SecurityException exception) {
                Logger.getLogger(exnOIQOITHDnuxgXpCDDRlD.class.getName()).log(Level.SEVERE, null, exception);
            }
        }
    }

    private ByteBuffer rHAjVyBgPhqkQKsOvJMPMYn(long l, int n, RandomAccessFile randomAccessFile) throws IOException {
        byte[] byArray = new byte[n];
        randomAccessFile.seek(l);
        int n2 = randomAccessFile.read(byArray);
        if (n2 > 0) {
            return ByteBuffer.wrap(byArray);
        }
        return null;
    }

    private void rHAjVyBgPhqkQKsOvJMPMYn(long l, RandomAccessFile randomAccessFile) throws IOException {
        ByteBuffer byteBuffer;
        long l2 = l;
        while ((byteBuffer = this.rHAjVyBgPhqkQKsOvJMPMYn(l2, this.JSuXbPLjXcQLpTiButqPpoI, randomAccessFile)) != null) {
            try {
                DzeHJEjXSeqlfumFByehgcX dzeHJEjXSeqlfumFByehgcX = (DzeHJEjXSeqlfumFByehgcX)this.rHAjVyBgPhqkQKsOvJMPMYn.newInstance();
                dzeHJEjXSeqlfumFByehgcX.rHAjVyBgPhqkQKsOvJMPMYn(byteBuffer);
                dzeHJEjXSeqlfumFByehgcX.rHAjVyBgPhqkQKsOvJMPMYn(l2 + (long)this.JSuXbPLjXcQLpTiButqPpoI);
                if (dzeHJEjXSeqlfumFByehgcX.QPeIwmpzLZIktKLXAJOQHcO() <= 0L) break;
                if (!this.QPeIwmpzLZIktKLXAJOQHcO.containsKey(new String(dzeHJEjXSeqlfumFByehgcX.JSuXbPLjXcQLpTiButqPpoI()))) {
                    this.QPeIwmpzLZIktKLXAJOQHcO.put(new String(dzeHJEjXSeqlfumFByehgcX.JSuXbPLjXcQLpTiButqPpoI()), new rHAjVyBgPhqkQKsOvJMPMYn<DzeHJEjXSeqlfumFByehgcX>(byteBuffer, dzeHJEjXSeqlfumFByehgcX));
                }
                l2 += (long)this.JSuXbPLjXcQLpTiButqPpoI;
                l2 += dzeHJEjXSeqlfumFByehgcX.QPeIwmpzLZIktKLXAJOQHcO();
                l2 += dzeHJEjXSeqlfumFByehgcX.QPeIwmpzLZIktKLXAJOQHcO() % 2L == 0L ? 0L : 1L;
            }
            catch (IllegalAccessException | InstantiationException reflectiveOperationException) {
                Logger.getLogger(exnOIQOITHDnuxgXpCDDRlD.class.getName()).log(Level.SEVERE, null, reflectiveOperationException);
            }
        }
    }

    public int rHAjVyBgPhqkQKsOvJMPMYn(Class<?> clazz) {
        Field[] fieldArray;
        int n = 0;
        for (Field field : fieldArray = clazz.getDeclaredFields()) {
            ZDSaXekyHHNqfExESErZUQI zDSaXekyHHNqfExESErZUQI = field.getAnnotation(ZDSaXekyHHNqfExESErZUQI.class);
            if (zDSaXekyHHNqfExESErZUQI == null) continue;
            n += zDSaXekyHHNqfExESErZUQI.rHAjVyBgPhqkQKsOvJMPMYn();
        }
        return n;
    }

    private class rHAjVyBgPhqkQKsOvJMPMYn<B> {
        protected final ByteBuffer rHAjVyBgPhqkQKsOvJMPMYn;
        protected final B QPeIwmpzLZIktKLXAJOQHcO;

        rHAjVyBgPhqkQKsOvJMPMYn(ByteBuffer byteBuffer, B b) {
            this.rHAjVyBgPhqkQKsOvJMPMYn = byteBuffer;
            this.QPeIwmpzLZIktKLXAJOQHcO = b;
        }
    }
}

