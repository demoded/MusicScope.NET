/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

public class GFDfJcQwFRWsKLEqUzyzjuA
extends Exception {
    private static final long serialVersionUID = 1L;
    private final long rHAjVyBgPhqkQKsOvJMPMYn;
    private final long QPeIwmpzLZIktKLXAJOQHcO;
    private final long JSuXbPLjXcQLpTiButqPpoI;

    public GFDfJcQwFRWsKLEqUzyzjuA(long l, long l2, long l3) {
        super(String.format("Out of chunk range exception. [offset = %d | size = %d | outOfRange = %d]", l, l2, l3));
        this.rHAjVyBgPhqkQKsOvJMPMYn = l;
        this.QPeIwmpzLZIktKLXAJOQHcO = l2;
        this.JSuXbPLjXcQLpTiButqPpoI = l3;
    }
}

