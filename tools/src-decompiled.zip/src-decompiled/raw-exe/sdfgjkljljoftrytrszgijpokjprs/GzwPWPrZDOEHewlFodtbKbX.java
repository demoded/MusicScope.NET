/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import javax.swing.JComponent;
import javax.swing.SwingUtilities;
import sdfgjkljljoftrytrszgijpokjprs.PumrgUjzIBRhWRYVWFJFxPn;

public class GzwPWPrZDOEHewlFodtbKbX
extends JComponent
implements MouseListener,
MouseMotionListener,
Runnable {
    private int rHAjVyBgPhqkQKsOvJMPMYn = 48000;
    private int QPeIwmpzLZIktKLXAJOQHcO = this.rHAjVyBgPhqkQKsOvJMPMYn / 2;
    private double JSuXbPLjXcQLpTiButqPpoI = -130.0;
    private double iwitQCGCnkthNoQBBlYaPUM = 0.0;
    private double dnqxuOOQwmxxivZzrQBWydh = -65.0;
    private boolean VZagBOcdslnIaKEkojULJvx = true;
    private boolean VmkNmvoUyyfcyaaKFyveguY = true;
    private int YGjBevanihqaxYKnUNtrNeA = 3;
    private int wunjGuaHWPKejzkQKUJfPKe;
    private double NuCoRkdmXmpraThwzNAiTcw;
    private double OrmpCzNZzYDlbDZDBXyofLf;
    private int ibbBhgWhrhhiOLwDlcriPhb;
    private double[] kVXnygMrAwyMajIgLatcyWS;
    private int vJgxuXjYdOvTUFZsFThavLL = 2048;
    private boolean FoVkhFqKjpvomrYQnnVFKwY = false;
    private final int kMqExmRlFLPTFqBDauCBKYL = 520;
    private final int uAGKHXCiDSbltWOPIpXUgwC = 80;
    private final int TNdBwPzcCrGifNBGlgVkPGL = 500;
    private final int CWUsTkhDhNSqiWmIUfrczRE = 1024;
    private double XphHMDaiRLyTnLXiOVlLPqZ = this.rHAjVyBgPhqkQKsOvJMPMYn / 4;
    private double cmBIzvlUaDPTiIjykjjmigy = this.rHAjVyBgPhqkQKsOvJMPMYn / 2;
    private double NwteqrdXWwWpaoJmiBDNxxz = this.XphHMDaiRLyTnLXiOVlLPqZ - this.cmBIzvlUaDPTiIjykjjmigy / 2.0;
    private double SYnuCfTgzCxensnEBdDedFe = this.XphHMDaiRLyTnLXiOVlLPqZ + this.cmBIzvlUaDPTiIjykjjmigy / 2.0;
    private double ajlSZBxlJSwYUTeUsFfhumH = (double)this.rHAjVyBgPhqkQKsOvJMPMYn / 2048.0;
    private int TTvVyJBikEjkvfEQPPobmUz = 24000;
    private int IiqlRFfWYxYaAobCQvdRFEl = 0;
    private int gLHqHFGBEIDXbcqrsZzduVF = 48000;
    private int xurJiSGFDQVeEtISoLSazWS;
    private int KLSmtNpcsSwOKRbEbUKdpqL;
    private int DamZYXCIxKyKrnRzlNpeRfa;
    private int ggsqrqYbiokXEjuGiCwGpvf;
    private int YikeWIksDnZbpLLacoPMfKN;
    private int rTbADuShFCOuMvGFEuNmbFb;
    private boolean tJuPpiiZKFnZdtTTOrwfbxj = false;
    private double[][] GgoKTcuIevtAhezhbHlrofU;
    private double[] sUwuMtUcgVzMHVXVoNHFrTY = new double[1024];
    private final double[] dBprZQxZjIUbnidwEbEFsgB = new double[1024];
    private float[][] izYvnpJmGiMoepycLkTtHXY;
    private int fTYgHRsyVHrYUHzMatjQAKU = 1;
    private int lYIsJtlmBodtJdeFMiGrmbj = 0;
    private final BufferedImage pDAQeBLmUtdZXTRAjtuqUnd = new BufferedImage(1024, 500, 1);
    private final int[] snNNuCYtWVgzONgaZnVaYOT = new int[1280];
    private final int[] ctKiKlqApLnHbBGBCfyBTor = new int[256];
    private final int[] SCJjSuWlrpbrKmEEKtjoHcU = new int[256];
    private final int[] wYePgUBonJzputtjVLJMXpX = new int[1024];
    private double RRnnNgUDxUFGFeaiYduOghS = 1279.0;
    private boolean rlLfOrnBfhXwDoxKtXtJZRR = false;
    private int yKwRggLaMfgwMIUFQoKHBce = 1;
    private boolean mzuRiLdvInzoAeWfRiBnJOp = false;
    private boolean CMOfeAVHYgkhoDpCHlrIxZW = false;
    private boolean AbkRNvAOeWIbEeMzsGvXdIr = false;
    private boolean sZuceysKFofvtPKVqIqCOBW = false;
    private PumrgUjzIBRhWRYVWFJFxPn DsdbIJsDbOeENdTpaIDYbiZ;

    public GzwPWPrZDOEHewlFodtbKbX() {
        this.QPeIwmpzLZIktKLXAJOQHcO();
        this.rHAjVyBgPhqkQKsOvJMPMYn();
    }

    private void rHAjVyBgPhqkQKsOvJMPMYn() {
        int n;
        int n2;
        this.NuCoRkdmXmpraThwzNAiTcw = 500.0 / Math.abs(this.iwitQCGCnkthNoQBBlYaPUM - this.JSuXbPLjXcQLpTiButqPpoI);
        this.OrmpCzNZzYDlbDZDBXyofLf = this.RRnnNgUDxUFGFeaiYduOghS / Math.abs(this.iwitQCGCnkthNoQBBlYaPUM - this.JSuXbPLjXcQLpTiButqPpoI);
        this.lYIsJtlmBodtJdeFMiGrmbj = 0;
        for (n2 = 0; n2 < this.fTYgHRsyVHrYUHzMatjQAKU; ++n2) {
            for (n = 0; n < this.ibbBhgWhrhhiOLwDlcriPhb; ++n) {
                this.izYvnpJmGiMoepycLkTtHXY[n][n2] = -200.0f;
            }
        }
        this.JSuXbPLjXcQLpTiButqPpoI();
        for (n2 = 0; n2 < 1024; ++n2) {
            for (n = 0; n < 500; ++n) {
                this.pDAQeBLmUtdZXTRAjtuqUnd.setRGB(n2, n, 0);
            }
        }
        this.rHAjVyBgPhqkQKsOvJMPMYn(-50, -50);
    }

    private void QPeIwmpzLZIktKLXAJOQHcO() {
        this.addMouseMotionListener(this);
        this.addMouseListener(this);
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(boolean bl) {
        this.sZuceysKFofvtPKVqIqCOBW = bl;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(int n) {
        this.vJgxuXjYdOvTUFZsFThavLL = n;
        this.kVXnygMrAwyMajIgLatcyWS = new double[n / 2];
        this.ibbBhgWhrhhiOLwDlcriPhb = n / 2;
        this.izYvnpJmGiMoepycLkTtHXY = null;
        this.fTYgHRsyVHrYUHzMatjQAKU = n < 0x100000 ? 500 : 250;
        this.izYvnpJmGiMoepycLkTtHXY = new float[this.ibbBhgWhrhhiOLwDlcriPhb][this.fTYgHRsyVHrYUHzMatjQAKU];
        this.GgoKTcuIevtAhezhbHlrofU = new double[1024][this.fTYgHRsyVHrYUHzMatjQAKU];
        this.sUwuMtUcgVzMHVXVoNHFrTY = new double[1024];
        this.rHAjVyBgPhqkQKsOvJMPMYn();
    }

    public void QPeIwmpzLZIktKLXAJOQHcO(int n) {
        if (n != this.rHAjVyBgPhqkQKsOvJMPMYn || !this.sZuceysKFofvtPKVqIqCOBW) {
            this.rHAjVyBgPhqkQKsOvJMPMYn = n;
            this.XphHMDaiRLyTnLXiOVlLPqZ = (double)n / 4.0;
            this.cmBIzvlUaDPTiIjykjjmigy = n / 2;
        }
        this.QPeIwmpzLZIktKLXAJOQHcO = n / 2;
        this.ajlSZBxlJSwYUTeUsFfhumH = (double)n / 2.0 / (double)this.ibbBhgWhrhhiOLwDlcriPhb;
        this.NwteqrdXWwWpaoJmiBDNxxz = this.XphHMDaiRLyTnLXiOVlLPqZ - this.cmBIzvlUaDPTiIjykjjmigy / 2.0;
        this.SYnuCfTgzCxensnEBdDedFe = this.XphHMDaiRLyTnLXiOVlLPqZ + this.cmBIzvlUaDPTiIjykjjmigy / 2.0;
        this.IiqlRFfWYxYaAobCQvdRFEl = (int)Math.round(this.XphHMDaiRLyTnLXiOVlLPqZ - (double)this.TTvVyJBikEjkvfEQPPobmUz / 2.0);
        this.gLHqHFGBEIDXbcqrsZzduVF = (int)Math.round(this.XphHMDaiRLyTnLXiOVlLPqZ + (double)this.TTvVyJBikEjkvfEQPPobmUz / 2.0);
        this.DsdbIJsDbOeENdTpaIDYbiZ.rHAjVyBgPhqkQKsOvJMPMYn(this.XphHMDaiRLyTnLXiOVlLPqZ, this.cmBIzvlUaDPTiIjykjjmigy);
        this.VZagBOcdslnIaKEkojULJvx();
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(int n, boolean bl, boolean bl2, int n2) {
        this.TTvVyJBikEjkvfEQPPobmUz = n;
        this.VZagBOcdslnIaKEkojULJvx = bl;
        this.VmkNmvoUyyfcyaaKFyveguY = bl2;
        this.YGjBevanihqaxYKnUNtrNeA = n2;
        switch (n2) {
            case 1: 
            case 2: 
            case 5: {
                this.RRnnNgUDxUFGFeaiYduOghS = 255.0;
                break;
            }
            case 3: {
                this.RRnnNgUDxUFGFeaiYduOghS = 895.0;
                break;
            }
            case 4: {
                this.RRnnNgUDxUFGFeaiYduOghS = 639.0;
                break;
            }
        }
        this.OrmpCzNZzYDlbDZDBXyofLf = this.RRnnNgUDxUFGFeaiYduOghS / Math.abs(this.iwitQCGCnkthNoQBBlYaPUM - this.JSuXbPLjXcQLpTiButqPpoI);
        this.tJuPpiiZKFnZdtTTOrwfbxj = true;
        this.wunjGuaHWPKejzkQKUJfPKe = (int)Math.round((double)this.vJgxuXjYdOvTUFZsFThavLL / 2048.0 / ((double)this.rHAjVyBgPhqkQKsOvJMPMYn / 2.0 / (double)n));
        this.IiqlRFfWYxYaAobCQvdRFEl = (int)Math.round(this.XphHMDaiRLyTnLXiOVlLPqZ - (double)n / 2.0);
        this.gLHqHFGBEIDXbcqrsZzduVF = (int)Math.round(this.XphHMDaiRLyTnLXiOVlLPqZ + (double)n / 2.0);
        this.iwitQCGCnkthNoQBBlYaPUM();
        this.VZagBOcdslnIaKEkojULJvx();
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(PumrgUjzIBRhWRYVWFJFxPn pumrgUjzIBRhWRYVWFJFxPn) {
        this.DsdbIJsDbOeENdTpaIDYbiZ = pumrgUjzIBRhWRYVWFJFxPn;
    }

    public void QPeIwmpzLZIktKLXAJOQHcO(boolean bl) {
        this.mzuRiLdvInzoAeWfRiBnJOp = bl;
        this.VZagBOcdslnIaKEkojULJvx();
    }

    public void JSuXbPLjXcQLpTiButqPpoI(boolean bl) {
        this.CMOfeAVHYgkhoDpCHlrIxZW = bl;
        this.VZagBOcdslnIaKEkojULJvx();
    }

    public void iwitQCGCnkthNoQBBlYaPUM(boolean bl) {
        this.AbkRNvAOeWIbEeMzsGvXdIr = bl;
        this.VZagBOcdslnIaKEkojULJvx();
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(double[] dArray) {
        if (!this.FoVkhFqKjpvomrYQnnVFKwY) {
            this.kVXnygMrAwyMajIgLatcyWS = dArray;
        }
        for (int i = 0; i < this.ibbBhgWhrhhiOLwDlcriPhb; ++i) {
            this.izYvnpJmGiMoepycLkTtHXY[i][this.lYIsJtlmBodtJdeFMiGrmbj] = (float)dArray[i];
        }
        this.JSuXbPLjXcQLpTiButqPpoI(this.lYIsJtlmBodtJdeFMiGrmbj);
        ++this.lYIsJtlmBodtJdeFMiGrmbj;
        if (this.lYIsJtlmBodtJdeFMiGrmbj >= this.fTYgHRsyVHrYUHzMatjQAKU) {
            this.lYIsJtlmBodtJdeFMiGrmbj = 0;
        }
        this.VZagBOcdslnIaKEkojULJvx();
    }

    private void JSuXbPLjXcQLpTiButqPpoI() {
        int n;
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        for (n = 0; n < 128; ++n) {
            this.snNNuCYtWVgzONgaZnVaYOT[n] = n2 << 16 | n3 << 8 | n4;
            ++n4;
        }
        n2 = 0;
        n3 = 0;
        n4 = 127;
        for (n = 128; n < 256; ++n) {
            this.snNNuCYtWVgzONgaZnVaYOT[n] = n2 << 16 | n3 << 8 | n4;
            ++n4;
            ++n3;
        }
        n2 = 0;
        n3 = 127;
        n4 = 255;
        for (n = 256; n < 384; ++n) {
            this.snNNuCYtWVgzONgaZnVaYOT[n] = n2 << 16 | n3 << 8 | n4;
            ++n3;
            --n4;
        }
        n2 = 0;
        n3 = 255;
        n4 = 127;
        for (n = 384; n < 512; ++n) {
            this.snNNuCYtWVgzONgaZnVaYOT[n] = n2 << 16 | n3 << 8 | n4;
            ++n2;
            --n4;
        }
        n2 = 127;
        n3 = 255;
        n4 = 0;
        for (n = 512; n < 640; ++n) {
            this.snNNuCYtWVgzONgaZnVaYOT[n] = n2 << 16 | n3 << 8 | n4;
            ++n2;
        }
        n2 = 255;
        n3 = 255;
        n4 = 0;
        for (n = 640; n < 768; ++n) {
            this.snNNuCYtWVgzONgaZnVaYOT[n] = n2 << 16 | n3 << 8 | n4;
            --n3;
        }
        n2 = 255;
        n3 = 127;
        n4 = 0;
        for (n = 768; n < 896; ++n) {
            this.snNNuCYtWVgzONgaZnVaYOT[n] = n2 << 16 | n3 << 8 | n4;
            --n3;
        }
        n4 = 0;
        n3 = 0;
        n2 = 0;
        for (n = 0; n < 256; ++n) {
            this.ctKiKlqApLnHbBGBCfyBTor[n] = n2 << 16 | n3 << 8 | n4;
            ++n3;
        }
        n4 = 0;
        n3 = 0;
        n2 = 0;
        for (n = 0; n < 256; ++n) {
            this.SCJjSuWlrpbrKmEEKtjoHcU[n] = n2 << 16 | n3 << 8 | n4;
            ++n2;
            ++n3;
            ++n4;
        }
        n2 = 0;
        n3 = 0;
        n4 = 0;
        for (n = 0; n < 128; ++n) {
            this.wYePgUBonJzputtjVLJMXpX[n] = n2 << 16 | n3 << 8 | n4;
            ++n4;
        }
        n2 = 0;
        n3 = 0;
        n4 = 127;
        for (n = 128; n < 256; ++n) {
            this.wYePgUBonJzputtjVLJMXpX[n] = n2 << 16 | n3 << 8 | n4;
            ++n2;
            ++n4;
        }
        n2 = 127;
        n3 = 0;
        n4 = 255;
        for (n = 256; n < 384; ++n) {
            this.wYePgUBonJzputtjVLJMXpX[n] = n2 << 16 | n3 << 8 | n4;
            --n4;
            ++n2;
        }
        n2 = 255;
        n3 = 0;
        n4 = 127;
        for (n = 384; n < 512; ++n) {
            this.wYePgUBonJzputtjVLJMXpX[n] = n2 << 16 | n3 << 8 | n4;
            --n4;
            ++n3;
        }
        n2 = 255;
        n3 = 127;
        n4 = 0;
        for (n = 512; n < 640; ++n) {
            this.wYePgUBonJzputtjVLJMXpX[n] = n2 << 16 | n3 << 8 | n4;
            ++n3;
        }
    }

    private void rHAjVyBgPhqkQKsOvJMPMYn(int n, int n2) {
        this.YikeWIksDnZbpLLacoPMfKN = n - 80;
        this.rTbADuShFCOuMvGFEuNmbFb = 520 - n2;
        this.VZagBOcdslnIaKEkojULJvx();
    }

    private void JSuXbPLjXcQLpTiButqPpoI(int n) {
        int n2 = (int)(this.XphHMDaiRLyTnLXiOVlLPqZ / this.ajlSZBxlJSwYUTeUsFfhumH);
        block7: for (int i = 0; i < 1024; ++i) {
            double d;
            int n3 = (i - 512) * this.wunjGuaHWPKejzkQKUJfPKe;
            if ((n3 += n2) < 0 || n3 + this.wunjGuaHWPKejzkQKUJfPKe > this.ibbBhgWhrhhiOLwDlcriPhb) {
                d = -200.0;
            } else if (this.wunjGuaHWPKejzkQKUJfPKe > 1) {
                d = -200.0;
                for (int j = 0; j < this.wunjGuaHWPKejzkQKUJfPKe; ++j) {
                    if (!(d < (double)this.izYvnpJmGiMoepycLkTtHXY[n3 + j][n])) continue;
                    d = this.izYvnpJmGiMoepycLkTtHXY[n3 + j][n];
                }
            } else {
                d = this.izYvnpJmGiMoepycLkTtHXY[n3][n];
            }
            if (d < this.JSuXbPLjXcQLpTiButqPpoI) {
                d = this.JSuXbPLjXcQLpTiButqPpoI;
            }
            this.GgoKTcuIevtAhezhbHlrofU[i][n] = d;
            if ((d = this.OrmpCzNZzYDlbDZDBXyofLf * Math.abs(this.JSuXbPLjXcQLpTiButqPpoI - d)) > this.RRnnNgUDxUFGFeaiYduOghS) {
                d = this.RRnnNgUDxUFGFeaiYduOghS;
            }
            switch (this.YGjBevanihqaxYKnUNtrNeA) {
                case 1: {
                    this.pDAQeBLmUtdZXTRAjtuqUnd.setRGB(i, n, this.ctKiKlqApLnHbBGBCfyBTor[(int)d]);
                    continue block7;
                }
                case 2: {
                    this.pDAQeBLmUtdZXTRAjtuqUnd.setRGB(i, n, this.SCJjSuWlrpbrKmEEKtjoHcU[(int)d]);
                    continue block7;
                }
                case 3: {
                    this.pDAQeBLmUtdZXTRAjtuqUnd.setRGB(i, n, this.snNNuCYtWVgzONgaZnVaYOT[(int)d]);
                    continue block7;
                }
                case 4: {
                    this.pDAQeBLmUtdZXTRAjtuqUnd.setRGB(i, n, this.wYePgUBonJzputtjVLJMXpX[(int)d]);
                    continue block7;
                }
                case 5: {
                    this.pDAQeBLmUtdZXTRAjtuqUnd.setRGB(i, n, this.SCJjSuWlrpbrKmEEKtjoHcU[(int)(255.0 - d)]);
                    continue block7;
                }
            }
        }
    }

    private void iwitQCGCnkthNoQBBlYaPUM() {
        for (int i = 0; i < this.fTYgHRsyVHrYUHzMatjQAKU; ++i) {
            this.JSuXbPLjXcQLpTiButqPpoI(i);
        }
    }

    private void dnqxuOOQwmxxivZzrQBWydh() {
        for (int i = 0; i < 1024; ++i) {
            for (int j = 0; j < this.fTYgHRsyVHrYUHzMatjQAKU; ++j) {
                this.sUwuMtUcgVzMHVXVoNHFrTY[i] = this.sUwuMtUcgVzMHVXVoNHFrTY[i] + this.GgoKTcuIevtAhezhbHlrofU[i][j];
            }
            this.sUwuMtUcgVzMHVXVoNHFrTY[i] = this.sUwuMtUcgVzMHVXVoNHFrTY[i] / (double)this.fTYgHRsyVHrYUHzMatjQAKU;
        }
    }

    @Override
    public void paintComponent(Graphics graphics) {
        int n;
        int n2;
        int n3;
        int n4;
        double d;
        int n5;
        int n6;
        this.FoVkhFqKjpvomrYQnnVFKwY = true;
        int n7 = 0;
        int n8 = 0;
        Graphics2D graphics2D = (Graphics2D)graphics;
        FontMetrics fontMetrics = graphics2D.getFontMetrics();
        Color color = Color.decode("#FFFFFF");
        Color color2 = Color.decode("#FFFFFF");
        graphics2D.setColor(Color.decode("#555555"));
        graphics2D.drawLine(40, 500, 40, 290);
        graphics2D.drawLine(40, 250, 40, 40);
        graphics2D.setColor(Color.decode("#FFFFFF"));
        graphics2D.drawLine(80, 520, 1104, 520);
        graphics2D.drawLine(79, 520, 79, 20);
        graphics2D.drawLine(75, 20, 79, 20);
        graphics2D.drawLine(75, 270, 80, 270);
        graphics2D.drawLine(75, 520, 80, 520);
        graphics2D.drawLine(592, 520, 592, 525);
        graphics2D.drawLine(80, 520, 80, 525);
        graphics2D.drawLine(1104, 520, 1104, 525);
        String string = String.valueOf(Math.round(this.XphHMDaiRLyTnLXiOVlLPqZ)) + " Hz";
        graphics2D.drawString(string, 592 - fontMetrics.stringWidth(string) / 2, 545);
        int n9 = this.IiqlRFfWYxYaAobCQvdRFEl;
        string = n9 < 0 ? "- Hz" : String.valueOf(n9) + " Hz";
        graphics2D.drawString(string, 80, 545);
        n9 = this.gLHqHFGBEIDXbcqrsZzduVF;
        string = n9 > this.QPeIwmpzLZIktKLXAJOQHcO ? "- Hz" : String.valueOf(n9) + " Hz";
        graphics2D.drawString(string, 1104 - fontMetrics.stringWidth(string), 545);
        string = String.valueOf(Math.round(this.iwitQCGCnkthNoQBBlYaPUM)) + " dB";
        graphics2D.drawString(string, 70 - fontMetrics.stringWidth(string), 25);
        string = String.valueOf(Math.round(this.JSuXbPLjXcQLpTiButqPpoI)) + " dB";
        graphics2D.drawString(string, 70 - fontMetrics.stringWidth(string), 525);
        string = String.valueOf((double)Math.round(this.dnqxuOOQwmxxivZzrQBWydh * 10.0) / 10.0) + " dB";
        graphics2D.drawString(string, 70 - fontMetrics.stringWidth(string), 275);
        if (this.VmkNmvoUyyfcyaaKFyveguY) {
            graphics.drawImage(this.pDAQeBLmUtdZXTRAjtuqUnd, 80, 20, null);
            graphics2D.setColor(Color.decode("#FF0000"));
            graphics2D.drawLine(80, this.lYIsJtlmBodtJdeFMiGrmbj + 20, 1104, this.lYIsJtlmBodtJdeFMiGrmbj + 20);
        }
        int n10 = (int)(this.XphHMDaiRLyTnLXiOVlLPqZ / this.ajlSZBxlJSwYUTeUsFfhumH);
        if (this.VZagBOcdslnIaKEkojULJvx || this.AbkRNvAOeWIbEeMzsGvXdIr) {
            switch (this.YGjBevanihqaxYKnUNtrNeA) {
                case 3: {
                    color = Color.decode("#FFFFFF");
                    color2 = Color.decode("#FFFFFF");
                    break;
                }
                case 2: {
                    color = Color.decode("#00FF00");
                    color2 = Color.decode("#00FF00");
                    break;
                }
                case 1: {
                    color = Color.decode("#EDFF00");
                    color2 = Color.decode("#EDFF00");
                    break;
                }
            }
        }
        if (this.VZagBOcdslnIaKEkojULJvx) {
            graphics2D.setColor(color);
            for (n6 = 0; n6 < 1024; ++n6) {
                n5 = (n6 - 512) * this.wunjGuaHWPKejzkQKUJfPKe;
                if ((n5 += n10) < 0 || n5 + this.wunjGuaHWPKejzkQKUJfPKe > this.ibbBhgWhrhhiOLwDlcriPhb) {
                    d = -200.0;
                } else if (this.wunjGuaHWPKejzkQKUJfPKe > 1) {
                    d = -200.0;
                    for (int i = 0; i < this.wunjGuaHWPKejzkQKUJfPKe; ++i) {
                        if (!(d < this.kVXnygMrAwyMajIgLatcyWS[n5 + i])) continue;
                        d = this.kVXnygMrAwyMajIgLatcyWS[n5 + i];
                    }
                } else {
                    d = this.kVXnygMrAwyMajIgLatcyWS[n5];
                }
                d = this.dBprZQxZjIUbnidwEbEFsgB[n6] = (this.dBprZQxZjIUbnidwEbEFsgB[n6] + d) / 2.0;
                if (d < this.JSuXbPLjXcQLpTiButqPpoI) {
                    d = this.JSuXbPLjXcQLpTiButqPpoI;
                }
                d = 520.0 + this.NuCoRkdmXmpraThwzNAiTcw * (this.JSuXbPLjXcQLpTiButqPpoI - d);
                n4 = 80 + n6;
                n3 = (int)d;
                if (n3 < -1) {
                    n3 = -1;
                }
                if (n6 == 0) {
                    n7 = n3;
                    continue;
                }
                graphics2D.drawLine(n4 - 1, n7, n4, n3);
                n7 = n3;
            }
        }
        if (this.AbkRNvAOeWIbEeMzsGvXdIr) {
            this.dnqxuOOQwmxxivZzrQBWydh();
            graphics2D.setColor(color2);
            for (n6 = 0; n6 < 1024; ++n6) {
                d = this.sUwuMtUcgVzMHVXVoNHFrTY[n6];
                if (d < this.JSuXbPLjXcQLpTiButqPpoI) {
                    d = this.JSuXbPLjXcQLpTiButqPpoI;
                }
                d = 520.0 + this.NuCoRkdmXmpraThwzNAiTcw * (this.JSuXbPLjXcQLpTiButqPpoI - d);
                n4 = 80 + n6;
                n3 = (int)d;
                if (n3 < -1) {
                    n3 = -1;
                }
                if (n6 == 0) {
                    n8 = n3;
                    continue;
                }
                graphics2D.drawLine(n4 - 1, n8, n4, n3);
                n8 = n3;
            }
        }
        if (this.mzuRiLdvInzoAeWfRiBnJOp) {
            double d2;
            graphics2D.setColor(Color.decode("#FFC400"));
            graphics2D.setStroke(new BasicStroke(2.0f));
            string = String.valueOf(Math.round(this.cmBIzvlUaDPTiIjykjjmigy)) + " Hz";
            graphics2D.drawString(string, 592 - fontMetrics.stringWidth(string) / 2, 565);
            double d3 = this.NwteqrdXWwWpaoJmiBDNxxz < 0.0 ? 0.0 : this.NwteqrdXWwWpaoJmiBDNxxz;
            n4 = (int)Math.round((d3 / this.ajlSZBxlJSwYUTeUsFfhumH - (double)n10) / (double)this.wunjGuaHWPKejzkQKUJfPKe + 512.0);
            if (n4 >= 0 && n4 <= 1024) {
                graphics2D.drawLine(80 + n4, 525, 80 + n4, 20);
                n2 = n4 < 412 ? 60 : -40;
                string = String.valueOf(Math.round(d3)) + " Hz";
                graphics2D.drawString(string, 80 + n4 + n2 - fontMetrics.stringWidth(string), 565);
            }
            if ((n4 = (int)Math.round(((d2 = this.SYnuCfTgzCxensnEBdDedFe > (double)(this.rHAjVyBgPhqkQKsOvJMPMYn / 2) ? (double)(this.rHAjVyBgPhqkQKsOvJMPMYn / 2) : this.SYnuCfTgzCxensnEBdDedFe) / this.ajlSZBxlJSwYUTeUsFfhumH - (double)n10) / (double)this.wunjGuaHWPKejzkQKUJfPKe + 512.0)) >= 0 && n4 <= 1025) {
                graphics2D.drawLine(80 + n4, 525, 80 + n4, 20);
                n2 = n4 > 612 ? 0 : 100;
                string = String.valueOf(Math.round(d2)) + " Hz";
                graphics2D.drawString(string, 80 + n4 + n2 - fontMetrics.stringWidth(string), 565);
            }
            graphics2D.setStroke(new BasicStroke(1.0f));
            if (this.CMOfeAVHYgkhoDpCHlrIxZW) {
                graphics2D.setColor(Color.decode("#00FF00"));
                string = String.valueOf(Math.round(d3)) + "Hz - " + String.valueOf(Math.round(d2)) + " Hz  =>  0 Hz - " + String.valueOf(Math.round(d2 - d3)) + " Hz";
                graphics2D.drawString(string, 200, 545);
            }
        }
        if (this.YikeWIksDnZbpLLacoPMfKN >= 0 && this.YikeWIksDnZbpLLacoPMfKN <= 1024 && this.rTbADuShFCOuMvGFEuNmbFb <= 500 && this.rTbADuShFCOuMvGFEuNmbFb >= 0 && this.tJuPpiiZKFnZdtTTOrwfbxj) {
            String string2;
            double d4;
            if (this.rTbADuShFCOuMvGFEuNmbFb > 333) {
                this.yKwRggLaMfgwMIUFQoKHBce = 100;
            } else if (this.rTbADuShFCOuMvGFEuNmbFb > 166 && this.rTbADuShFCOuMvGFEuNmbFb <= 333) {
                this.yKwRggLaMfgwMIUFQoKHBce = 10;
            } else if (this.rTbADuShFCOuMvGFEuNmbFb > 0 && this.rTbADuShFCOuMvGFEuNmbFb <= 166) {
                this.yKwRggLaMfgwMIUFQoKHBce = 1;
            }
            n2 = this.YikeWIksDnZbpLLacoPMfKN > 512 ? -15 : 95;
            int n11 = this.rTbADuShFCOuMvGFEuNmbFb > 250 ? 35 : -65;
            graphics2D.setColor(Color.decode("#000000"));
            graphics.fillRect(80 + this.YikeWIksDnZbpLLacoPMfKN + n2 - 85, 520 - this.rTbADuShFCOuMvGFEuNmbFb + n11 - 25, 90, 82);
            graphics2D.setColor(Color.decode("#FF0000"));
            graphics2D.drawLine(80 + this.YikeWIksDnZbpLLacoPMfKN - 20, 520 - this.rTbADuShFCOuMvGFEuNmbFb, 80 + this.YikeWIksDnZbpLLacoPMfKN + 20, 520 - this.rTbADuShFCOuMvGFEuNmbFb);
            graphics2D.drawLine(80 + this.YikeWIksDnZbpLLacoPMfKN, 520, 80 + this.YikeWIksDnZbpLLacoPMfKN, 20);
            graphics2D.setColor(Color.decode("#00E8E4"));
            double d5 = (((double)this.YikeWIksDnZbpLLacoPMfKN - 512.0) * (double)this.wunjGuaHWPKejzkQKUJfPKe + (double)n10) * this.ajlSZBxlJSwYUTeUsFfhumH;
            if (d5 >= 0.0 && d5 <= (double)this.QPeIwmpzLZIktKLXAJOQHcO) {
                string = String.valueOf((double)Math.round(d5 * 100.0) / 100.0) + " Hz";
                d4 = this.JSuXbPLjXcQLpTiButqPpoI + (double)this.rTbADuShFCOuMvGFEuNmbFb / this.NuCoRkdmXmpraThwzNAiTcw;
                string2 = String.valueOf(Math.round(d4)) + " dB";
            } else {
                string = "- Hz";
                string2 = "- dB";
            }
            graphics2D.drawString(string, 80 + this.YikeWIksDnZbpLLacoPMfKN + n2 - fontMetrics.stringWidth(string), 520 - this.rTbADuShFCOuMvGFEuNmbFb - 10 + n11);
            graphics2D.drawString(string2, 80 + this.YikeWIksDnZbpLLacoPMfKN + n2 - fontMetrics.stringWidth(string2), 520 - this.rTbADuShFCOuMvGFEuNmbFb + 10 + n11);
            int n12 = 500 - this.rTbADuShFCOuMvGFEuNmbFb;
            if (n12 > this.fTYgHRsyVHrYUHzMatjQAKU - 1) {
                n12 = this.fTYgHRsyVHrYUHzMatjQAKU - 1;
            } else if (n12 < 0) {
                n12 = 0;
            }
            graphics2D.setColor(Color.decode("#FFFF00"));
            n5 = (this.YikeWIksDnZbpLLacoPMfKN - 512) * this.wunjGuaHWPKejzkQKUJfPKe;
            if ((n5 += n10) >= 0 && n5 < this.ibbBhgWhrhhiOLwDlcriPhb) {
                d4 = this.izYvnpJmGiMoepycLkTtHXY[n5][n12];
                string = String.valueOf(Math.round(d4)) + " dB";
            } else {
                string = "- dB";
            }
            graphics2D.drawString(string, 80 + this.YikeWIksDnZbpLLacoPMfKN + n2 - fontMetrics.stringWidth(string), 520 - this.rTbADuShFCOuMvGFEuNmbFb + 30 + n11);
            string = "< > " + String.valueOf(Math.round(this.yKwRggLaMfgwMIUFQoKHBce)) + " Hz";
            graphics2D.drawString(string, 80 + this.YikeWIksDnZbpLLacoPMfKN + n2 - fontMetrics.stringWidth(string), 520 - this.rTbADuShFCOuMvGFEuNmbFb + 50 + n11);
        }
        if (this.YikeWIksDnZbpLLacoPMfKN < 0) {
            graphics2D.setColor(Color.decode("#FF0000"));
            n = this.rTbADuShFCOuMvGFEuNmbFb - 30;
            graphics2D.drawLine(80 + this.YikeWIksDnZbpLLacoPMfKN, 520 - n, 80 + this.YikeWIksDnZbpLLacoPMfKN - 10, 520 - (n + 10));
            graphics2D.drawLine(80 + this.YikeWIksDnZbpLLacoPMfKN, 520 - n, 80 + this.YikeWIksDnZbpLLacoPMfKN + 10, 520 - (n + 10));
            n = this.rTbADuShFCOuMvGFEuNmbFb + 30;
            graphics2D.drawLine(80 + this.YikeWIksDnZbpLLacoPMfKN, 520 - n, 80 + this.YikeWIksDnZbpLLacoPMfKN - 10, 520 - (n - 10));
            graphics2D.drawLine(80 + this.YikeWIksDnZbpLLacoPMfKN, 520 - n, 80 + this.YikeWIksDnZbpLLacoPMfKN + 10, 520 - (n - 10));
            string = this.YikeWIksDnZbpLLacoPMfKN < -40 ? "UL" : "LL";
            graphics2D.drawString(string, 80 + this.YikeWIksDnZbpLLacoPMfKN - fontMetrics.stringWidth(string) / 2, 520 - (this.rTbADuShFCOuMvGFEuNmbFb + 40));
        }
        if (this.YikeWIksDnZbpLLacoPMfKN > 0 && this.rTbADuShFCOuMvGFEuNmbFb < 0 && this.mzuRiLdvInzoAeWfRiBnJOp) {
            graphics2D.setColor(Color.decode("#FFC400"));
            n = this.YikeWIksDnZbpLLacoPMfKN - 30;
            graphics2D.drawLine(80 + n, 520 - this.rTbADuShFCOuMvGFEuNmbFb, 80 + (n + 10), 520 - (this.rTbADuShFCOuMvGFEuNmbFb - 10));
            graphics2D.drawLine(80 + n, 520 - this.rTbADuShFCOuMvGFEuNmbFb, 80 + (n + 10), 520 - (this.rTbADuShFCOuMvGFEuNmbFb + 10));
            n = this.YikeWIksDnZbpLLacoPMfKN + 30;
            graphics2D.drawLine(80 + n, 520 - this.rTbADuShFCOuMvGFEuNmbFb, 80 + (n - 10), 520 - (this.rTbADuShFCOuMvGFEuNmbFb - 10));
            graphics2D.drawLine(80 + n, 520 - this.rTbADuShFCOuMvGFEuNmbFb, 80 + (n - 10), 520 - (this.rTbADuShFCOuMvGFEuNmbFb + 10));
            string = "BW";
            graphics2D.drawString(string, 80 + this.YikeWIksDnZbpLLacoPMfKN - 45 - fontMetrics.stringWidth(string) / 2, 520 - this.rTbADuShFCOuMvGFEuNmbFb + 5);
        }
        this.FoVkhFqKjpvomrYQnnVFKwY = false;
    }

    private void VZagBOcdslnIaKEkojULJvx() {
        SwingUtilities.invokeLater(new Runnable(){

            @Override
            public void run() {
                GzwPWPrZDOEHewlFodtbKbX.this.repaint();
            }
        });
    }

    @Override
    public void run() {
    }

    @Override
    public void mouseDragged(MouseEvent mouseEvent) {
        int n = mouseEvent.getX();
        int n2 = mouseEvent.getY();
        double d = this.XphHMDaiRLyTnLXiOVlLPqZ;
        if (n > 80 && n2 < 520) {
            if (this.xurJiSGFDQVeEtISoLSazWS < n) {
                d -= (double)this.yKwRggLaMfgwMIUFQoKHBce;
            } else if (this.xurJiSGFDQVeEtISoLSazWS > n) {
                d += (double)this.yKwRggLaMfgwMIUFQoKHBce;
            }
            this.xurJiSGFDQVeEtISoLSazWS = n;
            if (d < 0.0) {
                d = 0.0;
            } else if (d > (double)this.rHAjVyBgPhqkQKsOvJMPMYn / 2.0) {
                d = (double)this.rHAjVyBgPhqkQKsOvJMPMYn / 2.0;
            }
            this.XphHMDaiRLyTnLXiOVlLPqZ = d;
            this.NwteqrdXWwWpaoJmiBDNxxz = this.XphHMDaiRLyTnLXiOVlLPqZ - this.cmBIzvlUaDPTiIjykjjmigy / 2.0;
            this.SYnuCfTgzCxensnEBdDedFe = this.XphHMDaiRLyTnLXiOVlLPqZ + this.cmBIzvlUaDPTiIjykjjmigy / 2.0;
            this.IiqlRFfWYxYaAobCQvdRFEl = (int)Math.round(this.XphHMDaiRLyTnLXiOVlLPqZ - (double)this.TTvVyJBikEjkvfEQPPobmUz / 2.0);
            this.gLHqHFGBEIDXbcqrsZzduVF = (int)Math.round(this.XphHMDaiRLyTnLXiOVlLPqZ + (double)this.TTvVyJBikEjkvfEQPPobmUz / 2.0);
            this.DsdbIJsDbOeENdTpaIDYbiZ.rHAjVyBgPhqkQKsOvJMPMYn(this.XphHMDaiRLyTnLXiOVlLPqZ, this.cmBIzvlUaDPTiIjykjjmigy);
            this.rlLfOrnBfhXwDoxKtXtJZRR = true;
        }
        if (n >= 40 && n < 80) {
            if (this.KLSmtNpcsSwOKRbEbUKdpqL < n2) {
                this.JSuXbPLjXcQLpTiButqPpoI -= 1.0;
            } else if (this.KLSmtNpcsSwOKRbEbUKdpqL > n2) {
                this.JSuXbPLjXcQLpTiButqPpoI += 1.0;
            }
            this.KLSmtNpcsSwOKRbEbUKdpqL = n2;
            if (this.JSuXbPLjXcQLpTiButqPpoI < -200.0) {
                this.JSuXbPLjXcQLpTiButqPpoI = -200.0;
            } else if (this.JSuXbPLjXcQLpTiButqPpoI > 0.0) {
                this.JSuXbPLjXcQLpTiButqPpoI = 0.0;
            } else if (this.JSuXbPLjXcQLpTiButqPpoI >= this.iwitQCGCnkthNoQBBlYaPUM) {
                this.JSuXbPLjXcQLpTiButqPpoI = this.iwitQCGCnkthNoQBBlYaPUM - 1.0;
            }
            this.dnqxuOOQwmxxivZzrQBWydh = (this.iwitQCGCnkthNoQBBlYaPUM - this.JSuXbPLjXcQLpTiButqPpoI) / 2.0 + this.JSuXbPLjXcQLpTiButqPpoI;
            this.rlLfOrnBfhXwDoxKtXtJZRR = true;
        }
        if (n < 40) {
            if (this.DamZYXCIxKyKrnRzlNpeRfa < n2) {
                this.iwitQCGCnkthNoQBBlYaPUM -= 1.0;
            } else if (this.DamZYXCIxKyKrnRzlNpeRfa > n2) {
                this.iwitQCGCnkthNoQBBlYaPUM += 1.0;
            }
            this.DamZYXCIxKyKrnRzlNpeRfa = n2;
            if (this.iwitQCGCnkthNoQBBlYaPUM < -200.0) {
                this.iwitQCGCnkthNoQBBlYaPUM = -200.0;
            } else if (this.iwitQCGCnkthNoQBBlYaPUM > 0.0) {
                this.iwitQCGCnkthNoQBBlYaPUM = 0.0;
            } else if (this.iwitQCGCnkthNoQBBlYaPUM <= this.JSuXbPLjXcQLpTiButqPpoI) {
                this.iwitQCGCnkthNoQBBlYaPUM = this.JSuXbPLjXcQLpTiButqPpoI + 1.0;
            }
            this.dnqxuOOQwmxxivZzrQBWydh = (this.iwitQCGCnkthNoQBBlYaPUM - this.JSuXbPLjXcQLpTiButqPpoI) / 2.0 + this.JSuXbPLjXcQLpTiButqPpoI;
            this.rlLfOrnBfhXwDoxKtXtJZRR = true;
        }
        if (n < 80) {
            this.NuCoRkdmXmpraThwzNAiTcw = 500.0 / Math.abs(this.iwitQCGCnkthNoQBBlYaPUM - this.JSuXbPLjXcQLpTiButqPpoI);
            this.OrmpCzNZzYDlbDZDBXyofLf = this.RRnnNgUDxUFGFeaiYduOghS / Math.abs(this.iwitQCGCnkthNoQBBlYaPUM - this.JSuXbPLjXcQLpTiButqPpoI);
        }
        if (n > 80 && n2 > 520 && this.mzuRiLdvInzoAeWfRiBnJOp) {
            if (this.ggsqrqYbiokXEjuGiCwGpvf < n) {
                this.cmBIzvlUaDPTiIjykjjmigy += 100.0;
            } else if (this.ggsqrqYbiokXEjuGiCwGpvf > n) {
                this.cmBIzvlUaDPTiIjykjjmigy -= 100.0;
            }
            this.ggsqrqYbiokXEjuGiCwGpvf = n;
            if (this.cmBIzvlUaDPTiIjykjjmigy < 100.0) {
                this.cmBIzvlUaDPTiIjykjjmigy = 100.0;
            } else if (this.cmBIzvlUaDPTiIjykjjmigy > (double)(this.rHAjVyBgPhqkQKsOvJMPMYn / 2)) {
                this.cmBIzvlUaDPTiIjykjjmigy = this.rHAjVyBgPhqkQKsOvJMPMYn / 2;
            }
            this.NwteqrdXWwWpaoJmiBDNxxz = this.XphHMDaiRLyTnLXiOVlLPqZ - this.cmBIzvlUaDPTiIjykjjmigy / 2.0;
            this.SYnuCfTgzCxensnEBdDedFe = this.XphHMDaiRLyTnLXiOVlLPqZ + this.cmBIzvlUaDPTiIjykjjmigy / 2.0;
            this.DsdbIJsDbOeENdTpaIDYbiZ.rHAjVyBgPhqkQKsOvJMPMYn(this.XphHMDaiRLyTnLXiOVlLPqZ, this.cmBIzvlUaDPTiIjykjjmigy);
        }
        this.rHAjVyBgPhqkQKsOvJMPMYn(mouseEvent.getX(), mouseEvent.getY());
    }

    @Override
    public void mouseMoved(MouseEvent mouseEvent) {
        if (mouseEvent.getSource() == this) {
            this.rHAjVyBgPhqkQKsOvJMPMYn(mouseEvent.getX(), mouseEvent.getY());
        }
    }

    @Override
    public void mouseClicked(MouseEvent mouseEvent) {
    }

    @Override
    public void mousePressed(MouseEvent mouseEvent) {
    }

    @Override
    public void mouseReleased(MouseEvent mouseEvent) {
        if (this.rlLfOrnBfhXwDoxKtXtJZRR) {
            this.rlLfOrnBfhXwDoxKtXtJZRR = false;
            this.iwitQCGCnkthNoQBBlYaPUM();
            this.VZagBOcdslnIaKEkojULJvx();
        }
    }

    @Override
    public void mouseEntered(MouseEvent mouseEvent) {
    }

    @Override
    public void mouseExited(MouseEvent mouseEvent) {
        if (mouseEvent.getSource() == this) {
            this.rHAjVyBgPhqkQKsOvJMPMYn(-50, -50);
        }
    }
}

