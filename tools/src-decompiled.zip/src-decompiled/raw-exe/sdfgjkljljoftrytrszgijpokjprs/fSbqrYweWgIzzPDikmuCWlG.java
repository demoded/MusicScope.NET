/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.SptUCyYjbKJFZiSwGHPpFmZ;
import sdfgjkljljoftrytrszgijpokjprs.eJnHMGFAPyJBjoMvbKedmZt;

public interface fSbqrYweWgIzzPDikmuCWlG {
    public void rHAjVyBgPhqkQKsOvJMPMYn(eJnHMGFAPyJBjoMvbKedmZt var1);

    public void rHAjVyBgPhqkQKsOvJMPMYn(SptUCyYjbKJFZiSwGHPpFmZ var1);

    public void rHAjVyBgPhqkQKsOvJMPMYn(String var1);
}

