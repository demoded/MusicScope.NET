/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.util.ArrayList;
import java.util.List;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Mixer;
import sdfgjkljljoftrytrszgijpokjprs.KFVWmcqOBgYFxPgeswapvPe;
import sdfgjkljljoftrytrszgijpokjprs.YzXXpcCCVJkKMcoHoACbjGG;
import sdfgjkljljoftrytrszgijpokjprs.sAVBeCYeaIWVZOjBqiIeTcH;

public class FXMxvrEFDHXVZBIoaPqKuiI {
    public static <C extends DataLine> List<sAVBeCYeaIWVZOjBqiIeTcH> rHAjVyBgPhqkQKsOvJMPMYn(Class<C> clazz, int[] nArray, int[] nArray2, KFVWmcqOBgYFxPgeswapvPe[] kFVWmcqOBgYFxPgeswapvPeArray, boolean bl) {
        ArrayList<sAVBeCYeaIWVZOjBqiIeTcH> arrayList = new ArrayList<sAVBeCYeaIWVZOjBqiIeTcH>(0);
        if (!YzXXpcCCVJkKMcoHoACbjGG.iwitQCGCnkthNoQBBlYaPUM()) {
            for (Mixer.Info info : AudioSystem.getMixerInfo()) {
                sAVBeCYeaIWVZOjBqiIeTcH sAVBeCYeaIWVZOjBqiIeTcH2 = new sAVBeCYeaIWVZOjBqiIeTcH(info, AudioFormat.Encoding.PCM_SIGNED, bl);
                for (int n : nArray) {
                    for (int n2 : nArray2) {
                        for (KFVWmcqOBgYFxPgeswapvPe kFVWmcqOBgYFxPgeswapvPe : kFVWmcqOBgYFxPgeswapvPeArray) {
                            AudioFormat audioFormat = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, n, kFVWmcqOBgYFxPgeswapvPe.rHAjVyBgPhqkQKsOvJMPMYn(), n2, n2 * kFVWmcqOBgYFxPgeswapvPe.QPeIwmpzLZIktKLXAJOQHcO(), (float)n2 * (float)n, bl);
                            DataLine.Info info2 = new DataLine.Info(clazz, audioFormat);
                            if (!AudioSystem.getMixer(info).isLineSupported(info2)) continue;
                            try (DataLine dataLine = (DataLine)AudioSystem.getMixer(info).getLine(info2);){
                                dataLine.open();
                                sAVBeCYeaIWVZOjBqiIeTcH2.rHAjVyBgPhqkQKsOvJMPMYn(kFVWmcqOBgYFxPgeswapvPe);
                                sAVBeCYeaIWVZOjBqiIeTcH2.QPeIwmpzLZIktKLXAJOQHcO(n2);
                                sAVBeCYeaIWVZOjBqiIeTcH2.rHAjVyBgPhqkQKsOvJMPMYn(n);
                            }
                            catch (LineUnavailableException lineUnavailableException) {
                                // empty catch block
                            }
                        }
                    }
                }
                if (sAVBeCYeaIWVZOjBqiIeTcH2.iwitQCGCnkthNoQBBlYaPUM().isEmpty() || sAVBeCYeaIWVZOjBqiIeTcH2.JSuXbPLjXcQLpTiButqPpoI().isEmpty() || sAVBeCYeaIWVZOjBqiIeTcH2.QPeIwmpzLZIktKLXAJOQHcO().isEmpty()) continue;
                arrayList.add(sAVBeCYeaIWVZOjBqiIeTcH2);
            }
        }
        return arrayList;
    }
}

