/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.AGpEswewZOXTtopHPFqtErb;
import sdfgjkljljoftrytrszgijpokjprs.KFVWmcqOBgYFxPgeswapvPe;
import sdfgjkljljoftrytrszgijpokjprs.QPeIwmpzLZIktKLXAJOQHcO;
import sdfgjkljljoftrytrszgijpokjprs.TWPHktttPCBsYgoUXmAgKnC;
import sdfgjkljljoftrytrszgijpokjprs.YGjBevanihqaxYKnUNtrNeA;

public class GgoKTcuIevtAhezhbHlrofU
implements YGjBevanihqaxYKnUNtrNeA {
    private String rHAjVyBgPhqkQKsOvJMPMYn;
    private KFVWmcqOBgYFxPgeswapvPe QPeIwmpzLZIktKLXAJOQHcO;
    private AGpEswewZOXTtopHPFqtErb JSuXbPLjXcQLpTiButqPpoI;
    private TWPHktttPCBsYgoUXmAgKnC iwitQCGCnkthNoQBBlYaPUM;
    private long dnqxuOOQwmxxivZzrQBWydh;
    private int VZagBOcdslnIaKEkojULJvx;
    private int VmkNmvoUyyfcyaaKFyveguY;
    private int YGjBevanihqaxYKnUNtrNeA;
    private long wunjGuaHWPKejzkQKUJfPKe;
    private QPeIwmpzLZIktKLXAJOQHcO NuCoRkdmXmpraThwzNAiTcw;

    @Override
    public int rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.VmkNmvoUyyfcyaaKFyveguY;
    }

    @Override
    public KFVWmcqOBgYFxPgeswapvPe QPeIwmpzLZIktKLXAJOQHcO() {
        return this.QPeIwmpzLZIktKLXAJOQHcO;
    }

    @Override
    public int JSuXbPLjXcQLpTiButqPpoI() {
        return this.VZagBOcdslnIaKEkojULJvx;
    }

    @Override
    public int iwitQCGCnkthNoQBBlYaPUM() {
        return this.YGjBevanihqaxYKnUNtrNeA;
    }

    @Override
    public TWPHktttPCBsYgoUXmAgKnC dnqxuOOQwmxxivZzrQBWydh() {
        return this.iwitQCGCnkthNoQBBlYaPUM;
    }

    @Override
    public long VZagBOcdslnIaKEkojULJvx() {
        return this.VmkNmvoUyyfcyaaKFyveguY() / (long)this.JSuXbPLjXcQLpTiButqPpoI();
    }

    @Override
    public long VmkNmvoUyyfcyaaKFyveguY() {
        return this.dnqxuOOQwmxxivZzrQBWydh;
    }

    @Override
    public String YGjBevanihqaxYKnUNtrNeA() {
        return this.rHAjVyBgPhqkQKsOvJMPMYn;
    }

    @Override
    public int wunjGuaHWPKejzkQKUJfPKe() {
        return (int)this.wunjGuaHWPKejzkQKUJfPKe;
    }

    @Override
    public AGpEswewZOXTtopHPFqtErb NuCoRkdmXmpraThwzNAiTcw() {
        return this.JSuXbPLjXcQLpTiButqPpoI;
    }

    @Override
    public long OrmpCzNZzYDlbDZDBXyofLf() {
        return -1L;
    }

    @Override
    public long ibbBhgWhrhhiOLwDlcriPhb() {
        return -1L;
    }

    @Override
    public QPeIwmpzLZIktKLXAJOQHcO kVXnygMrAwyMajIgLatcyWS() {
        return this.NuCoRkdmXmpraThwzNAiTcw;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(QPeIwmpzLZIktKLXAJOQHcO qPeIwmpzLZIktKLXAJOQHcO) {
        this.NuCoRkdmXmpraThwzNAiTcw = qPeIwmpzLZIktKLXAJOQHcO;
    }

    void rHAjVyBgPhqkQKsOvJMPMYn(int n) {
        this.VmkNmvoUyyfcyaaKFyveguY = n;
    }

    void rHAjVyBgPhqkQKsOvJMPMYn(KFVWmcqOBgYFxPgeswapvPe kFVWmcqOBgYFxPgeswapvPe) {
        this.QPeIwmpzLZIktKLXAJOQHcO = kFVWmcqOBgYFxPgeswapvPe;
    }

    void QPeIwmpzLZIktKLXAJOQHcO(int n) {
        this.VZagBOcdslnIaKEkojULJvx = n;
    }

    void JSuXbPLjXcQLpTiButqPpoI(int n) {
        this.YGjBevanihqaxYKnUNtrNeA = n;
    }

    void rHAjVyBgPhqkQKsOvJMPMYn(TWPHktttPCBsYgoUXmAgKnC tWPHktttPCBsYgoUXmAgKnC) {
        this.iwitQCGCnkthNoQBBlYaPUM = tWPHktttPCBsYgoUXmAgKnC;
    }

    void rHAjVyBgPhqkQKsOvJMPMYn(long l) {
        this.dnqxuOOQwmxxivZzrQBWydh = l;
    }

    void QPeIwmpzLZIktKLXAJOQHcO(long l) {
        this.wunjGuaHWPKejzkQKUJfPKe = l;
    }

    void rHAjVyBgPhqkQKsOvJMPMYn(AGpEswewZOXTtopHPFqtErb aGpEswewZOXTtopHPFqtErb) {
        this.JSuXbPLjXcQLpTiButqPpoI = aGpEswewZOXTtopHPFqtErb;
    }
}

