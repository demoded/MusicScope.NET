/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.util.Arrays;
import sdfgjkljljoftrytrszgijpokjprs.AGpEswewZOXTtopHPFqtErb;
import sdfgjkljljoftrytrszgijpokjprs.KFVWmcqOBgYFxPgeswapvPe;
import sdfgjkljljoftrytrszgijpokjprs.QPeIwmpzLZIktKLXAJOQHcO;
import sdfgjkljljoftrytrszgijpokjprs.TWPHktttPCBsYgoUXmAgKnC;
import sdfgjkljljoftrytrszgijpokjprs.YGjBevanihqaxYKnUNtrNeA;
import sdfgjkljljoftrytrszgijpokjprs.cdSECoXyrascmeWiUkiBTmK;

public class FoVkhFqKjpvomrYQnnVFKwY
implements YGjBevanihqaxYKnUNtrNeA {
    private static final char[] rHAjVyBgPhqkQKsOvJMPMYn = new char[]{'s', 'o', 'w', 't'};
    private final cdSECoXyrascmeWiUkiBTmK QPeIwmpzLZIktKLXAJOQHcO;
    private final TWPHktttPCBsYgoUXmAgKnC JSuXbPLjXcQLpTiButqPpoI;
    private final long iwitQCGCnkthNoQBBlYaPUM;
    private final long dnqxuOOQwmxxivZzrQBWydh;
    private QPeIwmpzLZIktKLXAJOQHcO VZagBOcdslnIaKEkojULJvx;

    public FoVkhFqKjpvomrYQnnVFKwY(cdSECoXyrascmeWiUkiBTmK cdSECoXyrascmeWiUkiBTmK2, long l, long l2) {
        this.QPeIwmpzLZIktKLXAJOQHcO = cdSECoXyrascmeWiUkiBTmK2;
        this.iwitQCGCnkthNoQBBlYaPUM = l;
        this.dnqxuOOQwmxxivZzrQBWydh = l2;
        this.VZagBOcdslnIaKEkojULJvx = null;
        switch (cdSECoXyrascmeWiUkiBTmK2.iwitQCGCnkthNoQBBlYaPUM()[3]) {
            case 'F': {
                this.JSuXbPLjXcQLpTiButqPpoI = TWPHktttPCBsYgoUXmAgKnC.rHAjVyBgPhqkQKsOvJMPMYn;
                break;
            }
            case 'C': {
                this.JSuXbPLjXcQLpTiButqPpoI = TWPHktttPCBsYgoUXmAgKnC.QPeIwmpzLZIktKLXAJOQHcO;
                break;
            }
            default: {
                this.JSuXbPLjXcQLpTiButqPpoI = TWPHktttPCBsYgoUXmAgKnC.JSuXbPLjXcQLpTiButqPpoI;
            }
        }
    }

    @Override
    public int rHAjVyBgPhqkQKsOvJMPMYn() {
        return (int)this.QPeIwmpzLZIktKLXAJOQHcO.dnqxuOOQwmxxivZzrQBWydh().VmkNmvoUyyfcyaaKFyveguY();
    }

    @Override
    public KFVWmcqOBgYFxPgeswapvPe QPeIwmpzLZIktKLXAJOQHcO() {
        return KFVWmcqOBgYFxPgeswapvPe.QPeIwmpzLZIktKLXAJOQHcO(this.QPeIwmpzLZIktKLXAJOQHcO.dnqxuOOQwmxxivZzrQBWydh().VZagBOcdslnIaKEkojULJvx());
    }

    @Override
    public int JSuXbPLjXcQLpTiButqPpoI() {
        return this.iwitQCGCnkthNoQBBlYaPUM() * this.QPeIwmpzLZIktKLXAJOQHcO().QPeIwmpzLZIktKLXAJOQHcO() * this.rHAjVyBgPhqkQKsOvJMPMYn();
    }

    @Override
    public int iwitQCGCnkthNoQBBlYaPUM() {
        return this.QPeIwmpzLZIktKLXAJOQHcO.dnqxuOOQwmxxivZzrQBWydh().iwitQCGCnkthNoQBBlYaPUM();
    }

    @Override
    public TWPHktttPCBsYgoUXmAgKnC dnqxuOOQwmxxivZzrQBWydh() {
        return this.JSuXbPLjXcQLpTiButqPpoI;
    }

    @Override
    public long VZagBOcdslnIaKEkojULJvx() {
        return this.VmkNmvoUyyfcyaaKFyveguY() / (long)this.JSuXbPLjXcQLpTiButqPpoI();
    }

    @Override
    public long VmkNmvoUyyfcyaaKFyveguY() {
        return this.QPeIwmpzLZIktKLXAJOQHcO.dnqxuOOQwmxxivZzrQBWydh().dnqxuOOQwmxxivZzrQBWydh() * this.QPeIwmpzLZIktKLXAJOQHcO().QPeIwmpzLZIktKLXAJOQHcO() * this.iwitQCGCnkthNoQBBlYaPUM();
    }

    @Override
    public String YGjBevanihqaxYKnUNtrNeA() {
        return "No Name";
    }

    @Override
    public int wunjGuaHWPKejzkQKUJfPKe() {
        return this.QPeIwmpzLZIktKLXAJOQHcO.VZagBOcdslnIaKEkojULJvx().dnqxuOOQwmxxivZzrQBWydh();
    }

    @Override
    public AGpEswewZOXTtopHPFqtErb NuCoRkdmXmpraThwzNAiTcw() {
        return AGpEswewZOXTtopHPFqtErb.wunjGuaHWPKejzkQKUJfPKe;
    }

    @Override
    public long OrmpCzNZzYDlbDZDBXyofLf() {
        return this.iwitQCGCnkthNoQBBlYaPUM;
    }

    @Override
    public long ibbBhgWhrhhiOLwDlcriPhb() {
        return this.dnqxuOOQwmxxivZzrQBWydh;
    }

    @Override
    public QPeIwmpzLZIktKLXAJOQHcO kVXnygMrAwyMajIgLatcyWS() {
        return this.VZagBOcdslnIaKEkojULJvx;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(QPeIwmpzLZIktKLXAJOQHcO qPeIwmpzLZIktKLXAJOQHcO) {
        this.VZagBOcdslnIaKEkojULJvx = qPeIwmpzLZIktKLXAJOQHcO;
    }

    public boolean vJgxuXjYdOvTUFZsFThavLL() {
        String string = Arrays.toString(this.QPeIwmpzLZIktKLXAJOQHcO.dnqxuOOQwmxxivZzrQBWydh().YGjBevanihqaxYKnUNtrNeA());
        String string2 = Arrays.toString(rHAjVyBgPhqkQKsOvJMPMYn);
        return string.equals(string2);
    }
}

