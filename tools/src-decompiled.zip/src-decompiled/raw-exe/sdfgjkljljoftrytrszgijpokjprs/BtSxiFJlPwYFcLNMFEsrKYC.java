/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import sdfgjkljljoftrytrszgijpokjprs.CbBsidOPrITWbOsdPkAmBWy;
import sdfgjkljljoftrytrszgijpokjprs.FWVSYwHLXQCcyAFBrRLKUjC;
import sdfgjkljljoftrytrszgijpokjprs.LdKUnSiKdszJzeZHYwovYXQ;
import sdfgjkljljoftrytrszgijpokjprs.LmpMbGiKePIaCNVnzKLRpFv;
import sdfgjkljljoftrytrszgijpokjprs.RvmLMdDLEGHIAejiawKxuPa;
import sdfgjkljljoftrytrszgijpokjprs.YGjBevanihqaxYKnUNtrNeA;
import sdfgjkljljoftrytrszgijpokjprs.YzXXpcCCVJkKMcoHoACbjGG;
import sdfgjkljljoftrytrszgijpokjprs.ivncmIpiNjIzzGkIkGWOXBB;
import sdfgjkljljoftrytrszgijpokjprs.iyaWEDVCWijrKBfHtkYptbR;
import sdfgjkljljoftrytrszgijpokjprs.kMqExmRlFLPTFqBDauCBKYL;
import sdfgjkljljoftrytrszgijpokjprs.kfrVEsKUvFeBfAoSkvCCRmV;
import sdfgjkljljoftrytrszgijpokjprs.rCmoWORuZTuTJLPUdPgkRnn;
import sdfgjkljljoftrytrszgijpokjprs.tJuPpiiZKFnZdtTTOrwfbxj;
import sdfgjkljljoftrytrszgijpokjprs.tSwCDjQKHwQVvbvetpZIATg;
import sdfgjkljljoftrytrszgijpokjprs.uWXqjVSzMiSlRMFaxTZuKKS;
import sdfgjkljljoftrytrszgijpokjprs.vJgxuXjYdOvTUFZsFThavLL;

public class BtSxiFJlPwYFcLNMFEsrKYC
implements DropTargetListener,
CbBsidOPrITWbOsdPkAmBWy<rHAjVyBgPhqkQKsOvJMPMYn>,
FWVSYwHLXQCcyAFBrRLKUjC,
RvmLMdDLEGHIAejiawKxuPa<rHAjVyBgPhqkQKsOvJMPMYn> {
    private final LmpMbGiKePIaCNVnzKLRpFv<rHAjVyBgPhqkQKsOvJMPMYn> rHAjVyBgPhqkQKsOvJMPMYn;
    private final rCmoWORuZTuTJLPUdPgkRnn QPeIwmpzLZIktKLXAJOQHcO;
    private final tSwCDjQKHwQVvbvetpZIATg JSuXbPLjXcQLpTiButqPpoI;
    private final sdfgjkljljoftrytrszgijpokjprs.rHAjVyBgPhqkQKsOvJMPMYn iwitQCGCnkthNoQBBlYaPUM;
    private ArrayList<rHAjVyBgPhqkQKsOvJMPMYn> dnqxuOOQwmxxivZzrQBWydh;
    private boolean VZagBOcdslnIaKEkojULJvx = true;

    public BtSxiFJlPwYFcLNMFEsrKYC(tSwCDjQKHwQVvbvetpZIATg tSwCDjQKHwQVvbvetpZIATg2) {
        this.JSuXbPLjXcQLpTiButqPpoI = tSwCDjQKHwQVvbvetpZIATg2;
        this.iwitQCGCnkthNoQBBlYaPUM = new sdfgjkljljoftrytrszgijpokjprs.rHAjVyBgPhqkQKsOvJMPMYn(new ivncmIpiNjIzzGkIkGWOXBB(), new vJgxuXjYdOvTUFZsFThavLL(), new LdKUnSiKdszJzeZHYwovYXQ(), new uWXqjVSzMiSlRMFaxTZuKKS(), new iyaWEDVCWijrKBfHtkYptbR(), new kMqExmRlFLPTFqBDauCBKYL(), new tJuPpiiZKFnZdtTTOrwfbxj(352800));
        this.QPeIwmpzLZIktKLXAJOQHcO = new rCmoWORuZTuTJLPUdPgkRnn(null, true);
        this.rHAjVyBgPhqkQKsOvJMPMYn = new LmpMbGiKePIaCNVnzKLRpFv<rHAjVyBgPhqkQKsOvJMPMYn>(this, this.QPeIwmpzLZIktKLXAJOQHcO);
        this.QPeIwmpzLZIktKLXAJOQHcO.rHAjVyBgPhqkQKsOvJMPMYn(this.rHAjVyBgPhqkQKsOvJMPMYn);
        this.dnqxuOOQwmxxivZzrQBWydh = new ArrayList(0);
        this.JSuXbPLjXcQLpTiButqPpoI();
    }

    private void JSuXbPLjXcQLpTiButqPpoI() {
        this.rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn(this);
    }

    @Override
    public void dragEnter(DropTargetDragEvent dropTargetDragEvent) {
    }

    @Override
    public void dragOver(DropTargetDragEvent dropTargetDragEvent) {
        if (!YzXXpcCCVJkKMcoHoACbjGG.JSuXbPLjXcQLpTiButqPpoI()) {
            block7: {
                if (!this.VZagBOcdslnIaKEkojULJvx) {
                    dropTargetDragEvent.rejectDrag();
                }
                dropTargetDragEvent.acceptDrag(0x40000000);
                Transferable transferable = dropTargetDragEvent.getTransferable();
                if (dropTargetDragEvent.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
                    try {
                        List list = (List)transferable.getTransferData(DataFlavor.javaFileListFlavor);
                        if (!(list instanceof List)) break block7;
                        if (list.size() == 1) {
                            for (Object e : list) {
                                if (!(e instanceof File)) continue;
                                return;
                            }
                            break block7;
                        }
                        return;
                    }
                    catch (UnsupportedFlavorException | IOException exception) {
                        // empty catch block
                    }
                }
            }
            dropTargetDragEvent.rejectDrag();
        }
    }

    @Override
    public void dropActionChanged(DropTargetDragEvent dropTargetDragEvent) {
    }

    @Override
    public void dragExit(DropTargetEvent dropTargetEvent) {
    }

    @Override
    public void drop(DropTargetDropEvent dropTargetDropEvent) {
        dropTargetDropEvent.acceptDrop(2);
        Transferable transferable = dropTargetDropEvent.getTransferable();
        if (dropTargetDropEvent.isDataFlavorSupported(DataFlavor.javaFileListFlavor) && this.VZagBOcdslnIaKEkojULJvx) {
            try {
                List list = (List)transferable.getTransferData(DataFlavor.javaFileListFlavor);
                if (list instanceof List && list.size() > 0) {
                    for (Object e : list) {
                        if (!(e instanceof File)) continue;
                        this.rHAjVyBgPhqkQKsOvJMPMYn((File)e);
                    }
                }
            }
            catch (UnsupportedFlavorException | IOException exception) {
                // empty catch block
            }
        }
        this.rHAjVyBgPhqkQKsOvJMPMYn();
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn() {
        this.dnqxuOOQwmxxivZzrQBWydh.clear();
        this.rHAjVyBgPhqkQKsOvJMPMYn.JSuXbPLjXcQLpTiButqPpoI().QPeIwmpzLZIktKLXAJOQHcO();
        this.rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn();
    }

    @Override
    public void rHAjVyBgPhqkQKsOvJMPMYn(File file) {
        this.rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn(file, true, this);
    }

    @Override
    public synchronized void rHAjVyBgPhqkQKsOvJMPMYn(rHAjVyBgPhqkQKsOvJMPMYn rHAjVyBgPhqkQKsOvJMPMYn2) {
        if (rHAjVyBgPhqkQKsOvJMPMYn2.rHAjVyBgPhqkQKsOvJMPMYn() != null) {
            this.dnqxuOOQwmxxivZzrQBWydh.add(rHAjVyBgPhqkQKsOvJMPMYn2);
        }
    }

    public synchronized rHAjVyBgPhqkQKsOvJMPMYn rHAjVyBgPhqkQKsOvJMPMYn(File file, Path path) throws Exception {
        rHAjVyBgPhqkQKsOvJMPMYn rHAjVyBgPhqkQKsOvJMPMYn2 = null;
        if (this.iwitQCGCnkthNoQBBlYaPUM.rHAjVyBgPhqkQKsOvJMPMYn(file.getAbsolutePath())) {
            rHAjVyBgPhqkQKsOvJMPMYn2 = new rHAjVyBgPhqkQKsOvJMPMYn(file, this.iwitQCGCnkthNoQBBlYaPUM.QPeIwmpzLZIktKLXAJOQHcO());
        }
        this.iwitQCGCnkthNoQBBlYaPUM.iwitQCGCnkthNoQBBlYaPUM();
        return rHAjVyBgPhqkQKsOvJMPMYn2;
    }

    @Override
    public void QPeIwmpzLZIktKLXAJOQHcO() {
        kfrVEsKUvFeBfAoSkvCCRmV kfrVEsKUvFeBfAoSkvCCRmV2 = kfrVEsKUvFeBfAoSkvCCRmV.rHAjVyBgPhqkQKsOvJMPMYn();
        for (rHAjVyBgPhqkQKsOvJMPMYn rHAjVyBgPhqkQKsOvJMPMYn2 : this.dnqxuOOQwmxxivZzrQBWydh) {
            if (this.JSuXbPLjXcQLpTiButqPpoI == null || kfrVEsKUvFeBfAoSkvCCRmV2.QPeIwmpzLZIktKLXAJOQHcO() || this.dnqxuOOQwmxxivZzrQBWydh.size() > 1) {
                kfrVEsKUvFeBfAoSkvCCRmV2.rHAjVyBgPhqkQKsOvJMPMYn(rHAjVyBgPhqkQKsOvJMPMYn2.rHAjVyBgPhqkQKsOvJMPMYn().getAbsolutePath(), rHAjVyBgPhqkQKsOvJMPMYn2.QPeIwmpzLZIktKLXAJOQHcO());
                kfrVEsKUvFeBfAoSkvCCRmV2.rHAjVyBgPhqkQKsOvJMPMYn(true);
                continue;
            }
            if (this.JSuXbPLjXcQLpTiButqPpoI == null) continue;
            this.JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(rHAjVyBgPhqkQKsOvJMPMYn2.rHAjVyBgPhqkQKsOvJMPMYn().getAbsolutePath());
        }
    }

    @Override
    public /* synthetic */ Object QPeIwmpzLZIktKLXAJOQHcO(File file, Path path) throws Exception {
        return this.rHAjVyBgPhqkQKsOvJMPMYn(file, path);
    }

    public static class rHAjVyBgPhqkQKsOvJMPMYn {
        private final File rHAjVyBgPhqkQKsOvJMPMYn;
        private final YGjBevanihqaxYKnUNtrNeA QPeIwmpzLZIktKLXAJOQHcO;

        public rHAjVyBgPhqkQKsOvJMPMYn(File file, YGjBevanihqaxYKnUNtrNeA yGjBevanihqaxYKnUNtrNeA) {
            this.rHAjVyBgPhqkQKsOvJMPMYn = file;
            this.QPeIwmpzLZIktKLXAJOQHcO = yGjBevanihqaxYKnUNtrNeA;
        }

        public File rHAjVyBgPhqkQKsOvJMPMYn() {
            return this.rHAjVyBgPhqkQKsOvJMPMYn;
        }

        public YGjBevanihqaxYKnUNtrNeA QPeIwmpzLZIktKLXAJOQHcO() {
            return this.QPeIwmpzLZIktKLXAJOQHcO;
        }
    }
}

