/*
 * Decompiled with CFR 0.152.
 */
package sdfgjkljljoftrytrszgijpokjprs;

import sdfgjkljljoftrytrszgijpokjprs.EXSUIhRmsvLMQreaJLDBbPg;
import sdfgjkljljoftrytrszgijpokjprs.jpSvGdIXyBXOcuLxzsPHYvF;
import sdfgjkljljoftrytrszgijpokjprs.rEiSHsgrayAGGxHhOvuGszw;
import sdfgjkljljoftrytrszgijpokjprs.rsjBvjhMVBmGgchpwDGNghi;
import sdfgjkljljoftrytrszgijpokjprs.sucWfqvlWCrLCiRWZENgaNt;
import sdfgjkljljoftrytrszgijpokjprs.tgEnMDWUChukKDvHjnBDvdF;

public class cIaNgIszMXSoKdZbRGCiSuk
extends rsjBvjhMVBmGgchpwDGNghi<EXSUIhRmsvLMQreaJLDBbPg, sucWfqvlWCrLCiRWZENgaNt> {
    public cIaNgIszMXSoKdZbRGCiSuk() {
        super(EXSUIhRmsvLMQreaJLDBbPg.class, sucWfqvlWCrLCiRWZENgaNt.class);
        this.rHAjVyBgPhqkQKsOvJMPMYn(jpSvGdIXyBXOcuLxzsPHYvF.class);
        this.rHAjVyBgPhqkQKsOvJMPMYn(tgEnMDWUChukKDvHjnBDvdF.class);
        this.rHAjVyBgPhqkQKsOvJMPMYn(rEiSHsgrayAGGxHhOvuGszw.class);
    }
}

