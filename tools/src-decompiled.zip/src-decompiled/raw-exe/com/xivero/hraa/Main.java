/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.io.Files
 *  com.xivero.appleHandler.IHandlerCallback
 *  com.xivero.appleHandler.IPlugin
 */
package com.xivero.hraa;

import com.google.common.io.Files;
import com.xivero.appleHandler.IHandlerCallback;
import com.xivero.appleHandler.IPlugin;
import com.xivero.hraa.gui.frame.rHAjVyBgPhqkQKsOvJMPMYn;
import java.awt.Frame;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Path;
import java.util.logging.Level;
import java.util.logging.Logger;
import sdfgjkljljoftrytrszgijpokjprs.AkjxEminiBQvbUdaGZgkyhV;
import sdfgjkljljoftrytrszgijpokjprs.BtSxiFJlPwYFcLNMFEsrKYC;
import sdfgjkljljoftrytrszgijpokjprs.FiypGaFYdzscEBybnfTNrMU;
import sdfgjkljljoftrytrszgijpokjprs.GGiRamzaArNdRQDukShvdNU;
import sdfgjkljljoftrytrszgijpokjprs.GUmcHlGuXLMlTCxtghDBJCl;
import sdfgjkljljoftrytrszgijpokjprs.HwBMoAdDdYXRPcGrNGRitQy;
import sdfgjkljljoftrytrszgijpokjprs.IpeEJbKSCPCYelngcqwUQgF;
import sdfgjkljljoftrytrszgijpokjprs.LRWbrwPJNJMrzLYayAJxsLY;
import sdfgjkljljoftrytrszgijpokjprs.NCABabPjyneGQZVXMqQJJlz;
import sdfgjkljljoftrytrszgijpokjprs.PPgRJjTGmnzzThoJZeKmfut;
import sdfgjkljljoftrytrszgijpokjprs.TSILPPfdcnHrmGfZNXMsPlw;
import sdfgjkljljoftrytrszgijpokjprs.UxNrRnaNgSMFamtqcmJwDwX;
import sdfgjkljljoftrytrszgijpokjprs.XZEXahJHCGCBNASefxRYhTY;
import sdfgjkljljoftrytrszgijpokjprs.XwHjOhsVogzdybpQXdaEGrM;
import sdfgjkljljoftrytrszgijpokjprs.YSgTJHtByEvxQOwRrfoYYZX;
import sdfgjkljljoftrytrszgijpokjprs.YzXXpcCCVJkKMcoHoACbjGG;
import sdfgjkljljoftrytrszgijpokjprs.ZjoyaRSokkGYDwXHPKTBIiX;
import sdfgjkljljoftrytrszgijpokjprs.cJizbPrgAISXyzXrgujHPeB;
import sdfgjkljljoftrytrszgijpokjprs.hdtwbvZSeJsEBjhsjhkgMoS;
import sdfgjkljljoftrytrszgijpokjprs.kTbZASHDopQBPRkAiVONWbv;
import sdfgjkljljoftrytrszgijpokjprs.kfrVEsKUvFeBfAoSkvCCRmV;
import sdfgjkljljoftrytrszgijpokjprs.lXCOGwZXVelwEKHMMPwpSAO;
import sdfgjkljljoftrytrszgijpokjprs.lwCwsaOnEEwXwbudVVNfhyz;
import sdfgjkljljoftrytrszgijpokjprs.miBFKRJVXkTtMTMpbtygQBp;
import sdfgjkljljoftrytrszgijpokjprs.mkMdhMdKzFSfOwGBSnmEzOe;
import sdfgjkljljoftrytrszgijpokjprs.mngrlCdeCRXqNKRFkqnJvFt;
import sdfgjkljljoftrytrszgijpokjprs.nkSLFlumvAIqqGMcVFgItWJ;
import sdfgjkljljoftrytrszgijpokjprs.ntMSlcredseGwvbyesPSAQf;
import sdfgjkljljoftrytrszgijpokjprs.nyfwxCZoaPuQlzOUeBNsFaO;
import sdfgjkljljoftrytrszgijpokjprs.qAPYmrSBwvJMqiHvTVjYfvo;
import sdfgjkljljoftrytrszgijpokjprs.rVznADxHDiUGKUcgCFACfzg;
import sdfgjkljljoftrytrszgijpokjprs.rqQjEReeYEfXFwAZlPAcXvt;
import sdfgjkljljoftrytrszgijpokjprs.sLuwRITuDanyEuFWGUJWQqQ;
import sdfgjkljljoftrytrszgijpokjprs.uRfbqkKHjLdhIvxtcBLiaka;

public class Main {
    public static final kTbZASHDopQBPRkAiVONWbv rHAjVyBgPhqkQKsOvJMPMYn;
    private static boolean QPeIwmpzLZIktKLXAJOQHcO;
    private static PPgRJjTGmnzzThoJZeKmfut JSuXbPLjXcQLpTiButqPpoI;
    private static BtSxiFJlPwYFcLNMFEsrKYC iwitQCGCnkthNoQBBlYaPUM;
    private static rHAjVyBgPhqkQKsOvJMPMYn dnqxuOOQwmxxivZzrQBWydh;
    private static final lwCwsaOnEEwXwbudVVNfhyz VZagBOcdslnIaKEkojULJvx;
    private static final XwHjOhsVogzdybpQXdaEGrM VmkNmvoUyyfcyaaKFyveguY;
    private static final AkjxEminiBQvbUdaGZgkyhV YGjBevanihqaxYKnUNtrNeA;
    private static final FiypGaFYdzscEBybnfTNrMU wunjGuaHWPKejzkQKUJfPKe;
    private static final HwBMoAdDdYXRPcGrNGRitQy NuCoRkdmXmpraThwzNAiTcw;
    private static final mkMdhMdKzFSfOwGBSnmEzOe OrmpCzNZzYDlbDZDBXyofLf;
    private static Path ibbBhgWhrhhiOLwDlcriPhb;

    public static void main(String[] stringArray) throws IOException {
        stringArray.clone();
        if (YzXXpcCCVJkKMcoHoACbjGG.JSuXbPLjXcQLpTiButqPpoI()) {
            try {
                File file = new File("lib/AppleAbout.jar");
                URL[] uRLArray = new URL[]{file.toURI().toURL()};
                URLClassLoader uRLClassLoader = URLClassLoader.newInstance(uRLArray);
                Class<?> clazz = uRLClassLoader.loadClass("com.xivero.appleHandler.HandlerPlugin");
                IPlugin iPlugin = (IPlugin)clazz.newInstance();
                iPlugin.addHandler(new IHandlerCallback(){

                    public void aboutHandlerCall() {
                        dnqxuOOQwmxxivZzrQBWydh.OrmpCzNZzYDlbDZDBXyofLf().setVisible(true);
                    }
                });
            }
            catch (ClassNotFoundException | IllegalAccessException | InstantiationException | MalformedURLException exception) {
                // empty catch block
            }
        }
        Main.rHAjVyBgPhqkQKsOvJMPMYn(new String[0]);
        dnqxuOOQwmxxivZzrQBWydh.uAGKHXCiDSbltWOPIpXUgwC();
    }

    public static void rHAjVyBgPhqkQKsOvJMPMYn(String ... stringArray) {
        if (stringArray != null && stringArray.length > 0) {
            stringArray.clone();
        }
        dnqxuOOQwmxxivZzrQBWydh = new rHAjVyBgPhqkQKsOvJMPMYn();
        YSgTJHtByEvxQOwRrfoYYZX.rHAjVyBgPhqkQKsOvJMPMYn();
        rqQjEReeYEfXFwAZlPAcXvt.rHAjVyBgPhqkQKsOvJMPMYn();
        JSuXbPLjXcQLpTiButqPpoI = PPgRJjTGmnzzThoJZeKmfut.VZagBOcdslnIaKEkojULJvx();
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(dnqxuOOQwmxxivZzrQBWydh.FoVkhFqKjpvomrYQnnVFKwY());
        iwitQCGCnkthNoQBBlYaPUM = new BtSxiFJlPwYFcLNMFEsrKYC(JSuXbPLjXcQLpTiButqPpoI);
        mngrlCdeCRXqNKRFkqnJvFt.rHAjVyBgPhqkQKsOvJMPMYn().rHAjVyBgPhqkQKsOvJMPMYn(JSuXbPLjXcQLpTiButqPpoI);
        kfrVEsKUvFeBfAoSkvCCRmV kfrVEsKUvFeBfAoSkvCCRmV2 = kfrVEsKUvFeBfAoSkvCCRmV.rHAjVyBgPhqkQKsOvJMPMYn();
        kfrVEsKUvFeBfAoSkvCCRmV2.rHAjVyBgPhqkQKsOvJMPMYn(JSuXbPLjXcQLpTiButqPpoI);
        dnqxuOOQwmxxivZzrQBWydh.rHAjVyBgPhqkQKsOvJMPMYn(iwitQCGCnkthNoQBBlYaPUM);
        dnqxuOOQwmxxivZzrQBWydh.rHAjVyBgPhqkQKsOvJMPMYn(JSuXbPLjXcQLpTiButqPpoI);
        GGiRamzaArNdRQDukShvdNU gGiRamzaArNdRQDukShvdNU = dnqxuOOQwmxxivZzrQBWydh.rHAjVyBgPhqkQKsOvJMPMYn();
        gGiRamzaArNdRQDukShvdNU.rHAjVyBgPhqkQKsOvJMPMYn(JSuXbPLjXcQLpTiButqPpoI);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(gGiRamzaArNdRQDukShvdNU, ZjoyaRSokkGYDwXHPKTBIiX.values());
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(gGiRamzaArNdRQDukShvdNU);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(dnqxuOOQwmxxivZzrQBWydh.kVXnygMrAwyMajIgLatcyWS());
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(dnqxuOOQwmxxivZzrQBWydh.vJgxuXjYdOvTUFZsFThavLL());
        ntMSlcredseGwvbyesPSAQf ntMSlcredseGwvbyesPSAQf2 = dnqxuOOQwmxxivZzrQBWydh.QPeIwmpzLZIktKLXAJOQHcO();
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(ntMSlcredseGwvbyesPSAQf2, cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn.iwitQCGCnkthNoQBBlYaPUM);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(ntMSlcredseGwvbyesPSAQf2);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(ntMSlcredseGwvbyesPSAQf2, ZjoyaRSokkGYDwXHPKTBIiX.values());
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(ntMSlcredseGwvbyesPSAQf2, lXCOGwZXVelwEKHMMPwpSAO.dnqxuOOQwmxxivZzrQBWydh);
        nyfwxCZoaPuQlzOUeBNsFaO nyfwxCZoaPuQlzOUeBNsFaO2 = dnqxuOOQwmxxivZzrQBWydh.NuCoRkdmXmpraThwzNAiTcw();
        kfrVEsKUvFeBfAoSkvCCRmV2.rHAjVyBgPhqkQKsOvJMPMYn(nyfwxCZoaPuQlzOUeBNsFaO2);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(nyfwxCZoaPuQlzOUeBNsFaO2);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(nyfwxCZoaPuQlzOUeBNsFaO2, lXCOGwZXVelwEKHMMPwpSAO.values());
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(nyfwxCZoaPuQlzOUeBNsFaO2, ZjoyaRSokkGYDwXHPKTBIiX.values());
        IpeEJbKSCPCYelngcqwUQgF ipeEJbKSCPCYelngcqwUQgF = dnqxuOOQwmxxivZzrQBWydh.JSuXbPLjXcQLpTiButqPpoI();
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(ipeEJbKSCPCYelngcqwUQgF, cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn.dnqxuOOQwmxxivZzrQBWydh);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(ipeEJbKSCPCYelngcqwUQgF);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(ipeEJbKSCPCYelngcqwUQgF, ZjoyaRSokkGYDwXHPKTBIiX.values());
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(ipeEJbKSCPCYelngcqwUQgF, lXCOGwZXVelwEKHMMPwpSAO.dnqxuOOQwmxxivZzrQBWydh);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(ipeEJbKSCPCYelngcqwUQgF);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(ipeEJbKSCPCYelngcqwUQgF);
        NCABabPjyneGQZVXMqQJJlz nCABabPjyneGQZVXMqQJJlz = dnqxuOOQwmxxivZzrQBWydh.iwitQCGCnkthNoQBBlYaPUM();
        nCABabPjyneGQZVXMqQJJlz.rHAjVyBgPhqkQKsOvJMPMYn(JSuXbPLjXcQLpTiButqPpoI.YGjBevanihqaxYKnUNtrNeA());
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(nCABabPjyneGQZVXMqQJJlz, cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(nCABabPjyneGQZVXMqQJJlz);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(nCABabPjyneGQZVXMqQJJlz);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(nCABabPjyneGQZVXMqQJJlz, ZjoyaRSokkGYDwXHPKTBIiX.values());
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(nCABabPjyneGQZVXMqQJJlz, lXCOGwZXVelwEKHMMPwpSAO.dnqxuOOQwmxxivZzrQBWydh);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(nCABabPjyneGQZVXMqQJJlz);
        miBFKRJVXkTtMTMpbtygQBp miBFKRJVXkTtMTMpbtygQBp2 = dnqxuOOQwmxxivZzrQBWydh.dnqxuOOQwmxxivZzrQBWydh();
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(miBFKRJVXkTtMTMpbtygQBp2, cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn, cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn.VmkNmvoUyyfcyaaKFyveguY);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(miBFKRJVXkTtMTMpbtygQBp2);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(miBFKRJVXkTtMTMpbtygQBp2);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(miBFKRJVXkTtMTMpbtygQBp2, ZjoyaRSokkGYDwXHPKTBIiX.values());
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(miBFKRJVXkTtMTMpbtygQBp2, lXCOGwZXVelwEKHMMPwpSAO.values());
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(miBFKRJVXkTtMTMpbtygQBp2);
        TSILPPfdcnHrmGfZNXMsPlw tSILPPfdcnHrmGfZNXMsPlw = dnqxuOOQwmxxivZzrQBWydh.VmkNmvoUyyfcyaaKFyveguY();
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(tSILPPfdcnHrmGfZNXMsPlw, cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn.dnqxuOOQwmxxivZzrQBWydh, cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn.VmkNmvoUyyfcyaaKFyveguY);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(tSILPPfdcnHrmGfZNXMsPlw);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(tSILPPfdcnHrmGfZNXMsPlw, ZjoyaRSokkGYDwXHPKTBIiX.values());
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(tSILPPfdcnHrmGfZNXMsPlw, lXCOGwZXVelwEKHMMPwpSAO.VZagBOcdslnIaKEkojULJvx, lXCOGwZXVelwEKHMMPwpSAO.dnqxuOOQwmxxivZzrQBWydh);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(tSILPPfdcnHrmGfZNXMsPlw);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(tSILPPfdcnHrmGfZNXMsPlw);
        XZEXahJHCGCBNASefxRYhTY xZEXahJHCGCBNASefxRYhTY = dnqxuOOQwmxxivZzrQBWydh.VZagBOcdslnIaKEkojULJvx();
        xZEXahJHCGCBNASefxRYhTY.addMouseListener(xZEXahJHCGCBNASefxRYhTY);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(xZEXahJHCGCBNASefxRYhTY);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(xZEXahJHCGCBNASefxRYhTY, ZjoyaRSokkGYDwXHPKTBIiX.rHAjVyBgPhqkQKsOvJMPMYn);
        uRfbqkKHjLdhIvxtcBLiaka uRfbqkKHjLdhIvxtcBLiaka2 = dnqxuOOQwmxxivZzrQBWydh.YGjBevanihqaxYKnUNtrNeA();
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(uRfbqkKHjLdhIvxtcBLiaka2);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(uRfbqkKHjLdhIvxtcBLiaka2, cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn.dnqxuOOQwmxxivZzrQBWydh);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(uRfbqkKHjLdhIvxtcBLiaka2);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(uRfbqkKHjLdhIvxtcBLiaka2, ZjoyaRSokkGYDwXHPKTBIiX.values());
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(uRfbqkKHjLdhIvxtcBLiaka2, lXCOGwZXVelwEKHMMPwpSAO.dnqxuOOQwmxxivZzrQBWydh);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(uRfbqkKHjLdhIvxtcBLiaka2);
        uRfbqkKHjLdhIvxtcBLiaka2.addMouseListener(uRfbqkKHjLdhIvxtcBLiaka2);
        uRfbqkKHjLdhIvxtcBLiaka2.addMouseMotionListener(uRfbqkKHjLdhIvxtcBLiaka2);
        rVznADxHDiUGKUcgCFACfzg rVznADxHDiUGKUcgCFACfzg2 = dnqxuOOQwmxxivZzrQBWydh.wunjGuaHWPKejzkQKUJfPKe();
        rVznADxHDiUGKUcgCFACfzg2.rHAjVyBgPhqkQKsOvJMPMYn(JSuXbPLjXcQLpTiButqPpoI);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(rVznADxHDiUGKUcgCFACfzg2, cJizbPrgAISXyzXrgujHPeB.rHAjVyBgPhqkQKsOvJMPMYn.dnqxuOOQwmxxivZzrQBWydh);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(rVznADxHDiUGKUcgCFACfzg2);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(rVznADxHDiUGKUcgCFACfzg2);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(rVznADxHDiUGKUcgCFACfzg2);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(rVznADxHDiUGKUcgCFACfzg2, ZjoyaRSokkGYDwXHPKTBIiX.values());
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(rVznADxHDiUGKUcgCFACfzg2, lXCOGwZXVelwEKHMMPwpSAO.VZagBOcdslnIaKEkojULJvx, lXCOGwZXVelwEKHMMPwpSAO.dnqxuOOQwmxxivZzrQBWydh);
        nkSLFlumvAIqqGMcVFgItWJ nkSLFlumvAIqqGMcVFgItWJ2 = dnqxuOOQwmxxivZzrQBWydh.ibbBhgWhrhhiOLwDlcriPhb();
        nkSLFlumvAIqqGMcVFgItWJ2.rHAjVyBgPhqkQKsOvJMPMYn(JSuXbPLjXcQLpTiButqPpoI);
        LRWbrwPJNJMrzLYayAJxsLY lRWbrwPJNJMrzLYayAJxsLY = dnqxuOOQwmxxivZzrQBWydh.kMqExmRlFLPTFqBDauCBKYL();
        lRWbrwPJNJMrzLYayAJxsLY.rHAjVyBgPhqkQKsOvJMPMYn(tSILPPfdcnHrmGfZNXMsPlw);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(VZagBOcdslnIaKEkojULJvx);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(VZagBOcdslnIaKEkojULJvx);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(VmkNmvoUyyfcyaaKFyveguY);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(VmkNmvoUyyfcyaaKFyveguY);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(YGjBevanihqaxYKnUNtrNeA);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(YGjBevanihqaxYKnUNtrNeA);
        nCABabPjyneGQZVXMqQJJlz.addMouseListener(miBFKRJVXkTtMTMpbtygQBp2);
        nCABabPjyneGQZVXMqQJJlz.addMouseListener(nCABabPjyneGQZVXMqQJJlz);
        nCABabPjyneGQZVXMqQJJlz.addMouseMotionListener(miBFKRJVXkTtMTMpbtygQBp2);
        nCABabPjyneGQZVXMqQJJlz.addMouseMotionListener(nCABabPjyneGQZVXMqQJJlz);
        nCABabPjyneGQZVXMqQJJlz.rHAjVyBgPhqkQKsOvJMPMYn(miBFKRJVXkTtMTMpbtygQBp2);
        FiypGaFYdzscEBybnfTNrMU.rHAjVyBgPhqkQKsOvJMPMYn().rHAjVyBgPhqkQKsOvJMPMYn(nCABabPjyneGQZVXMqQJJlz, Integer.MAX_VALUE);
        miBFKRJVXkTtMTMpbtygQBp2.addMouseListener(nCABabPjyneGQZVXMqQJJlz);
        miBFKRJVXkTtMTMpbtygQBp2.addMouseMotionListener(nCABabPjyneGQZVXMqQJJlz);
        miBFKRJVXkTtMTMpbtygQBp2.addMouseListener(miBFKRJVXkTtMTMpbtygQBp2);
        miBFKRJVXkTtMTMpbtygQBp2.addMouseMotionListener(miBFKRJVXkTtMTMpbtygQBp2);
        miBFKRJVXkTtMTMpbtygQBp2.addMouseMotionListener(uRfbqkKHjLdhIvxtcBLiaka2);
        miBFKRJVXkTtMTMpbtygQBp2.addMouseListener(uRfbqkKHjLdhIvxtcBLiaka2);
        miBFKRJVXkTtMTMpbtygQBp2.rHAjVyBgPhqkQKsOvJMPMYn(JSuXbPLjXcQLpTiButqPpoI.wunjGuaHWPKejzkQKUJfPKe());
        FiypGaFYdzscEBybnfTNrMU.rHAjVyBgPhqkQKsOvJMPMYn().rHAjVyBgPhqkQKsOvJMPMYn(miBFKRJVXkTtMTMpbtygQBp2, Integer.MIN_VALUE);
        ipeEJbKSCPCYelngcqwUQgF.addMouseListener(ipeEJbKSCPCYelngcqwUQgF);
        ipeEJbKSCPCYelngcqwUQgF.addMouseListener(tSILPPfdcnHrmGfZNXMsPlw);
        ipeEJbKSCPCYelngcqwUQgF.addMouseListener(uRfbqkKHjLdhIvxtcBLiaka2);
        ipeEJbKSCPCYelngcqwUQgF.addMouseListener(ntMSlcredseGwvbyesPSAQf2);
        ipeEJbKSCPCYelngcqwUQgF.addMouseListener(nCABabPjyneGQZVXMqQJJlz);
        ipeEJbKSCPCYelngcqwUQgF.addMouseListener(miBFKRJVXkTtMTMpbtygQBp2);
        ipeEJbKSCPCYelngcqwUQgF.rHAjVyBgPhqkQKsOvJMPMYn(JSuXbPLjXcQLpTiButqPpoI.VmkNmvoUyyfcyaaKFyveguY());
        ipeEJbKSCPCYelngcqwUQgF.rHAjVyBgPhqkQKsOvJMPMYn(VZagBOcdslnIaKEkojULJvx);
        ipeEJbKSCPCYelngcqwUQgF.rHAjVyBgPhqkQKsOvJMPMYn(kfrVEsKUvFeBfAoSkvCCRmV.rHAjVyBgPhqkQKsOvJMPMYn());
        tSILPPfdcnHrmGfZNXMsPlw.addMouseListener(ipeEJbKSCPCYelngcqwUQgF);
        tSILPPfdcnHrmGfZNXMsPlw.addMouseListener(tSILPPfdcnHrmGfZNXMsPlw);
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(kfrVEsKUvFeBfAoSkvCCRmV2, ZjoyaRSokkGYDwXHPKTBIiX.values());
        JSuXbPLjXcQLpTiButqPpoI.rHAjVyBgPhqkQKsOvJMPMYn(kfrVEsKUvFeBfAoSkvCCRmV2, lXCOGwZXVelwEKHMMPwpSAO.values());
        Logger.getLogger("org.jaudiotagger").setLevel(Level.OFF);
        rVznADxHDiUGKUcgCFACfzg2.rHAjVyBgPhqkQKsOvJMPMYn(new sLuwRITuDanyEuFWGUJWQqQ(){

            @Override
            public void rHAjVyBgPhqkQKsOvJMPMYn(File file) {
                final File file2 = file;
                if (!QPeIwmpzLZIktKLXAJOQHcO) {
                    NuCoRkdmXmpraThwzNAiTcw.rHAjVyBgPhqkQKsOvJMPMYn(file.getAbsolutePath() + "_report");
                } else {
                    File file3 = new File(NuCoRkdmXmpraThwzNAiTcw.JSuXbPLjXcQLpTiButqPpoI());
                    NuCoRkdmXmpraThwzNAiTcw.rHAjVyBgPhqkQKsOvJMPMYn(file3.getParent() + File.separatorChar + file.getName() + "_report");
                }
                NuCoRkdmXmpraThwzNAiTcw.rHAjVyBgPhqkQKsOvJMPMYn(new qAPYmrSBwvJMqiHvTVjYfvo(){

                    @Override
                    public void rHAjVyBgPhqkQKsOvJMPMYn(GUmcHlGuXLMlTCxtghDBJCl gUmcHlGuXLMlTCxtghDBJCl) {
                        NuCoRkdmXmpraThwzNAiTcw.setVisible(false);
                        try {
                            if (!Files.equal((File)file2.getParentFile(), (File)new File(NuCoRkdmXmpraThwzNAiTcw.JSuXbPLjXcQLpTiButqPpoI()).getParentFile())) {
                                QPeIwmpzLZIktKLXAJOQHcO = true;
                            }
                        }
                        catch (IOException iOException) {
                            // empty catch block
                        }
                        if (gUmcHlGuXLMlTCxtghDBJCl == GUmcHlGuXLMlTCxtghDBJCl.rHAjVyBgPhqkQKsOvJMPMYn) {
                            Main.rHAjVyBgPhqkQKsOvJMPMYn(file2.getName(), NuCoRkdmXmpraThwzNAiTcw.JSuXbPLjXcQLpTiButqPpoI(), NuCoRkdmXmpraThwzNAiTcw.QPeIwmpzLZIktKLXAJOQHcO(), NuCoRkdmXmpraThwzNAiTcw.rHAjVyBgPhqkQKsOvJMPMYn());
                        }
                    }
                });
                NuCoRkdmXmpraThwzNAiTcw.setVisible(true);
            }
        });
    }

    public static void rHAjVyBgPhqkQKsOvJMPMYn(String string, String string2, boolean bl, boolean bl2) {
        Main.rHAjVyBgPhqkQKsOvJMPMYn(string, string2, bl, bl2, false);
    }

    public static void rHAjVyBgPhqkQKsOvJMPMYn(String string, String string2, boolean bl, boolean bl2, boolean bl3) {
        if (bl) {
            wunjGuaHWPKejzkQKUJfPKe.rHAjVyBgPhqkQKsOvJMPMYn(new UxNrRnaNgSMFamtqcmJwDwX(string), string2 + ".png");
        }
        if (bl2) {
            wunjGuaHWPKejzkQKUJfPKe.rHAjVyBgPhqkQKsOvJMPMYn(VZagBOcdslnIaKEkojULJvx, string2 + ".txt");
        }
        if (bl3) {
            wunjGuaHWPKejzkQKUJfPKe.rHAjVyBgPhqkQKsOvJMPMYn(YGjBevanihqaxYKnUNtrNeA);
        }
    }

    public static synchronized Path rHAjVyBgPhqkQKsOvJMPMYn() {
        if (ibbBhgWhrhhiOLwDlcriPhb == null) {
            try {
                ibbBhgWhrhhiOLwDlcriPhb = mkMdhMdKzFSfOwGBSnmEzOe.rHAjVyBgPhqkQKsOvJMPMYn("_msf");
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
        return ibbBhgWhrhhiOLwDlcriPhb;
    }

    static {
        QPeIwmpzLZIktKLXAJOQHcO = false;
        wunjGuaHWPKejzkQKUJfPKe = FiypGaFYdzscEBybnfTNrMU.rHAjVyBgPhqkQKsOvJMPMYn();
        NuCoRkdmXmpraThwzNAiTcw = new HwBMoAdDdYXRPcGrNGRitQy((Frame)dnqxuOOQwmxxivZzrQBWydh, true);
        VZagBOcdslnIaKEkojULJvx = new lwCwsaOnEEwXwbudVVNfhyz();
        VmkNmvoUyyfcyaaKFyveguY = new XwHjOhsVogzdybpQXdaEGrM();
        YGjBevanihqaxYKnUNtrNeA = AkjxEminiBQvbUdaGZgkyhV.rHAjVyBgPhqkQKsOvJMPMYn();
        OrmpCzNZzYDlbDZDBXyofLf = new mkMdhMdKzFSfOwGBSnmEzOe(Main.rHAjVyBgPhqkQKsOvJMPMYn());
        rHAjVyBgPhqkQKsOvJMPMYn = new kTbZASHDopQBPRkAiVONWbv(new hdtwbvZSeJsEBjhsjhkgMoS());
        rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn(0, 2);
        rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn(1, 1);
        rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn(2, 0);
        rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn(3, 180724);
    }
}

