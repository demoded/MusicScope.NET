/*
 * Decompiled with CFR 0.152.
 */
package com.xivero.hraa.gui.frame.jitter;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.JComponent;
import javax.swing.SwingUtilities;

public class JSuXbPLjXcQLpTiButqPpoI
extends JComponent
implements MouseListener,
MouseMotionListener,
Runnable {
    private double[] rHAjVyBgPhqkQKsOvJMPMYn = new double[16384];
    private double[] QPeIwmpzLZIktKLXAJOQHcO = new double[16384];
    private int JSuXbPLjXcQLpTiButqPpoI = 0;
    private int iwitQCGCnkthNoQBBlYaPUM = 0;
    private final int dnqxuOOQwmxxivZzrQBWydh = 40;
    private final int VZagBOcdslnIaKEkojULJvx = 725;
    private final int VmkNmvoUyyfcyaaKFyveguY = 16384;
    private final int YGjBevanihqaxYKnUNtrNeA = 11025;
    private final double wunjGuaHWPKejzkQKUJfPKe = 1.3458251953125;
    private int NuCoRkdmXmpraThwzNAiTcw = 8192;
    private int OrmpCzNZzYDlbDZDBXyofLf = 500;
    private int ibbBhgWhrhhiOLwDlcriPhb = this.NuCoRkdmXmpraThwzNAiTcw - this.OrmpCzNZzYDlbDZDBXyofLf;
    private int kVXnygMrAwyMajIgLatcyWS = 1;
    private int vJgxuXjYdOvTUFZsFThavLL = this.NuCoRkdmXmpraThwzNAiTcw - this.kVXnygMrAwyMajIgLatcyWS * this.OrmpCzNZzYDlbDZDBXyofLf;

    public JSuXbPLjXcQLpTiButqPpoI() {
        this.QPeIwmpzLZIktKLXAJOQHcO();
        this.rHAjVyBgPhqkQKsOvJMPMYn();
    }

    private void QPeIwmpzLZIktKLXAJOQHcO() {
        this.addMouseMotionListener(this);
        this.addMouseListener(this);
    }

    public final void rHAjVyBgPhqkQKsOvJMPMYn() {
        for (int i = 0; i < 16384; ++i) {
            this.rHAjVyBgPhqkQKsOvJMPMYn[i] = -150.0;
        }
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(double[] dArray) {
        this.rHAjVyBgPhqkQKsOvJMPMYn = dArray;
        SwingUtilities.invokeLater(new Runnable(){

            @Override
            public void run() {
                JSuXbPLjXcQLpTiButqPpoI.this.repaint();
            }
        });
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(int n) {
        this.kVXnygMrAwyMajIgLatcyWS = n;
        this.vJgxuXjYdOvTUFZsFThavLL = this.NuCoRkdmXmpraThwzNAiTcw - n * this.OrmpCzNZzYDlbDZDBXyofLf;
    }

    @Override
    public void paintComponent(Graphics graphics) {
        int n;
        String string;
        int n2;
        Graphics2D graphics2D = (Graphics2D)graphics;
        FontMetrics fontMetrics = graphics2D.getFontMetrics();
        double d = -150.0;
        double d2 = this.rHAjVyBgPhqkQKsOvJMPMYn[this.NuCoRkdmXmpraThwzNAiTcw];
        graphics2D.setColor(Color.decode("#000000"));
        graphics2D.drawLine(40, 725, 40, 15);
        for (n2 = 0; n2 < 16; ++n2) {
            graphics2D.setColor(Color.decode("#DDDDDD"));
            graphics2D.drawLine(40, (int)(725.0 - (double)n2 * 46.6666), 1040, (int)(725.0 - (double)n2 * 46.6666));
            graphics2D.setColor(Color.decode("#000000"));
            graphics2D.drawLine(40, (int)(725.0 - (double)n2 * 46.6666), 35, (int)(725.0 - (double)n2 * 46.6666));
            string = String.valueOf((15 - n2) * -10);
            graphics2D.drawString(string, 32 - fontMetrics.stringWidth(string), (int)(725.0 - (double)n2 * 46.6666 + 5.0));
        }
        string = "dB";
        graphics2D.drawString(string, 40 - fontMetrics.stringWidth(string) / 2, 10);
        graphics2D.drawLine(40, 725, 1040, 725);
        graphics2D.drawLine(540, 725, 540, 730);
        string = String.valueOf(11025);
        graphics2D.drawString(string, 540 - fontMetrics.stringWidth(string) / 2, 745);
        string = "Hz";
        graphics2D.drawString(string, 1065 - fontMetrics.stringWidth(string), 730);
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int n3 = this.vJgxuXjYdOvTUFZsFThavLL;
        for (n2 = 0; n2 < 1002; ++n2) {
            graphics2D.setColor(Color.decode("#0000FF"));
            double d3 = -150.0;
            for (int i = 0; i < this.kVXnygMrAwyMajIgLatcyWS; ++i) {
                if (!(d3 < this.rHAjVyBgPhqkQKsOvJMPMYn[n3 + i])) continue;
                d3 = this.rHAjVyBgPhqkQKsOvJMPMYn[n3 + i];
            }
            int n4 = (int)(725.0 - 4.6666 * (150.0 + d));
            n = (int)(725.0 - 4.6666 * (150.0 + d3));
            d = d3;
            this.QPeIwmpzLZIktKLXAJOQHcO[n2] = d3;
            if (n2 > 0) {
                graphics2D.drawLine(40 + n2 - 1, n4, 40 + n2, n);
            }
            n3 += this.kVXnygMrAwyMajIgLatcyWS;
        }
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
        if (this.JSuXbPLjXcQLpTiButqPpoI >= 40 && this.JSuXbPLjXcQLpTiButqPpoI < 1042) {
            graphics2D.setColor(Color.decode("#000000"));
            graphics2D.drawLine(this.JSuXbPLjXcQLpTiButqPpoI, 725, this.JSuXbPLjXcQLpTiButqPpoI, 60);
            double d4 = this.QPeIwmpzLZIktKLXAJOQHcO[this.JSuXbPLjXcQLpTiButqPpoI - 40];
            graphics2D.setColor(Color.decode("#FF0000"));
            n = (int)(725.0 - 4.6666 * (150.0 + d4));
            graphics2D.drawLine(this.JSuXbPLjXcQLpTiButqPpoI - 10, n, this.JSuXbPLjXcQLpTiButqPpoI + 10, n);
            graphics2D.setColor(Color.decode("#000000"));
            int n5 = (int)((double)(this.JSuXbPLjXcQLpTiButqPpoI - 40 - 500) * 1.3458251953125 * (double)this.kVXnygMrAwyMajIgLatcyWS + 11025.0);
            string = String.valueOf(n5) + "Hz";
            graphics2D.drawString(string, this.JSuXbPLjXcQLpTiButqPpoI + 40 + 18 - fontMetrics.stringWidth(string), 10);
            double d5 = (double)Math.round(10.0 * d4) / 10.0;
            string = String.valueOf(d5) + "dB";
            graphics2D.setColor(Color.decode("#000000"));
            graphics2D.drawString(string, this.JSuXbPLjXcQLpTiButqPpoI + 40 + 18 - fontMetrics.stringWidth(string), 25);
            int n6 = Math.abs(n5 - 11025);
            string = String.valueOf(n6) + "Hz";
            graphics2D.setColor(Color.decode("#FF0000"));
            graphics2D.drawString(string, this.JSuXbPLjXcQLpTiButqPpoI + 40 + 18 - fontMetrics.stringWidth(string), 40);
            double d6 = d4 - d2;
            int n7 = (int)Math.round(1.0E12 * (4.0 * Math.pow(10.0, d6 / 20.0) / 69272.11801165494));
            string = n7 < 999999 ? String.valueOf(n7) + "ps" : "--- ps";
            graphics2D.setColor(Color.decode("#FF0000"));
            graphics2D.drawString(string, this.JSuXbPLjXcQLpTiButqPpoI + 40 + 18 - fontMetrics.stringWidth(string), 55);
        }
    }

    @Override
    public void run() {
    }

    @Override
    public void mouseClicked(MouseEvent mouseEvent) {
        int n = mouseEvent.getX();
        int n2 = mouseEvent.getY();
        if (mouseEvent.getSource() == this) {
            this.repaint();
        }
    }

    @Override
    public void mousePressed(MouseEvent mouseEvent) {
        Object var2_2 = null;
        if (mouseEvent.getSource() == this) {
            this.JSuXbPLjXcQLpTiButqPpoI = mouseEvent.getX();
            this.iwitQCGCnkthNoQBBlYaPUM = mouseEvent.getY();
        }
    }

    @Override
    public void mouseReleased(MouseEvent mouseEvent) {
    }

    @Override
    public void mouseEntered(MouseEvent mouseEvent) {
    }

    @Override
    public void mouseExited(MouseEvent mouseEvent) {
        if (mouseEvent.getSource() == this) {
            this.JSuXbPLjXcQLpTiButqPpoI = 0;
            this.iwitQCGCnkthNoQBBlYaPUM = 0;
        }
        this.repaint();
    }

    @Override
    public void mouseDragged(MouseEvent mouseEvent) {
    }

    @Override
    public void mouseMoved(MouseEvent mouseEvent) {
        if (mouseEvent.getSource() == this) {
            this.JSuXbPLjXcQLpTiButqPpoI = mouseEvent.getX();
            this.iwitQCGCnkthNoQBBlYaPUM = mouseEvent.getY();
        }
        this.repaint();
    }
}

