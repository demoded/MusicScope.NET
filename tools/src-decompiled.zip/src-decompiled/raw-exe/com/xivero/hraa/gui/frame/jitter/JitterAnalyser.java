/*
 * Decompiled with CFR 0.152.
 */
package com.xivero.hraa.gui.frame.jitter;

import com.xivero.hraa.gui.frame.jitter.JSuXbPLjXcQLpTiButqPpoI;
import com.xivero.hraa.gui.frame.jitter.rHAjVyBgPhqkQKsOvJMPMYn;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Line;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class JitterAnalyser
extends JDialog
implements ActionListener {
    static final Mixer.Info[] rHAjVyBgPhqkQKsOvJMPMYn = AudioSystem.getMixerInfo();
    static final int[] QPeIwmpzLZIktKLXAJOQHcO = new int[rHAjVyBgPhqkQKsOvJMPMYn.length + 1];
    static final int[] JSuXbPLjXcQLpTiButqPpoI = new int[rHAjVyBgPhqkQKsOvJMPMYn.length + 1];
    static final JComboBox iwitQCGCnkthNoQBBlYaPUM = new JComboBox();
    static final JComboBox dnqxuOOQwmxxivZzrQBWydh = new JComboBox();
    private static final JButton ibbBhgWhrhhiOLwDlcriPhb = new JButton("Start");
    static JRadioButton VZagBOcdslnIaKEkojULJvx = new JRadioButton("Narrow", true);
    static JRadioButton VmkNmvoUyyfcyaaKFyveguY = new JRadioButton("Medium");
    static JRadioButton YGjBevanihqaxYKnUNtrNeA = new JRadioButton("Wide");
    static JRadioButton wunjGuaHWPKejzkQKUJfPKe = new JRadioButton("Ultra Wide");
    public static final JSuXbPLjXcQLpTiButqPpoI NuCoRkdmXmpraThwzNAiTcw = new JSuXbPLjXcQLpTiButqPpoI();
    public static rHAjVyBgPhqkQKsOvJMPMYn OrmpCzNZzYDlbDZDBXyofLf = new rHAjVyBgPhqkQKsOvJMPMYn();

    public JitterAnalyser(Frame frame, boolean bl) {
        super(frame, bl);
        JitterAnalyser.iwitQCGCnkthNoQBBlYaPUM();
        this.JSuXbPLjXcQLpTiButqPpoI();
    }

    private Component QPeIwmpzLZIktKLXAJOQHcO() {
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BoxLayout(jPanel, 3));
        jPanel.setBackground(Color.black);
        JPanel jPanel2 = new JPanel();
        JPanel jPanel3 = new JPanel();
        jPanel3.setBackground(Color.white);
        jPanel.add(jPanel2);
        jPanel.add(jPanel3);
        JLabel jLabel = new JLabel("Input:");
        iwitQCGCnkthNoQBBlYaPUM.setPreferredSize(new Dimension(250, 25));
        dnqxuOOQwmxxivZzrQBWydh.setPreferredSize(new Dimension(200, 25));
        jPanel2.add(jLabel);
        jPanel2.add(iwitQCGCnkthNoQBBlYaPUM);
        NuCoRkdmXmpraThwzNAiTcw.setPreferredSize(new Dimension(1100, 750));
        NuCoRkdmXmpraThwzNAiTcw.setBackground(Color.white);
        jPanel3.add(NuCoRkdmXmpraThwzNAiTcw);
        jPanel2.add(ibbBhgWhrhhiOLwDlcriPhb);
        ibbBhgWhrhhiOLwDlcriPhb.addActionListener(this);
        JLabel jLabel2 = new JLabel("     Bandwidth:");
        jPanel2.add(jLabel2);
        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(VZagBOcdslnIaKEkojULJvx);
        buttonGroup.add(VmkNmvoUyyfcyaaKFyveguY);
        buttonGroup.add(YGjBevanihqaxYKnUNtrNeA);
        buttonGroup.add(wunjGuaHWPKejzkQKUJfPKe);
        jPanel2.add(VZagBOcdslnIaKEkojULJvx);
        jPanel2.add(VmkNmvoUyyfcyaaKFyveguY);
        jPanel2.add(YGjBevanihqaxYKnUNtrNeA);
        jPanel2.add(wunjGuaHWPKejzkQKUJfPKe);
        VZagBOcdslnIaKEkojULJvx.addActionListener(this);
        VmkNmvoUyyfcyaaKFyveguY.addActionListener(this);
        YGjBevanihqaxYKnUNtrNeA.addActionListener(this);
        wunjGuaHWPKejzkQKUJfPKe.addActionListener(this);
        return jPanel;
    }

    private void JSuXbPLjXcQLpTiButqPpoI() {
        Dimension dimension = new Dimension(1150, 850);
        this.setTitle("MusicScope - Jitter Analyzer");
        this.setLocation(10, 10);
        this.setPreferredSize(dimension);
        this.setMinimumSize(dimension);
        this.setMaximumSize(dimension);
        this.setSize(dimension);
        this.setDefaultCloseOperation(1);
        this.setResizable(false);
        this.addWindowListener(new WindowAdapter(){

            @Override
            public void windowClosing(WindowEvent windowEvent) {
                JitterAnalyser.this.VZagBOcdslnIaKEkojULJvx();
            }
        });
        Component component = this.QPeIwmpzLZIktKLXAJOQHcO();
        this.getContentPane().add(component, "Center");
    }

    private static void iwitQCGCnkthNoQBBlYaPUM() {
        int n = 0;
        boolean bl = false;
        Line.Info info = new Line.Info(TargetDataLine.class);
        for (int i = 0; i < rHAjVyBgPhqkQKsOvJMPMYn.length; ++i) {
            Mixer mixer = AudioSystem.getMixer(rHAjVyBgPhqkQKsOvJMPMYn[i]);
            if (!mixer.isLineSupported(info)) continue;
            iwitQCGCnkthNoQBBlYaPUM.addItem(rHAjVyBgPhqkQKsOvJMPMYn[i].getName());
            JitterAnalyser.QPeIwmpzLZIktKLXAJOQHcO[n] = i;
            ++n;
        }
    }

    private void dnqxuOOQwmxxivZzrQBWydh() {
        if (!OrmpCzNZzYDlbDZDBXyofLf.rHAjVyBgPhqkQKsOvJMPMYn()) {
            OrmpCzNZzYDlbDZDBXyofLf.rHAjVyBgPhqkQKsOvJMPMYn(true);
        }
        try {
            Thread.sleep(500L);
        }
        catch (InterruptedException interruptedException) {
            // empty catch block
        }
        NuCoRkdmXmpraThwzNAiTcw.rHAjVyBgPhqkQKsOvJMPMYn();
        OrmpCzNZzYDlbDZDBXyofLf.rHAjVyBgPhqkQKsOvJMPMYn(false);
        new Thread(OrmpCzNZzYDlbDZDBXyofLf).start();
        ibbBhgWhrhhiOLwDlcriPhb.setText("Stop");
    }

    private void VZagBOcdslnIaKEkojULJvx() {
        OrmpCzNZzYDlbDZDBXyofLf.rHAjVyBgPhqkQKsOvJMPMYn(true);
        ibbBhgWhrhhiOLwDlcriPhb.setText("Start");
    }

    public static void rHAjVyBgPhqkQKsOvJMPMYn() {
        ibbBhgWhrhhiOLwDlcriPhb.setText("Start");
    }

    public static void rHAjVyBgPhqkQKsOvJMPMYn(double[] dArray) {
        if (NuCoRkdmXmpraThwzNAiTcw != null) {
            NuCoRkdmXmpraThwzNAiTcw.rHAjVyBgPhqkQKsOvJMPMYn(dArray);
        }
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        if (actionEvent.getSource() == ibbBhgWhrhhiOLwDlcriPhb) {
            if ("Start".equals(ibbBhgWhrhhiOLwDlcriPhb.getText())) {
                this.dnqxuOOQwmxxivZzrQBWydh();
            } else {
                this.VZagBOcdslnIaKEkojULJvx();
            }
        }
        if (actionEvent.getSource() == VZagBOcdslnIaKEkojULJvx) {
            NuCoRkdmXmpraThwzNAiTcw.rHAjVyBgPhqkQKsOvJMPMYn(1);
        }
        if (actionEvent.getSource() == VmkNmvoUyyfcyaaKFyveguY) {
            NuCoRkdmXmpraThwzNAiTcw.rHAjVyBgPhqkQKsOvJMPMYn(2);
        }
        if (actionEvent.getSource() == YGjBevanihqaxYKnUNtrNeA) {
            NuCoRkdmXmpraThwzNAiTcw.rHAjVyBgPhqkQKsOvJMPMYn(4);
        }
        if (actionEvent.getSource() == wunjGuaHWPKejzkQKUJfPKe) {
            NuCoRkdmXmpraThwzNAiTcw.rHAjVyBgPhqkQKsOvJMPMYn(8);
        }
    }

    public static void main(String[] stringArray) {
        JitterAnalyser.iwitQCGCnkthNoQBBlYaPUM();
    }

    @Override
    public void setVisible(boolean bl) {
        if (bl) {
            this.setLocationRelativeTo(null);
        }
        super.setVisible(bl);
    }
}

