/*
 * Decompiled with CFR 0.152.
 */
package com.xivero.hraa.gui.frame;

import com.xivero.hraa.gui.frame.ScrollbarStyle;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.dnd.DropTarget;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.LayoutStyle;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import sdfgjkljljoftrytrszgijpokjprs.AVBqUkzZTgvQKwqvfonPEcF;
import sdfgjkljljoftrytrszgijpokjprs.BtSxiFJlPwYFcLNMFEsrKYC;
import sdfgjkljljoftrytrszgijpokjprs.FiypGaFYdzscEBybnfTNrMU;
import sdfgjkljljoftrytrszgijpokjprs.GGiRamzaArNdRQDukShvdNU;
import sdfgjkljljoftrytrszgijpokjprs.IpeEJbKSCPCYelngcqwUQgF;
import sdfgjkljljoftrytrszgijpokjprs.LRWbrwPJNJMrzLYayAJxsLY;
import sdfgjkljljoftrytrszgijpokjprs.NCABabPjyneGQZVXMqQJJlz;
import sdfgjkljljoftrytrszgijpokjprs.OVwxYDEnxDAUeujkyADMYmG;
import sdfgjkljljoftrytrszgijpokjprs.TSILPPfdcnHrmGfZNXMsPlw;
import sdfgjkljljoftrytrszgijpokjprs.XZEXahJHCGCBNASefxRYhTY;
import sdfgjkljljoftrytrszgijpokjprs.caLVyYpGgtBFoKHsZrgjtvS;
import sdfgjkljljoftrytrszgijpokjprs.fdLwzVOPYyeAPmrtqvpdjBY;
import sdfgjkljljoftrytrszgijpokjprs.gnLUzUqSTDchaQNdJTgTnhn;
import sdfgjkljljoftrytrszgijpokjprs.hbAAgnybqKnNXPUlmqPVCYX;
import sdfgjkljljoftrytrszgijpokjprs.miBFKRJVXkTtMTMpbtygQBp;
import sdfgjkljljoftrytrszgijpokjprs.mjycquzYfQnWsdeiKxtdpyM;
import sdfgjkljljoftrytrszgijpokjprs.nkSLFlumvAIqqGMcVFgItWJ;
import sdfgjkljljoftrytrszgijpokjprs.ntMSlcredseGwvbyesPSAQf;
import sdfgjkljljoftrytrszgijpokjprs.nyfwxCZoaPuQlzOUeBNsFaO;
import sdfgjkljljoftrytrszgijpokjprs.rVznADxHDiUGKUcgCFACfzg;
import sdfgjkljljoftrytrszgijpokjprs.uBNIahMkeIPqFihQtHhzUgi;
import sdfgjkljljoftrytrszgijpokjprs.uRfbqkKHjLdhIvxtcBLiaka;

public class rHAjVyBgPhqkQKsOvJMPMYn
extends JFrame
implements mjycquzYfQnWsdeiKxtdpyM {
    private static final long serialVersionUID = 1L;
    private final int rHAjVyBgPhqkQKsOvJMPMYn;
    private static caLVyYpGgtBFoKHsZrgjtvS QPeIwmpzLZIktKLXAJOQHcO;
    private uRfbqkKHjLdhIvxtcBLiaka JSuXbPLjXcQLpTiButqPpoI;
    private XZEXahJHCGCBNASefxRYhTY iwitQCGCnkthNoQBBlYaPUM;
    private gnLUzUqSTDchaQNdJTgTnhn dnqxuOOQwmxxivZzrQBWydh;
    private gnLUzUqSTDchaQNdJTgTnhn VZagBOcdslnIaKEkojULJvx;
    private nyfwxCZoaPuQlzOUeBNsFaO VmkNmvoUyyfcyaaKFyveguY;
    private JLabel YGjBevanihqaxYKnUNtrNeA;
    private JLabel wunjGuaHWPKejzkQKUJfPKe;
    private JLabel NuCoRkdmXmpraThwzNAiTcw;
    private JPanel OrmpCzNZzYDlbDZDBXyofLf;
    private JPanel ibbBhgWhrhhiOLwDlcriPhb;
    private JPanel kVXnygMrAwyMajIgLatcyWS;
    private JPanel vJgxuXjYdOvTUFZsFThavLL;
    private JPanel FoVkhFqKjpvomrYQnnVFKwY;
    private JPanel kMqExmRlFLPTFqBDauCBKYL;
    private JPanel uAGKHXCiDSbltWOPIpXUgwC;
    private JPanel TNdBwPzcCrGifNBGlgVkPGL;
    private JPanel CWUsTkhDhNSqiWmIUfrczRE;
    private JPanel XphHMDaiRLyTnLXiOVlLPqZ;
    private JPanel cmBIzvlUaDPTiIjykjjmigy;
    private JScrollPane NwteqrdXWwWpaoJmiBDNxxz;
    private IpeEJbKSCPCYelngcqwUQgF SYnuCfTgzCxensnEBdDedFe;
    private TSILPPfdcnHrmGfZNXMsPlw ajlSZBxlJSwYUTeUsFfhumH;
    private GGiRamzaArNdRQDukShvdNU TTvVyJBikEjkvfEQPPobmUz;
    private nkSLFlumvAIqqGMcVFgItWJ IiqlRFfWYxYaAobCQvdRFEl;
    private NCABabPjyneGQZVXMqQJJlz gLHqHFGBEIDXbcqrsZzduVF;
    private LRWbrwPJNJMrzLYayAJxsLY xurJiSGFDQVeEtISoLSazWS;
    private ntMSlcredseGwvbyesPSAQf KLSmtNpcsSwOKRbEbUKdpqL;
    private rVznADxHDiUGKUcgCFACfzg DamZYXCIxKyKrnRzlNpeRfa;
    private uBNIahMkeIPqFihQtHhzUgi ggsqrqYbiokXEjuGiCwGpvf;
    private uBNIahMkeIPqFihQtHhzUgi YikeWIksDnZbpLLacoPMfKN;
    private uBNIahMkeIPqFihQtHhzUgi rTbADuShFCOuMvGFEuNmbFb;
    private uBNIahMkeIPqFihQtHhzUgi tJuPpiiZKFnZdtTTOrwfbxj;
    private uBNIahMkeIPqFihQtHhzUgi GgoKTcuIevtAhezhbHlrofU;
    private AVBqUkzZTgvQKwqvfonPEcF sUwuMtUcgVzMHVXVoNHFrTY;
    private miBFKRJVXkTtMTMpbtygQBp dBprZQxZjIUbnidwEbEFsgB;

    public rHAjVyBgPhqkQKsOvJMPMYn() {
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        Insets insets = Toolkit.getDefaultToolkit().getScreenInsets(this.getGraphicsConfiguration());
        int n = insets.bottom;
        this.rHAjVyBgPhqkQKsOvJMPMYn = Math.min(dimension.height - n, 995);
        this.CWUsTkhDhNSqiWmIUfrczRE();
        this.XphHMDaiRLyTnLXiOVlLPqZ();
        ArrayList<Image> arrayList = new ArrayList<Image>(0);
        for (int i = 16; i <= 128; i *= 2) {
            arrayList.add(new ImageIcon(rHAjVyBgPhqkQKsOvJMPMYn.class.getResource("icon" + i + ".png")).getImage());
        }
        this.setIconImages(arrayList);
        this.setLocationRelativeTo(null);
        QPeIwmpzLZIktKLXAJOQHcO = new caLVyYpGgtBFoKHsZrgjtvS((Frame)this, true);
    }

    public GGiRamzaArNdRQDukShvdNU rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.TTvVyJBikEjkvfEQPPobmUz;
    }

    public ntMSlcredseGwvbyesPSAQf QPeIwmpzLZIktKLXAJOQHcO() {
        return this.KLSmtNpcsSwOKRbEbUKdpqL;
    }

    public IpeEJbKSCPCYelngcqwUQgF JSuXbPLjXcQLpTiButqPpoI() {
        return this.SYnuCfTgzCxensnEBdDedFe;
    }

    public NCABabPjyneGQZVXMqQJJlz iwitQCGCnkthNoQBBlYaPUM() {
        return this.gLHqHFGBEIDXbcqrsZzduVF;
    }

    public miBFKRJVXkTtMTMpbtygQBp dnqxuOOQwmxxivZzrQBWydh() {
        return this.dBprZQxZjIUbnidwEbEFsgB;
    }

    public XZEXahJHCGCBNASefxRYhTY VZagBOcdslnIaKEkojULJvx() {
        return this.iwitQCGCnkthNoQBBlYaPUM;
    }

    public TSILPPfdcnHrmGfZNXMsPlw VmkNmvoUyyfcyaaKFyveguY() {
        return this.ajlSZBxlJSwYUTeUsFfhumH;
    }

    public uRfbqkKHjLdhIvxtcBLiaka YGjBevanihqaxYKnUNtrNeA() {
        return this.JSuXbPLjXcQLpTiButqPpoI;
    }

    public rVznADxHDiUGKUcgCFACfzg wunjGuaHWPKejzkQKUJfPKe() {
        return this.DamZYXCIxKyKrnRzlNpeRfa;
    }

    public nyfwxCZoaPuQlzOUeBNsFaO NuCoRkdmXmpraThwzNAiTcw() {
        return this.VmkNmvoUyyfcyaaKFyveguY;
    }

    public caLVyYpGgtBFoKHsZrgjtvS OrmpCzNZzYDlbDZDBXyofLf() {
        return QPeIwmpzLZIktKLXAJOQHcO;
    }

    public nkSLFlumvAIqqGMcVFgItWJ ibbBhgWhrhhiOLwDlcriPhb() {
        return this.IiqlRFfWYxYaAobCQvdRFEl;
    }

    public AVBqUkzZTgvQKwqvfonPEcF kVXnygMrAwyMajIgLatcyWS() {
        return this.sUwuMtUcgVzMHVXVoNHFrTY;
    }

    public hbAAgnybqKnNXPUlmqPVCYX vJgxuXjYdOvTUFZsFThavLL() {
        return this.IiqlRFfWYxYaAobCQvdRFEl.rHAjVyBgPhqkQKsOvJMPMYn();
    }

    public OVwxYDEnxDAUeujkyADMYmG FoVkhFqKjpvomrYQnnVFKwY() {
        return this.IiqlRFfWYxYaAobCQvdRFEl.QPeIwmpzLZIktKLXAJOQHcO();
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(fdLwzVOPYyeAPmrtqvpdjBY fdLwzVOPYyeAPmrtqvpdjBY2) {
        this.sUwuMtUcgVzMHVXVoNHFrTY.rHAjVyBgPhqkQKsOvJMPMYn(fdLwzVOPYyeAPmrtqvpdjBY2);
    }

    public LRWbrwPJNJMrzLYayAJxsLY kMqExmRlFLPTFqBDauCBKYL() {
        return this.xurJiSGFDQVeEtISoLSazWS;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(BtSxiFJlPwYFcLNMFEsrKYC btSxiFJlPwYFcLNMFEsrKYC) {
        DropTarget dropTarget = new DropTarget(this, btSxiFJlPwYFcLNMFEsrKYC);
        this.setDropTarget(dropTarget);
    }

    private void CWUsTkhDhNSqiWmIUfrczRE() {
        this.vJgxuXjYdOvTUFZsFThavLL = new JPanel();
        this.OrmpCzNZzYDlbDZDBXyofLf = new JPanel();
        this.kVXnygMrAwyMajIgLatcyWS = new JPanel();
        this.TTvVyJBikEjkvfEQPPobmUz = new GGiRamzaArNdRQDukShvdNU();
        this.VmkNmvoUyyfcyaaKFyveguY = new nyfwxCZoaPuQlzOUeBNsFaO();
        this.YikeWIksDnZbpLLacoPMfKN = new uBNIahMkeIPqFihQtHhzUgi();
        this.GgoKTcuIevtAhezhbHlrofU = new uBNIahMkeIPqFihQtHhzUgi();
        this.DamZYXCIxKyKrnRzlNpeRfa = new rVznADxHDiUGKUcgCFACfzg();
        this.IiqlRFfWYxYaAobCQvdRFEl = new nkSLFlumvAIqqGMcVFgItWJ(this);
        this.sUwuMtUcgVzMHVXVoNHFrTY = new AVBqUkzZTgvQKwqvfonPEcF();
        this.VZagBOcdslnIaKEkojULJvx = new gnLUzUqSTDchaQNdJTgTnhn();
        this.ibbBhgWhrhhiOLwDlcriPhb = new JPanel();
        this.FoVkhFqKjpvomrYQnnVFKwY = new JPanel();
        this.kMqExmRlFLPTFqBDauCBKYL = new JPanel();
        this.iwitQCGCnkthNoQBBlYaPUM = new XZEXahJHCGCBNASefxRYhTY();
        this.YGjBevanihqaxYKnUNtrNeA = new JLabel();
        this.ggsqrqYbiokXEjuGiCwGpvf = new uBNIahMkeIPqFihQtHhzUgi();
        this.TNdBwPzcCrGifNBGlgVkPGL = new JPanel();
        this.SYnuCfTgzCxensnEBdDedFe = new IpeEJbKSCPCYelngcqwUQgF();
        this.CWUsTkhDhNSqiWmIUfrczRE = new JPanel();
        this.ajlSZBxlJSwYUTeUsFfhumH = new TSILPPfdcnHrmGfZNXMsPlw();
        this.xurJiSGFDQVeEtISoLSazWS = new LRWbrwPJNJMrzLYayAJxsLY();
        this.rTbADuShFCOuMvGFEuNmbFb = new uBNIahMkeIPqFihQtHhzUgi();
        this.uAGKHXCiDSbltWOPIpXUgwC = new JPanel();
        this.JSuXbPLjXcQLpTiButqPpoI = new uRfbqkKHjLdhIvxtcBLiaka();
        this.wunjGuaHWPKejzkQKUJfPKe = new JLabel();
        this.tJuPpiiZKFnZdtTTOrwfbxj = new uBNIahMkeIPqFihQtHhzUgi();
        this.cmBIzvlUaDPTiIjykjjmigy = new JPanel();
        this.KLSmtNpcsSwOKRbEbUKdpqL = new ntMSlcredseGwvbyesPSAQf();
        this.NuCoRkdmXmpraThwzNAiTcw = new JLabel();
        this.NwteqrdXWwWpaoJmiBDNxxz = new JScrollPane();
        this.XphHMDaiRLyTnLXiOVlLPqZ = new JPanel();
        this.gLHqHFGBEIDXbcqrsZzduVF = new NCABabPjyneGQZVXMqQJJlz();
        this.dBprZQxZjIUbnidwEbEFsgB = new miBFKRJVXkTtMTMpbtygQBp();
        this.dnqxuOOQwmxxivZzrQBWydh = new gnLUzUqSTDchaQNdJTgTnhn();
        this.setDefaultCloseOperation(3);
        this.setTitle("MusicScope");
        this.setBackground(new Color(0, 0, 0));
        this.setMinimumSize(new Dimension(1145, 665));
        this.setPreferredSize(new Dimension(1140, this.rHAjVyBgPhqkQKsOvJMPMYn));
        this.vJgxuXjYdOvTUFZsFThavLL.setBackground(new Color(0, 0, 0));
        this.vJgxuXjYdOvTUFZsFThavLL.setForeground(new Color(255, 255, 255));
        this.OrmpCzNZzYDlbDZDBXyofLf.setBackground(this.getBackground());
        this.OrmpCzNZzYDlbDZDBXyofLf.setForeground(new Color(255, 255, 255));
        this.kVXnygMrAwyMajIgLatcyWS.setBackground(this.getBackground());
        this.kVXnygMrAwyMajIgLatcyWS.setForeground(new Color(255, 255, 255));
        this.TTvVyJBikEjkvfEQPPobmUz.setBackground(this.getBackground());
        this.VmkNmvoUyyfcyaaKFyveguY.setBackground(this.getBackground());
        this.VmkNmvoUyyfcyaaKFyveguY.setForeground(new Color(255, 255, 255));
        this.VmkNmvoUyyfcyaaKFyveguY.setMaximumSize(new Dimension(472, 36));
        this.DamZYXCIxKyKrnRzlNpeRfa.setBackground(this.getBackground());
        this.DamZYXCIxKyKrnRzlNpeRfa.setForeground(new Color(255, 255, 255));
        this.DamZYXCIxKyKrnRzlNpeRfa.setEnabled(false);
        GroupLayout groupLayout = new GroupLayout(this.kVXnygMrAwyMajIgLatcyWS);
        this.kVXnygMrAwyMajIgLatcyWS.setLayout(groupLayout);
        groupLayout.setHorizontalGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout.createSequentialGroup().addComponent(this.sUwuMtUcgVzMHVXVoNHFrTY, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.TTvVyJBikEjkvfEQPPobmUz, -2, 298, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.YikeWIksDnZbpLLacoPMfKN, -2, 10, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.DamZYXCIxKyKrnRzlNpeRfa, -2, 141, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.GgoKTcuIevtAhezhbHlrofU, -2, 10, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.VmkNmvoUyyfcyaaKFyveguY, -1, 438, Short.MAX_VALUE).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.IiqlRFfWYxYaAobCQvdRFEl, -2, 119, -2).addContainerGap()));
        groupLayout.setVerticalGroup(groupLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.VmkNmvoUyyfcyaaKFyveguY, -2, 0, Short.MAX_VALUE).addComponent(this.YikeWIksDnZbpLLacoPMfKN, -1, -1, Short.MAX_VALUE).addComponent(this.GgoKTcuIevtAhezhbHlrofU, -1, -1, Short.MAX_VALUE).addComponent(this.DamZYXCIxKyKrnRzlNpeRfa, -2, 0, Short.MAX_VALUE).addComponent(this.TTvVyJBikEjkvfEQPPobmUz, -1, -1, Short.MAX_VALUE).addComponent(this.IiqlRFfWYxYaAobCQvdRFEl, GroupLayout.Alignment.TRAILING, -1, -1, Short.MAX_VALUE).addComponent(this.sUwuMtUcgVzMHVXVoNHFrTY, GroupLayout.Alignment.TRAILING, -1, -1, Short.MAX_VALUE));
        this.ibbBhgWhrhhiOLwDlcriPhb.setBackground(this.getBackground());
        this.FoVkhFqKjpvomrYQnnVFKwY.setBackground(this.getBackground());
        this.FoVkhFqKjpvomrYQnnVFKwY.setForeground(new Color(0, 144, 0));
        this.kMqExmRlFLPTFqBDauCBKYL.setBackground(this.getBackground());
        this.iwitQCGCnkthNoQBBlYaPUM.setBackground(this.getBackground());
        this.iwitQCGCnkthNoQBBlYaPUM.setDoubleBuffered(true);
        this.iwitQCGCnkthNoQBBlYaPUM.setMinimumSize(new Dimension(142, 0));
        this.iwitQCGCnkthNoQBBlYaPUM.setPreferredSize(new Dimension(0, 100));
        this.YGjBevanihqaxYKnUNtrNeA.setForeground(this.FoVkhFqKjpvomrYQnnVFKwY.getForeground());
        this.YGjBevanihqaxYKnUNtrNeA.setHorizontalAlignment(2);
        this.YGjBevanihqaxYKnUNtrNeA.setLabelFor(this.kMqExmRlFLPTFqBDauCBKYL);
        this.YGjBevanihqaxYKnUNtrNeA.setText("Format");
        this.YGjBevanihqaxYKnUNtrNeA.setFocusable(false);
        this.iwitQCGCnkthNoQBBlYaPUM.add(this.YGjBevanihqaxYKnUNtrNeA);
        this.YGjBevanihqaxYKnUNtrNeA.setBounds(0, 0, 121, 14);
        GroupLayout groupLayout2 = new GroupLayout(this.kMqExmRlFLPTFqBDauCBKYL);
        this.kMqExmRlFLPTFqBDauCBKYL.setLayout(groupLayout2);
        groupLayout2.setHorizontalGroup(groupLayout2.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout2.createSequentialGroup().addGap(0, 0, 0).addComponent(this.iwitQCGCnkthNoQBBlYaPUM, -2, 121, -2).addGap(0, 0, Short.MAX_VALUE)));
        groupLayout2.setVerticalGroup(groupLayout2.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout2.createSequentialGroup().addGap(0, 0, 0).addComponent(this.iwitQCGCnkthNoQBBlYaPUM, -1, 300, Short.MAX_VALUE).addGap(0, 0, 0)));
        this.TNdBwPzcCrGifNBGlgVkPGL.setBackground(this.getBackground());
        this.SYnuCfTgzCxensnEBdDedFe.setBackground(this.getBackground());
        this.SYnuCfTgzCxensnEBdDedFe.setDoubleBuffered(true);
        this.SYnuCfTgzCxensnEBdDedFe.setMinimumSize(new Dimension(166, 300));
        this.SYnuCfTgzCxensnEBdDedFe.setName("");
        this.CWUsTkhDhNSqiWmIUfrczRE.setBackground(this.getBackground());
        this.ajlSZBxlJSwYUTeUsFfhumH.setBackground(this.getBackground());
        this.ajlSZBxlJSwYUTeUsFfhumH.setDoubleBuffered(true);
        this.xurJiSGFDQVeEtISoLSazWS.setForeground(new Color(255, 255, 255));
        this.xurJiSGFDQVeEtISoLSazWS.rHAjVyBgPhqkQKsOvJMPMYn(Color.decode("#009000"));
        this.xurJiSGFDQVeEtISoLSazWS.QPeIwmpzLZIktKLXAJOQHcO(Color.GRAY);
        this.xurJiSGFDQVeEtISoLSazWS.rHAjVyBgPhqkQKsOvJMPMYn("Levels");
        this.xurJiSGFDQVeEtISoLSazWS.QPeIwmpzLZIktKLXAJOQHcO("Bit Monitor");
        this.ajlSZBxlJSwYUTeUsFfhumH.add(this.xurJiSGFDQVeEtISoLSazWS);
        this.xurJiSGFDQVeEtISoLSazWS.setBounds(0, 0, 130, 14);
        GroupLayout groupLayout3 = new GroupLayout(this.CWUsTkhDhNSqiWmIUfrczRE);
        this.CWUsTkhDhNSqiWmIUfrczRE.setLayout(groupLayout3);
        groupLayout3.setHorizontalGroup(groupLayout3.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout3.createSequentialGroup().addGap(0, 0, 0).addComponent(this.ajlSZBxlJSwYUTeUsFfhumH, -2, 131, -2).addGap(0, 0, Short.MAX_VALUE)));
        groupLayout3.setVerticalGroup(groupLayout3.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout3.createSequentialGroup().addGap(0, 0, 0).addComponent(this.ajlSZBxlJSwYUTeUsFfhumH, -1, -1, Short.MAX_VALUE).addGap(0, 0, 0)));
        GroupLayout groupLayout4 = new GroupLayout(this.TNdBwPzcCrGifNBGlgVkPGL);
        this.TNdBwPzcCrGifNBGlgVkPGL.setLayout(groupLayout4);
        groupLayout4.setHorizontalGroup(groupLayout4.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout4.createSequentialGroup().addGap(0, 0, 0).addComponent(this.CWUsTkhDhNSqiWmIUfrczRE, -2, -1, -2).addGap(33, 33, 33).addComponent(this.SYnuCfTgzCxensnEBdDedFe, -2, 170, -2).addGap(0, 0, 0)));
        groupLayout4.setVerticalGroup(groupLayout4.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.CWUsTkhDhNSqiWmIUfrczRE, -1, -1, Short.MAX_VALUE).addComponent(this.SYnuCfTgzCxensnEBdDedFe, GroupLayout.Alignment.TRAILING, -1, -1, Short.MAX_VALUE));
        this.uAGKHXCiDSbltWOPIpXUgwC.setBackground(this.getBackground());
        this.JSuXbPLjXcQLpTiButqPpoI.setBackground(this.getBackground());
        this.JSuXbPLjXcQLpTiButqPpoI.setDoubleBuffered(true);
        this.wunjGuaHWPKejzkQKUJfPKe.setForeground(this.FoVkhFqKjpvomrYQnnVFKwY.getForeground());
        this.wunjGuaHWPKejzkQKUJfPKe.setText("History");
        this.JSuXbPLjXcQLpTiButqPpoI.add(this.wunjGuaHWPKejzkQKUJfPKe);
        this.wunjGuaHWPKejzkQKUJfPKe.setBounds(0, 0, 50, 14);
        GroupLayout groupLayout5 = new GroupLayout(this.uAGKHXCiDSbltWOPIpXUgwC);
        this.uAGKHXCiDSbltWOPIpXUgwC.setLayout(groupLayout5);
        groupLayout5.setHorizontalGroup(groupLayout5.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout5.createSequentialGroup().addGap(0, 0, 0).addComponent(this.JSuXbPLjXcQLpTiButqPpoI, -2, 303, -2).addGap(0, 0, Short.MAX_VALUE)));
        groupLayout5.setVerticalGroup(groupLayout5.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout5.createSequentialGroup().addGap(0, 0, 0).addComponent(this.JSuXbPLjXcQLpTiButqPpoI, -1, -1, Short.MAX_VALUE).addGap(0, 0, 0)));
        this.cmBIzvlUaDPTiIjykjjmigy.setBackground(this.getBackground());
        this.KLSmtNpcsSwOKRbEbUKdpqL.setBackground(this.getBackground());
        this.KLSmtNpcsSwOKRbEbUKdpqL.setDoubleBuffered(true);
        this.KLSmtNpcsSwOKRbEbUKdpqL.setMinimumSize(new Dimension(200, 300));
        this.NuCoRkdmXmpraThwzNAiTcw.setForeground(this.FoVkhFqKjpvomrYQnnVFKwY.getForeground());
        this.NuCoRkdmXmpraThwzNAiTcw.setText("Stereo");
        this.KLSmtNpcsSwOKRbEbUKdpqL.add(this.NuCoRkdmXmpraThwzNAiTcw);
        this.NuCoRkdmXmpraThwzNAiTcw.setBounds(0, 0, 202, 14);
        GroupLayout groupLayout6 = new GroupLayout(this.cmBIzvlUaDPTiIjykjjmigy);
        this.cmBIzvlUaDPTiIjykjjmigy.setLayout(groupLayout6);
        groupLayout6.setHorizontalGroup(groupLayout6.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout6.createSequentialGroup().addGap(0, 0, 0).addComponent(this.KLSmtNpcsSwOKRbEbUKdpqL, -2, 202, -2).addContainerGap(-1, Short.MAX_VALUE)));
        groupLayout6.setVerticalGroup(groupLayout6.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout6.createSequentialGroup().addGap(0, 0, 0).addComponent(this.KLSmtNpcsSwOKRbEbUKdpqL, -1, -1, Short.MAX_VALUE).addGap(0, 0, 0)));
        GroupLayout groupLayout7 = new GroupLayout(this.FoVkhFqKjpvomrYQnnVFKwY);
        this.FoVkhFqKjpvomrYQnnVFKwY.setLayout(groupLayout7);
        groupLayout7.setHorizontalGroup(groupLayout7.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout7.createSequentialGroup().addGap(5, 5, 5).addComponent(this.kMqExmRlFLPTFqBDauCBKYL, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.ggsqrqYbiokXEjuGiCwGpvf, -2, 10, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.TNdBwPzcCrGifNBGlgVkPGL, -1, -1, Short.MAX_VALUE).addGap(10, 10, 10).addComponent(this.rTbADuShFCOuMvGFEuNmbFb, -2, 10, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.uAGKHXCiDSbltWOPIpXUgwC, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED, -1, Short.MAX_VALUE).addComponent(this.tJuPpiiZKFnZdtTTOrwfbxj, -2, 10, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.cmBIzvlUaDPTiIjykjjmigy, -2, -1, -2).addGap(20, 20, 20)));
        groupLayout7.setVerticalGroup(groupLayout7.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.ggsqrqYbiokXEjuGiCwGpvf, -1, -1, Short.MAX_VALUE).addComponent(this.rTbADuShFCOuMvGFEuNmbFb, -1, -1, Short.MAX_VALUE).addComponent(this.tJuPpiiZKFnZdtTTOrwfbxj, -1, -1, Short.MAX_VALUE).addComponent(this.kMqExmRlFLPTFqBDauCBKYL, -1, -1, Short.MAX_VALUE).addComponent(this.TNdBwPzcCrGifNBGlgVkPGL, -1, -1, Short.MAX_VALUE).addComponent(this.uAGKHXCiDSbltWOPIpXUgwC, -1, -1, Short.MAX_VALUE).addComponent(this.cmBIzvlUaDPTiIjykjjmigy, -1, -1, Short.MAX_VALUE));
        this.NwteqrdXWwWpaoJmiBDNxxz.setBackground(this.getBackground());
        this.NwteqrdXWwWpaoJmiBDNxxz.setBorder(null);
        this.NwteqrdXWwWpaoJmiBDNxxz.setHorizontalScrollBarPolicy(31);
        this.NwteqrdXWwWpaoJmiBDNxxz.getVerticalScrollBar().setUI(new ScrollbarStyle());
        this.NwteqrdXWwWpaoJmiBDNxxz.setDoubleBuffered(true);
        this.XphHMDaiRLyTnLXiOVlLPqZ.setBackground(this.getBackground());
        this.gLHqHFGBEIDXbcqrsZzduVF.setBackground(this.getBackground());
        this.gLHqHFGBEIDXbcqrsZzduVF.setDoubleBuffered(true);
        this.dBprZQxZjIUbnidwEbEFsgB.setBackground(this.getBackground());
        this.dBprZQxZjIUbnidwEbEFsgB.setDoubleBuffered(true);
        GroupLayout groupLayout8 = new GroupLayout(this.XphHMDaiRLyTnLXiOVlLPqZ);
        this.XphHMDaiRLyTnLXiOVlLPqZ.setLayout(groupLayout8);
        groupLayout8.setHorizontalGroup(groupLayout8.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout8.createSequentialGroup().addGap(0, 0, 0).addGroup(groupLayout8.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout8.createSequentialGroup().addComponent(this.dBprZQxZjIUbnidwEbEFsgB, -2, 1074, -2).addContainerGap()).addComponent(this.gLHqHFGBEIDXbcqrsZzduVF, -1, -1, Short.MAX_VALUE))));
        groupLayout8.setVerticalGroup(groupLayout8.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout8.createSequentialGroup().addComponent(this.gLHqHFGBEIDXbcqrsZzduVF, -2, 280, -2).addGap(18, 18, 18).addComponent(this.dBprZQxZjIUbnidwEbEFsgB, -2, 269, -2).addContainerGap(-1, Short.MAX_VALUE)));
        this.NwteqrdXWwWpaoJmiBDNxxz.setViewportView(this.XphHMDaiRLyTnLXiOVlLPqZ);
        GroupLayout groupLayout9 = new GroupLayout(this.ibbBhgWhrhhiOLwDlcriPhb);
        this.ibbBhgWhrhhiOLwDlcriPhb.setLayout(groupLayout9);
        groupLayout9.setHorizontalGroup(groupLayout9.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout9.createSequentialGroup().addGap(0, 0, 0).addGroup(groupLayout9.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.dnqxuOOQwmxxivZzrQBWydh, -1, -1, Short.MAX_VALUE).addComponent(this.FoVkhFqKjpvomrYQnnVFKwY, -1, -1, Short.MAX_VALUE).addComponent(this.NwteqrdXWwWpaoJmiBDNxxz)).addGap(10, 10, 10)));
        groupLayout9.setVerticalGroup(groupLayout9.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout9.createSequentialGroup().addGap(3, 3, 3).addComponent(this.FoVkhFqKjpvomrYQnnVFKwY, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.dnqxuOOQwmxxivZzrQBWydh, -2, 10, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.NwteqrdXWwWpaoJmiBDNxxz, -1, 284, Short.MAX_VALUE).addGap(5, 5, 5)));
        GroupLayout groupLayout10 = new GroupLayout(this.OrmpCzNZzYDlbDZDBXyofLf);
        this.OrmpCzNZzYDlbDZDBXyofLf.setLayout(groupLayout10);
        groupLayout10.setHorizontalGroup(groupLayout10.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout10.createSequentialGroup().addContainerGap().addGroup(groupLayout10.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(groupLayout10.createSequentialGroup().addComponent(this.VZagBOcdslnIaKEkojULJvx, -1, -1, Short.MAX_VALUE).addGap(10, 10, 10)).addComponent(this.kVXnygMrAwyMajIgLatcyWS, -2, -1, -2).addComponent(this.ibbBhgWhrhhiOLwDlcriPhb, -2, -1, -2))));
        groupLayout10.setVerticalGroup(groupLayout10.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, groupLayout10.createSequentialGroup().addGap(8, 8, 8).addComponent(this.kVXnygMrAwyMajIgLatcyWS, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.VZagBOcdslnIaKEkojULJvx, -2, 7, -2).addGap(3, 3, 3).addComponent(this.ibbBhgWhrhhiOLwDlcriPhb, -1, -1, Short.MAX_VALUE)));
        GroupLayout groupLayout11 = new GroupLayout(this.vJgxuXjYdOvTUFZsFThavLL);
        this.vJgxuXjYdOvTUFZsFThavLL.setLayout(groupLayout11);
        groupLayout11.setHorizontalGroup(groupLayout11.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, groupLayout11.createSequentialGroup().addContainerGap(-1, Short.MAX_VALUE).addComponent(this.OrmpCzNZzYDlbDZDBXyofLf, -2, -1, -2).addContainerGap(-1, Short.MAX_VALUE)));
        groupLayout11.setVerticalGroup(groupLayout11.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.OrmpCzNZzYDlbDZDBXyofLf, GroupLayout.Alignment.TRAILING, -1, -1, Short.MAX_VALUE));
        GroupLayout groupLayout12 = new GroupLayout(this.getContentPane());
        this.getContentPane().setLayout(groupLayout12);
        groupLayout12.setHorizontalGroup(groupLayout12.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.vJgxuXjYdOvTUFZsFThavLL, -1, -1, Short.MAX_VALUE));
        groupLayout12.setVerticalGroup(groupLayout12.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.vJgxuXjYdOvTUFZsFThavLL, GroupLayout.Alignment.TRAILING, -1, -1, Short.MAX_VALUE));
        this.pack();
    }

    public void uAGKHXCiDSbltWOPIpXUgwC() {
        try {
            String string = System.getProperty("os.name").toLowerCase();
            String string2 = string.contains("win") ? "Nimbus" : (string.contains("mac") ? "Macintosh" : UIManager.getSystemLookAndFeelClassName());
            for (UIManager.LookAndFeelInfo lookAndFeelInfo : UIManager.getInstalledLookAndFeels()) {
                if (!string2.equals(lookAndFeelInfo.getName())) continue;
                UIManager.setLookAndFeel(lookAndFeelInfo.getClassName());
                break;
            }
        }
        catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException exception) {
            Logger.getLogger(rHAjVyBgPhqkQKsOvJMPMYn.class.getName()).log(Level.SEVERE, null, exception);
        }
        EventQueue.invokeLater(new Runnable(){

            @Override
            public void run() {
                rHAjVyBgPhqkQKsOvJMPMYn.this.setVisible(true);
            }
        });
    }

    @Override
    public BufferedImage TNdBwPzcCrGifNBGlgVkPGL() {
        Container container = this.getContentPane();
        BufferedImage bufferedImage = new BufferedImage(container.getWidth(), container.getHeight(), 2);
        container.paint(bufferedImage.getGraphics());
        return bufferedImage;
    }

    private void XphHMDaiRLyTnLXiOVlLPqZ() {
        FiypGaFYdzscEBybnfTNrMU fiypGaFYdzscEBybnfTNrMU = FiypGaFYdzscEBybnfTNrMU.rHAjVyBgPhqkQKsOvJMPMYn();
        fiypGaFYdzscEBybnfTNrMU.rHAjVyBgPhqkQKsOvJMPMYn("MainFrame", this);
        fiypGaFYdzscEBybnfTNrMU.rHAjVyBgPhqkQKsOvJMPMYn("Format", new mjycquzYfQnWsdeiKxtdpyM(){

            @Override
            public BufferedImage TNdBwPzcCrGifNBGlgVkPGL() {
                return rHAjVyBgPhqkQKsOvJMPMYn.this.rHAjVyBgPhqkQKsOvJMPMYn(rHAjVyBgPhqkQKsOvJMPMYn.this.kMqExmRlFLPTFqBDauCBKYL);
            }
        });
        fiypGaFYdzscEBybnfTNrMU.rHAjVyBgPhqkQKsOvJMPMYn("History", new mjycquzYfQnWsdeiKxtdpyM(){

            @Override
            public BufferedImage TNdBwPzcCrGifNBGlgVkPGL() {
                return rHAjVyBgPhqkQKsOvJMPMYn.this.rHAjVyBgPhqkQKsOvJMPMYn(rHAjVyBgPhqkQKsOvJMPMYn.this.uAGKHXCiDSbltWOPIpXUgwC);
            }
        });
        fiypGaFYdzscEBybnfTNrMU.rHAjVyBgPhqkQKsOvJMPMYn("Levels", new mjycquzYfQnWsdeiKxtdpyM(){

            @Override
            public BufferedImage TNdBwPzcCrGifNBGlgVkPGL() {
                return rHAjVyBgPhqkQKsOvJMPMYn.this.rHAjVyBgPhqkQKsOvJMPMYn(rHAjVyBgPhqkQKsOvJMPMYn.this.TNdBwPzcCrGifNBGlgVkPGL);
            }
        });
        fiypGaFYdzscEBybnfTNrMU.rHAjVyBgPhqkQKsOvJMPMYn("Spectrum", new mjycquzYfQnWsdeiKxtdpyM(){

            @Override
            public BufferedImage TNdBwPzcCrGifNBGlgVkPGL() {
                return rHAjVyBgPhqkQKsOvJMPMYn.this.rHAjVyBgPhqkQKsOvJMPMYn(rHAjVyBgPhqkQKsOvJMPMYn.this.XphHMDaiRLyTnLXiOVlLPqZ);
            }
        });
        fiypGaFYdzscEBybnfTNrMU.rHAjVyBgPhqkQKsOvJMPMYn("Stereo", new mjycquzYfQnWsdeiKxtdpyM(){

            @Override
            public BufferedImage TNdBwPzcCrGifNBGlgVkPGL() {
                return rHAjVyBgPhqkQKsOvJMPMYn.this.rHAjVyBgPhqkQKsOvJMPMYn(rHAjVyBgPhqkQKsOvJMPMYn.this.cmBIzvlUaDPTiIjykjjmigy);
            }
        });
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private BufferedImage rHAjVyBgPhqkQKsOvJMPMYn(JPanel jPanel) {
        BufferedImage bufferedImage = new BufferedImage(jPanel.getWidth(), jPanel.getHeight(), 6);
        JPanel jPanel2 = jPanel;
        synchronized (jPanel2) {
            Graphics2D graphics2D = bufferedImage.createGraphics();
            jPanel.printAll(graphics2D);
            graphics2D.dispose();
        }
        return bufferedImage;
    }
}

