/*
 * Decompiled with CFR 0.152.
 */
package com.xivero.hraa.gui.frame.jitter;

import com.xivero.hraa.gui.frame.jitter.JitterAnalyser;

public class QPeIwmpzLZIktKLXAJOQHcO
implements Runnable {
    private final int rHAjVyBgPhqkQKsOvJMPMYn = 32768;
    private final int QPeIwmpzLZIktKLXAJOQHcO = (int)(Math.log10(32768.0) / Math.log10(2.0));
    private final int JSuXbPLjXcQLpTiButqPpoI = 4096;
    private final double[] iwitQCGCnkthNoQBBlYaPUM = new double[32768];
    private final double[][] dnqxuOOQwmxxivZzrQBWydh = new double[8][16384];
    private final double[] VZagBOcdslnIaKEkojULJvx = new double[16384];
    private double[] VmkNmvoUyyfcyaaKFyveguY = new double[32768];
    private int YGjBevanihqaxYKnUNtrNeA = 0;
    private final int wunjGuaHWPKejzkQKUJfPKe = 4;
    private boolean NuCoRkdmXmpraThwzNAiTcw = false;

    public QPeIwmpzLZIktKLXAJOQHcO() {
        this.JSuXbPLjXcQLpTiButqPpoI();
    }

    public boolean rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.NuCoRkdmXmpraThwzNAiTcw;
    }

    public void rHAjVyBgPhqkQKsOvJMPMYn(double[] dArray) {
        this.VmkNmvoUyyfcyaaKFyveguY = dArray;
    }

    private void JSuXbPLjXcQLpTiButqPpoI() {
        for (int i = 0; i < 32768; ++i) {
            double d = Math.PI * 2 * (double)i / 32767.0;
            this.iwitQCGCnkthNoQBBlYaPUM[i] = 0.27105140069342 - 0.43329793923448 * Math.cos(d) + 0.21812299954311 * Math.cos(2.0 * d) - 0.06592544638803 * Math.cos(3.0 * d) + 0.01081174209837 * Math.cos(4.0 * d) - 7.7658482522E-4 * Math.cos(5.0 * d) + 1.388721735E-5 * Math.cos(6.0 * d);
        }
    }

    public void QPeIwmpzLZIktKLXAJOQHcO() {
        int n;
        boolean bl = true;
        double[] dArray = new double[32768];
        double[] dArray2 = new double[32768];
        for (n = 0; n < 32768; ++n) {
            dArray[n] = this.iwitQCGCnkthNoQBBlYaPUM[n] * this.VmkNmvoUyyfcyaaKFyveguY[n];
            dArray2[n] = 0.0;
        }
        int n2 = 32768;
        int n3 = this.QPeIwmpzLZIktKLXAJOQHcO;
        int n4 = n2 >> 1;
        int n5 = 0;
        for (n = 0; n < n2 - 1; ++n) {
            int n6;
            if (n < n5) {
                double d = dArray[n];
                double d2 = dArray2[n];
                dArray[n] = dArray[n5];
                dArray2[n] = dArray2[n5];
                dArray[n5] = d;
                dArray2[n5] = d2;
            }
            for (n6 = n4; n6 <= n5; n5 -= n6, n6 >>= 1) {
            }
            n5 += n6;
        }
        double d = -1.0;
        double d3 = 0.0;
        int n7 = 1;
        for (int i = 0; i < n3; ++i) {
            int n8 = n7;
            n7 <<= 1;
            double d4 = 1.0;
            double d5 = 0.0;
            for (n5 = 0; n5 < n8; ++n5) {
                for (n = n5; n < n2; n += n7) {
                    int n9 = n + n8;
                    double d6 = d4 * dArray[n9] - d5 * dArray2[n9];
                    double d7 = d4 * dArray2[n9] + d5 * dArray[n9];
                    dArray[n9] = dArray[n] - d6;
                    dArray2[n9] = dArray2[n] - d7;
                    int n10 = n;
                    dArray[n10] = dArray[n10] + d6;
                    int n11 = n;
                    dArray2[n11] = dArray2[n11] + d7;
                }
                double d8 = d4 * d - d5 * d3;
                d5 = d4 * d3 + d5 * d;
                d4 = d8;
            }
            d3 = Math.sqrt((1.0 - d) / 2.0);
            if (bl) {
                d3 = -d3;
            }
            d = Math.sqrt((1.0 + d) / 2.0);
        }
        ++this.YGjBevanihqaxYKnUNtrNeA;
        if (this.YGjBevanihqaxYKnUNtrNeA > 3) {
            this.YGjBevanihqaxYKnUNtrNeA = 0;
        }
        n = 0;
        while ((double)n < 16384.0) {
            double d9 = dArray[n] / 4096.0;
            double d10 = dArray2[n] / 4096.0;
            double d11 = Math.sqrt(d9 * d9 + d10 * d10);
            for (int i = 0; i < 4; ++i) {
                d11 += this.dnqxuOOQwmxxivZzrQBWydh[i][n];
            }
            this.VZagBOcdslnIaKEkojULJvx[n] = (d11 /= 5.0) > 0.0 ? 20.0 * Math.log10(d11) : -150.0;
            if (this.VZagBOcdslnIaKEkojULJvx[n] < -150.0) {
                this.VZagBOcdslnIaKEkojULJvx[n] = -150.0;
            }
            this.dnqxuOOQwmxxivZzrQBWydh[this.YGjBevanihqaxYKnUNtrNeA][n] = d11;
            ++n;
        }
        JitterAnalyser.rHAjVyBgPhqkQKsOvJMPMYn(this.VZagBOcdslnIaKEkojULJvx);
    }

    @Override
    public void run() {
        this.NuCoRkdmXmpraThwzNAiTcw = true;
        this.QPeIwmpzLZIktKLXAJOQHcO();
        this.NuCoRkdmXmpraThwzNAiTcw = false;
    }
}

