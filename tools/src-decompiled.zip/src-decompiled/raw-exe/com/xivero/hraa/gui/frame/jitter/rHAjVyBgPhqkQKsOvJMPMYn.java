/*
 * Decompiled with CFR 0.152.
 */
package com.xivero.hraa.gui.frame.jitter;

import com.xivero.hraa.gui.frame.jitter.JitterAnalyser;
import com.xivero.hraa.gui.frame.jitter.QPeIwmpzLZIktKLXAJOQHcO;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;

public class rHAjVyBgPhqkQKsOvJMPMYn
implements Runnable {
    private final float QPeIwmpzLZIktKLXAJOQHcO = 44100.0f;
    private int JSuXbPLjXcQLpTiButqPpoI;
    private TargetDataLine iwitQCGCnkthNoQBBlYaPUM = null;
    private boolean dnqxuOOQwmxxivZzrQBWydh = false;
    private final byte[] VZagBOcdslnIaKEkojULJvx = new byte[65536];
    private final double[] VmkNmvoUyyfcyaaKFyveguY = new double[65536];
    private int YGjBevanihqaxYKnUNtrNeA;
    private int wunjGuaHWPKejzkQKUJfPKe;
    private int NuCoRkdmXmpraThwzNAiTcw = 4;
    public static QPeIwmpzLZIktKLXAJOQHcO rHAjVyBgPhqkQKsOvJMPMYn = new QPeIwmpzLZIktKLXAJOQHcO();

    public void rHAjVyBgPhqkQKsOvJMPMYn(boolean bl) {
        this.dnqxuOOQwmxxivZzrQBWydh = bl;
    }

    public boolean rHAjVyBgPhqkQKsOvJMPMYn() {
        return this.dnqxuOOQwmxxivZzrQBWydh;
    }

    private void QPeIwmpzLZIktKLXAJOQHcO() {
        int n = 2;
        boolean bl = false;
        boolean bl2 = true;
        this.JSuXbPLjXcQLpTiButqPpoI = 24;
        Mixer mixer = AudioSystem.getMixer(JitterAnalyser.rHAjVyBgPhqkQKsOvJMPMYn[JitterAnalyser.QPeIwmpzLZIktKLXAJOQHcO[JitterAnalyser.iwitQCGCnkthNoQBBlYaPUM.getSelectedIndex()]]);
        AudioFormat audioFormat = new AudioFormat(44100.0f, this.JSuXbPLjXcQLpTiButqPpoI, n, bl2, bl);
        DataLine.Info info = new DataLine.Info(TargetDataLine.class, audioFormat);
        try {
            this.NuCoRkdmXmpraThwzNAiTcw = 6;
            this.iwitQCGCnkthNoQBBlYaPUM = (TargetDataLine)mixer.getLine(info);
            this.iwitQCGCnkthNoQBBlYaPUM.open(audioFormat);
            this.iwitQCGCnkthNoQBBlYaPUM.start();
            this.iwitQCGCnkthNoQBBlYaPUM.flush();
        }
        catch (LineUnavailableException lineUnavailableException) {
            System.out.println("No Input Audio Line Available!");
        }
        catch (Exception exception) {
            System.out.println("Input Audio Format Not Supported! Try 16 Bit.");
            this.JSuXbPLjXcQLpTiButqPpoI = 16;
            this.NuCoRkdmXmpraThwzNAiTcw = 4;
            audioFormat = new AudioFormat(44100.0f, this.JSuXbPLjXcQLpTiButqPpoI, n, bl2, bl);
            info = new DataLine.Info(TargetDataLine.class, audioFormat);
            try {
                this.iwitQCGCnkthNoQBBlYaPUM = (TargetDataLine)mixer.getLine(info);
                this.iwitQCGCnkthNoQBBlYaPUM.open(audioFormat);
                this.iwitQCGCnkthNoQBBlYaPUM.start();
                this.iwitQCGCnkthNoQBBlYaPUM.flush();
            }
            catch (LineUnavailableException lineUnavailableException) {
                Logger.getLogger(rHAjVyBgPhqkQKsOvJMPMYn.class.getName()).log(Level.SEVERE, null, lineUnavailableException);
                System.out.println("Input Audio Format Not Supported!");
            }
        }
    }

    private void JSuXbPLjXcQLpTiButqPpoI() {
        int n = 512;
        int n2 = this.NuCoRkdmXmpraThwzNAiTcw * n;
        int n3 = 0;
        double[] dArray = new double[65536];
        double d = Math.pow(2.0, this.JSuXbPLjXcQLpTiButqPpoI);
        this.dnqxuOOQwmxxivZzrQBWydh = false;
        while (!this.dnqxuOOQwmxxivZzrQBWydh) {
            this.iwitQCGCnkthNoQBBlYaPUM.read(this.VZagBOcdslnIaKEkojULJvx, 0, n2);
            for (int i = 0; i < n2; i += this.NuCoRkdmXmpraThwzNAiTcw) {
                int n4;
                int n5;
                if (this.JSuXbPLjXcQLpTiButqPpoI == 24) {
                    n5 = this.VZagBOcdslnIaKEkojULJvx[i + 2];
                    n5 = n5 << 8 | this.VZagBOcdslnIaKEkojULJvx[i + 1] & 0xFF;
                    n5 = n5 << 8 | this.VZagBOcdslnIaKEkojULJvx[i] & 0xFF;
                    n4 = this.VZagBOcdslnIaKEkojULJvx[i + 5];
                    n4 = n4 << 8 | this.VZagBOcdslnIaKEkojULJvx[i + 4] & 0xFF;
                    n4 = n4 << 8 | this.VZagBOcdslnIaKEkojULJvx[i + 3] & 0xFF;
                } else {
                    n5 = this.VZagBOcdslnIaKEkojULJvx[i + 1];
                    n5 = n5 << 8 | this.VZagBOcdslnIaKEkojULJvx[i] & 0xFF;
                    n4 = this.VZagBOcdslnIaKEkojULJvx[i + 3];
                    n4 = n4 << 8 | this.VZagBOcdslnIaKEkojULJvx[i + 2] & 0xFF;
                }
                this.VmkNmvoUyyfcyaaKFyveguY[this.YGjBevanihqaxYKnUNtrNeA] = (double)(n5 + n4) / d;
                ++this.YGjBevanihqaxYKnUNtrNeA;
                if (this.YGjBevanihqaxYKnUNtrNeA > 65535) {
                    this.YGjBevanihqaxYKnUNtrNeA = 0;
                }
                if (++n3 <= 4096 || rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn()) continue;
                n3 = 0;
                this.wunjGuaHWPKejzkQKUJfPKe = this.YGjBevanihqaxYKnUNtrNeA;
                for (int j = 0; j < Short.MAX_VALUE; ++j) {
                    dArray[j] = this.VmkNmvoUyyfcyaaKFyveguY[this.wunjGuaHWPKejzkQKUJfPKe];
                    ++this.wunjGuaHWPKejzkQKUJfPKe;
                    if (this.wunjGuaHWPKejzkQKUJfPKe <= 65535) continue;
                    this.wunjGuaHWPKejzkQKUJfPKe = 0;
                }
                rHAjVyBgPhqkQKsOvJMPMYn.rHAjVyBgPhqkQKsOvJMPMYn(dArray);
                new Thread(rHAjVyBgPhqkQKsOvJMPMYn).start();
            }
        }
        this.iwitQCGCnkthNoQBBlYaPUM.flush();
        this.iwitQCGCnkthNoQBBlYaPUM.stop();
        this.iwitQCGCnkthNoQBBlYaPUM.close();
        JitterAnalyser.rHAjVyBgPhqkQKsOvJMPMYn();
    }

    @Override
    public void run() {
        this.QPeIwmpzLZIktKLXAJOQHcO();
        this.JSuXbPLjXcQLpTiButqPpoI();
    }
}

